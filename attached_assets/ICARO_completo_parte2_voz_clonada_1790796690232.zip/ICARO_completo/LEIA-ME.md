# ÍCARO: pacote completo do projeto

Assistente virtual de aula da Contabilidade UEFS (ITCONT 2026).
ÍCARO = Inteligência, Ciência de Dados, Análise de Dados, Resultados e Operações.
Criado a partir do "Jarvis" do professor Rômulo Benício, em 29/09/2026.

## O que tem em cada pasta

| Pasta | Conteúdo |
|---|---|
| `01_prompts` | Todos os seus prompts na íntegra, o resumo da conversa e o prompt do ÍCARO para o ChatGPT |
| `02_arquivos_enviados` | Código original do Jarvis, vídeo da ITCONT, amostra de voz e os prints que você mandou |
| `03_artefato_publicado` | Arquivos exatos do artefato publicado no Claude (página, rosto, vídeos) e o código-fonte |
| `04_icaro_arquivo_local` | ÍCARO em arquivo único para abrir com dois cliques (microfone, Gemini e ChatGPT Voz) e a foto de perfil |
| `05_voz_clonada` | Pacote da voz clonada (XTTS-v2) com instalador, servidor e calibração de 50 validações |
| `06_versoes_anteriores` | Primeira versão do ÍCARO (estilo Jarvis) |
| `07_testes_e_build` | Scripts que montam as versões e os testes automáticos usados |
| `08_imagens_de_tela` | Capturas da versão final e quadros do vídeo original |

## Link do artefato

https://claude.ai/artifact/KVwny834hxikwcKtmRn62S

## Como usar, em resumo

- **Na hora, sem instalar nada:** abra o artefato. O Claude responde e o ÍCARO fala com a voz do navegador. Lá, pergunte digitando ou pelo ditado do chat do Claude.
- **Com microfone e ChatGPT Voz:** abra `04_icaro_arquivo_local/icaro_uefs.html` no Chrome ou Edge e coloque a chave da API OpenAI em ☰ > Conexão.
- **Com a voz igual ao vídeo:** siga o `LEIA-ME.txt` de `05_voz_clonada/icaro-voz`. A ordem é instalar, depois calibrar, depois iniciar.

## Atenção: segurança

O arquivo `04_icaro_arquivo_local/icaro_uefs.html` e o `05_voz_clonada/icaro-voz/icaro_uefs.html` levam a chave do Gemini gravada. O arquivo `01_prompts/prompts_do_usuario.md` também tem essa chave, porque reproduz a sua primeira mensagem.
**Não compartilhe este zip nem esses arquivos publicamente.** Depois do evento, apague a chave no Google AI Studio e gere outra.
