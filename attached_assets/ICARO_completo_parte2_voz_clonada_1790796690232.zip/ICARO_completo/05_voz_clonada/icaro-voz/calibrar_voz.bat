@echo off
chcp 65001 >nul
title ICARO - calibracao da voz (50 validacoes)
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Rode primeiro o instalar.bat
  pause
  exit /b 1
)
set COQUI_TOS_AGREED=1
set PYTHONIOENCODING=utf-8
echo Calibrando a voz com 50 validacoes. Sem placa de video pode levar de 15 a 40 minutos.
echo Feche o iniciar_icaro.bat antes, se estiver aberto.
echo.
venv\Scripts\python.exe calibrar_voz.py %*
echo.
echo Pronto. Abra o iniciar_icaro.bat de novo para usar a voz calibrada.
pause
