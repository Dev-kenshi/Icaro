# -*- coding: utf-8 -*-
"""
ÍCARO - Calibração da voz clonada com 50 validações.

Cada validação:
  1. escolhe uma combinação de parâmetros do XTTS (trecho de referência, temperatura,
     top_p, top_k, penalidade de repetição, velocidade, tamanho do condicionamento);
  2. gera duas frases de teste com a voz clonada;
  3. mede a voz gerada (tom, entonação, ritmo, timbre, espectro, brilho) e a
     similaridade de locutor (cosseno entre embeddings de voz);
  4. dá uma nota de 0 a 100 comparando com a voz do vídeo.

As 12 primeiras validações exploram o espaço ao acaso; as outras 38 refinam em volta
da melhor (busca local com passo que diminui). No fim calcula a correção de tom e a
equalização que aproximam ainda mais o resultado e grava tudo em calibracao.json.
O servidor_voz.py passa a usar essa configuração automaticamente.

Uso:  venv\\Scripts\\python.exe calibrar_voz.py           (50 validações)
      venv\\Scripts\\python.exe calibrar_voz.py --n 20    (mais rápido)
"""
import argparse
import csv
import json
import math
import os
import random
import sys
import time

import numpy as np
import soundfile as sf

import metricas_voz as M

PASTA = os.path.dirname(os.path.abspath(__file__))
SAIDA = os.path.join(PASTA, "calibracao")
FRASES = [
    "Olá, turma. Eu sou o ÍCARO, assistente de aula da Contabilidade da UEFS.",
    "A análise de dados transforma números em decisões melhores para a empresa.",
]
ESPACO = {
    "temperature": (0.30, 0.90),
    "top_p": (0.60, 0.95),
    "repetition_penalty": (2.0, 10.0),
    "speed": (0.85, 1.10),
    "top_k": [20, 30, 50],
    "gpt_cond_len": [6, 12, 24],
}


def log(msg):
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


# ------------------------------------------------------------------ referências
def preparar_referencias():
    """Cria candidatos de referência a partir da voz do vídeo (separada da música, se possível)."""
    os.makedirs(SAIDA, exist_ok=True)
    vocal = os.path.join(PASTA, "separado", "htdemucs", "audio_completo_video", "vocals.wav")
    fonte = vocal if os.path.exists(vocal) else os.path.join(PASTA, "audio_completo_video.wav")
    y = M.carregar(fonte)
    sr = M.SR
    janelas = {"A_13-30s": (13, 30.5), "B_30-48s": (30, 48), "C_48-66s": (48, 66), "D_5-70s": (5, 70)}
    refs = {}
    for nome, (a, b) in janelas.items():
        trecho = y[int(a * sr): int(b * sr)]
        if len(trecho) > sr * 5:
            p = os.path.join(SAIDA, f"ref_{nome}.wav")
            sf.write(p, trecho, sr)
            refs[nome] = p
    for extra in ("voz_referencia_limpa.wav", "voz_referencia.wav"):
        p = os.path.join(PASTA, extra)
        if os.path.exists(p):
            refs[extra.replace(".wav", "")] = p
    alvo = y[int(5 * sr): int(72 * sr)]  # toda a fala do vídeo é o alvo
    alvo_path = os.path.join(SAIDA, "alvo.wav")
    sf.write(alvo_path, alvo, sr)
    return refs, alvo, alvo_path, os.path.basename(fonte)


# ------------------------------------------------------------------ busca
def amostrar(rng, refs):
    return {
        "ref": rng.choice(sorted(refs)),
        "temperature": rng.uniform(*ESPACO["temperature"]),
        "top_p": rng.uniform(*ESPACO["top_p"]),
        "repetition_penalty": rng.uniform(*ESPACO["repetition_penalty"]),
        "speed": rng.uniform(*ESPACO["speed"]),
        "top_k": rng.choice(ESPACO["top_k"]),
        "gpt_cond_len": rng.choice(ESPACO["gpt_cond_len"]),
    }


def vizinho(rng, base, refs, passo):
    """Perturba a melhor configuração; `passo` (0..1) encolhe ao longo da busca."""
    c = dict(base)
    for k in ("temperature", "top_p", "repetition_penalty", "speed"):
        lo, hi = ESPACO[k]
        c[k] = float(np.clip(c[k] + rng.gauss(0, passo * (hi - lo) * 0.35), lo, hi))
    if rng.random() < 0.25 * passo + 0.05:
        c["top_k"] = rng.choice(ESPACO["top_k"])
    if rng.random() < 0.25 * passo + 0.05:
        c["gpt_cond_len"] = rng.choice(ESPACO["gpt_cond_len"])
    if rng.random() < 0.30 * passo:
        c["ref"] = rng.choice(sorted(refs))
    return c


def cosseno(a, b):
    a = np.asarray(a, float).ravel()
    b = np.asarray(b, float).ravel()
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))


def calibrar(sintetizar, embedding, refs, alvo, alvo_path, n=50, semente=7, ao_validar=None):
    """
    sintetizar(texto, cfg) -> (audio float32, sr)
    embedding(caminho_wav) -> vetor do locutor
    Devolve (melhor_cfg, melhor_resultado, historico)
    """
    rng = random.Random(semente)
    perfil_alvo = M.perfil(alvo)
    emb_alvo = embedding(alvo_path)
    log("Voz do vídeo  -> " + M.resumo(perfil_alvo))
    historico = []
    melhor = None
    n_explorar = max(4, min(12, n // 4))
    for i in range(1, n + 1):
        if melhor is None or i <= n_explorar:
            cfg = amostrar(rng, refs)
            fase = "explorar"
        else:
            passo = max(0.15, 1 - (i - n_explorar) / (n - n_explorar))
            cfg = vizinho(rng, melhor[0], refs, passo)
            fase = "refinar"
        t0 = time.time()
        try:
            partes, sr = [], None
            for frase in FRASES:
                a, sr = sintetizar(frase, cfg)
                partes += [a, np.zeros(int(sr * 0.25), np.float32)]
            audio = np.concatenate(partes)
            y = M.normalizar(M.librosa.resample(audio, orig_sr=sr, target_sr=M.SR)) if sr != M.SR else M.normalizar(audio)
            tmp = os.path.join(SAIDA, "_teste.wav")
            sf.write(tmp, y, M.SR)
            p = M.perfil(y)
            sim = cosseno(embedding(tmp), emb_alvo)
            r = M.comparar(p, perfil_alvo, similaridade_locutor=sim)
            r["similaridade_locutor"] = sim
            r["perfil"] = {k: v for k, v in p.items() if k not in ("mfcc", "ltas")}
            r["_perfil"] = p
            r["_audio"] = y
        except Exception as e:  # uma validação com erro não derruba a calibração
            r = {"pontuacao": 0.0, "erro": str(e), "eixos": {}}
        r["segundos"] = round(time.time() - t0, 1)
        historico.append((i, fase, cfg, r))
        novo = melhor is None or r["pontuacao"] > melhor[1]["pontuacao"]
        if novo:
            melhor = (cfg, r)
        log(f"Validação {i:02d}/{n} [{fase}] nota {r['pontuacao']:5.1f}"
            f"{'  <- melhor' if novo else ''}  ({r['segundos']}s)  ref={cfg['ref']} "
            f"temp={cfg['temperature']:.2f} vel={cfg['speed']:.2f}")
        if ao_validar:
            ao_validar(i, r)
    return melhor[0], melhor[1], historico, perfil_alvo


def pos_processar(melhor_r, perfil_alvo):
    """Correção matemática final: desloca o tom e equaliza o espectro para bater com o alvo."""
    corr = M.correcao(melhor_r["_perfil"], perfil_alvo)
    y2 = M.aplicar(melhor_r["_audio"], M.SR, corr["semitons"], corr["eq_db"])
    r2 = M.comparar(M.perfil(y2), perfil_alvo, similaridade_locutor=melhor_r.get("similaridade_locutor"))
    return corr, r2, y2


def salvar(melhor_cfg, melhor_r, corr, r2, historico, perfil_alvo, fonte):
    usar_pos = r2["pontuacao"] > melhor_r["pontuacao"] + 0.5
    cfg = {
        "referencia": melhor_cfg["ref"],
        "gpt_cond_len": melhor_cfg["gpt_cond_len"],
        "inferencia": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in melhor_cfg.items()
                       if k in ("temperature", "top_p", "top_k", "repetition_penalty", "speed")},
        "pos": {"semitons": corr["semitons"] if usar_pos else 0.0, "eq_db": corr["eq_db"] if usar_pos else None},
        "nota_sem_pos": round(melhor_r["pontuacao"], 1),
        "nota_final": round(max(r2["pontuacao"], melhor_r["pontuacao"]), 1),
        "eixos_final": r2["eixos"] if usar_pos else melhor_r["eixos"],
        "alvo": {k: round(float(v), 2) for k, v in perfil_alvo.items() if k not in ("mfcc", "ltas")},
        "fonte_alvo": fonte,
        "validacoes": len(historico),
        "criado_em": time.strftime("%Y-%m-%d %H:%M"),
    }
    with open(os.path.join(PASTA, "calibracao.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    with open(os.path.join(SAIDA, "relatorio_50_validacoes.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        eixos = ["locutor", "tom", "entonacao", "ritmo", "timbre", "espectro", "brilho"]
        w.writerow(["validacao", "fase", "nota", *eixos, "referencia", "temperature", "top_p", "top_k",
                    "repetition_penalty", "speed", "gpt_cond_len", "tom_hz", "silabas_s", "segundos", "erro"])
        for i, fase, c, r in historico:
            e = r.get("eixos", {})
            pf = r.get("perfil", {})
            w.writerow([i, fase, round(r["pontuacao"], 1), *[e.get(k, "") for k in eixos], c["ref"],
                        round(c["temperature"], 3), round(c["top_p"], 3), c["top_k"], round(c["repetition_penalty"], 2),
                        round(c["speed"], 3), c["gpt_cond_len"], round(pf.get("f0_hz", float("nan")), 1),
                        round(pf.get("silabas_s", float("nan")), 2), r["segundos"], r.get("erro", "")])
    return cfg


# ------------------------------------------------------------------ XTTS real
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=50, help="número de validações (padrão 50)")
    args = ap.parse_args()

    os.environ.setdefault("COQUI_TOS_AGREED", "1")
    import torch
    from TTS.api import TTS

    dispositivo = "cuda" if torch.cuda.is_available() else "cpu"
    log(f"Carregando XTTS-v2 em {dispositivo.upper()}...")
    modelo = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(dispositivo).synthesizer.tts_model

    refs, alvo, alvo_path, fonte = preparar_referencias()
    log(f"Referências candidatas: {', '.join(sorted(refs))}  (fonte: {fonte})")
    cache = {}

    def latentes(ref, cond):
        chave = (ref, cond)
        if chave not in cache:
            cache[chave] = modelo.get_conditioning_latents(audio_path=[refs[ref]], gpt_cond_len=cond,
                                                           gpt_cond_chunk_len=min(6, cond), max_ref_length=60)
        return cache[chave]

    def sintetizar(texto, cfg):
        g, s = latentes(cfg["ref"], cfg["gpt_cond_len"])
        torch.manual_seed(1234)
        with torch.inference_mode():
            out = modelo.inference(texto, "pt", g, s, temperature=cfg["temperature"], top_p=cfg["top_p"],
                                   top_k=cfg["top_k"], repetition_penalty=cfg["repetition_penalty"],
                                   speed=cfg["speed"], enable_text_splitting=False)
        w = out["wav"]
        w = w.cpu().numpy() if hasattr(w, "cpu") else np.asarray(w)
        return w.astype(np.float32), 24000

    def embedding(caminho):
        _, s = modelo.get_conditioning_latents(audio_path=[caminho], gpt_cond_len=6, max_ref_length=60)
        return s.cpu().numpy()

    melhor_cfg, melhor_r, hist, perfil_alvo = calibrar(sintetizar, embedding, refs, alvo, alvo_path, n=args.n)
    corr, r2, y2 = pos_processar(melhor_r, perfil_alvo)
    sf.write(os.path.join(SAIDA, "melhor_sem_correcao.wav"), melhor_r["_audio"], M.SR)
    sf.write(os.path.join(SAIDA, "melhor_com_correcao.wav"), y2, M.SR)
    cfg = salvar(melhor_cfg, melhor_r, corr, r2, hist, perfil_alvo, fonte)
    print()
    log(f"Melhor nota: {cfg['nota_sem_pos']} -> com correção de tom/EQ: {r2['pontuacao']:.1f}")
    log(f"Eixos (0-100): {cfg['eixos_final']}")
    log("Configuração salva em calibracao.json. Reinicie o iniciar_icaro.bat para usar.")
    log("Ouça: calibracao\\melhor_com_correcao.wav  |  Relatório: calibracao\\relatorio_50_validacoes.csv")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)
