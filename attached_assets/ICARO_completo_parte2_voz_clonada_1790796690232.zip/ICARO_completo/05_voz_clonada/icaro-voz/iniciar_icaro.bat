@echo off
chcp 65001 >nul
title ICARO - servidor de voz (nao feche esta janela)
cd /d "%~dp0"
if not exist venv\Scripts\python.exe (
  echo Rode primeiro o instalar.bat
  pause
  exit /b 1
)
set COQUI_TOS_AGREED=1
set PYTHONIOENCODING=utf-8
venv\Scripts\python.exe servidor_voz.py
pause
