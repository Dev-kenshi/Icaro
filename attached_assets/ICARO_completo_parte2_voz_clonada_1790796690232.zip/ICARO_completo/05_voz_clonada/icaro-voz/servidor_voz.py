# -*- coding: utf-8 -*-
"""
ÍCARO - Servidor de voz clonada (XTTS-v2, código aberto, roda no seu computador).

O que ele faz:
  1. Carrega o modelo XTTS-v2 (baixado automaticamente na 1ª vez, ~1,8 GB).
  2. Aprende a voz a partir de voz_referencia_limpa.wav (ou voz_referencia.wav).
  3. Abre http://localhost:5002  -> serve o ÍCARO e gera a fala com a voz clonada.

Rotas:
  GET  /           -> página do ÍCARO (icaro_uefs.html)
  GET  /saude      -> {"ok": true, "dispositivo": "cpu|cuda"}
  POST /falar      -> {"texto": "..."}  devolve audio/wav
"""
import io
import os
import re
import sys
import threading
import time
import wave

os.environ.setdefault("COQUI_TOS_AGREED", "1")  # licença CPML (uso não comercial)

PASTA = os.path.dirname(os.path.abspath(__file__))
PORTA = int(os.environ.get("ICARO_PORTA", "5002"))
IDIOMA = "pt"
LIMITE_FRASE = 180  # XTTS aceita ~200 caracteres por trecho em português


def log(msg):
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


try:
    import numpy as np
    import torch
    from flask import Flask, jsonify, request, send_file, Response
    from flask_cors import CORS
    from TTS.api import TTS
except Exception as erro:  # pragma: no cover
    print("\nFaltam bibliotecas. Rode primeiro o arquivo instalar.bat\nDetalhe:", erro)
    input("Pressione Enter para sair...")
    sys.exit(1)

# ---------------------------------------------------------------- modelo
DISPOSITIVO = "cuda" if torch.cuda.is_available() else "cpu"
if DISPOSITIVO == "cpu":
    torch.set_num_threads(max(1, (os.cpu_count() or 4) - 1))

log(f"Carregando XTTS-v2 em {DISPOSITIVO.upper()} (a 1ª vez baixa o modelo, aguarde)...")
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(DISPOSITIVO)
modelo = tts.synthesizer.tts_model
TAXA = 24000

# Calibração (gerada por calibrar_voz.py com 50 validações)
CAL = {}
try:
    import json
    with open(os.path.join(PASTA, "calibracao.json"), encoding="utf-8") as f:
        CAL = json.load(f)
    log(f"Calibração carregada: nota {CAL.get('nota_final')} em {CAL.get('validacoes')} validações.")
except FileNotFoundError:
    log("Sem calibracao.json: usando parâmetros padrão (rode calibrar_voz.bat para ajustar a voz).")
except Exception as e:
    log(f"Aviso: calibracao.json inválido ({e}). Usando padrão.")

PARAMS = {"temperature": 0.65, "repetition_penalty": 5.0, "top_p": 0.85, "top_k": 50, "speed": 1.0}
PARAMS.update(CAL.get("inferencia", {}))
POS = CAL.get("pos") or {}
GPT_COND = int(CAL.get("gpt_cond_len", 30))

referencias = [os.path.join(PASTA, n) for n in ("voz_referencia_limpa.wav", "voz_referencia.wav")]
if CAL.get("referencia"):
    nome = CAL["referencia"]
    referencias = [os.path.join(PASTA, "calibracao", f"ref_{nome}.wav"), os.path.join(PASTA, f"{nome}.wav")] + referencias
referencia = next((r for r in referencias if os.path.exists(r)), None)
if not referencia:
    log("ERRO: coloque voz_referencia.wav nesta pasta.")
    input("Pressione Enter para sair...")
    sys.exit(1)

log(f"Aprendendo a voz a partir de {os.path.basename(referencia)} ...")
gpt_latente, voz_embedding = modelo.get_conditioning_latents(
    audio_path=[referencia], gpt_cond_len=GPT_COND, gpt_cond_chunk_len=min(6, GPT_COND), max_ref_length=60
)
if POS.get("semitons") or POS.get("eq_db"):
    import metricas_voz
    log(f"Correção matemática ativa: tom {POS.get('semitons', 0):+.2f} semitons, EQ em {len(POS.get('eq_db') or [])} bandas.")
else:
    metricas_voz = None
log("Voz pronta.")

trava = threading.Lock()  # uma síntese por vez, na ordem de chegada


def dividir(texto):
    """Quebra em frases curtas que o XTTS fala bem."""
    texto = re.sub(r"[*#_`>|]", "", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    frases = re.split(r"(?<=[.!?;:])\s+", texto)
    saida = []
    for f in frases:
        while len(f) > LIMITE_FRASE:
            corte = f.rfind(",", 0, LIMITE_FRASE)
            if corte < 40:
                corte = f.rfind(" ", 0, LIMITE_FRASE)
            if corte < 1:
                corte = LIMITE_FRASE
            saida.append(f[: corte + 1].strip())
            f = f[corte + 1 :].strip()
        if f:
            saida.append(f)
    return saida


def sintetizar(texto):
    pedacos = []
    silencio = np.zeros(int(TAXA * 0.12), dtype=np.float32)
    for frase in dividir(texto):
        with torch.inference_mode():
            out = modelo.inference(
                frase, IDIOMA, gpt_latente, voz_embedding,
                enable_text_splitting=False, **PARAMS,
            )
        wav = out["wav"]
        wav = wav.cpu().numpy() if hasattr(wav, "cpu") else np.asarray(wav)
        pedacos += [wav.astype(np.float32), silencio]
    audio = np.concatenate(pedacos) if pedacos else silencio
    if metricas_voz is not None:
        audio = metricas_voz.aplicar(audio, TAXA, POS.get("semitons", 0.0), POS.get("eq_db"))
    audio = np.clip(audio, -1, 1)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(TAXA)
        w.writeframes((audio * 32767).astype(np.int16).tobytes())
    buf.seek(0)
    return buf


# ---------------------------------------------------------------- servidor
app = Flask(__name__)
CORS(app)


@app.get("/")
def pagina():
    arq = os.path.join(PASTA, "icaro_uefs.html")
    if not os.path.exists(arq):
        return Response("Coloque icaro_uefs.html nesta pasta.", 404)
    return send_file(arq, mimetype="text/html")


@app.get("/saude")
def saude():
    return jsonify(ok=True, dispositivo=DISPOSITIVO, referencia=os.path.basename(referencia))


@app.post("/falar")
def falar():
    dados = request.get_json(silent=True) or {}
    texto = str(dados.get("texto", "")).strip()[:1500]
    if not texto:
        return jsonify(erro="texto vazio"), 400
    t0 = time.time()
    with trava:
        audio = sintetizar(texto)
    log(f"Falou {len(texto)} caracteres em {time.time() - t0:.1f}s")
    return send_file(audio, mimetype="audio/wav")


if __name__ == "__main__":
    # aquecimento: a 1ª síntese é sempre mais lenta
    try:
        sintetizar("Sistema ÍCARO online.")
    except Exception as e:
        log(f"Aviso no aquecimento: {e}")
    log(f"ÍCARO no ar: abra http://localhost:{PORTA}  (feche esta janela para desligar)")
    if os.environ.get("ICARO_NAO_ABRIR") != "1":
        import webbrowser
        threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:{PORTA}")).start()
    app.run(host="127.0.0.1", port=PORTA, threaded=True)
