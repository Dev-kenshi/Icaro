# -*- coding: utf-8 -*-
"""
Matemática da voz do ÍCARO.

Mede numa gravação:
  - Tom (F0) pelo algoritmo pYIN: mediana em Hz e variação em semitons.
  - Ritmo: núcleos silábicos por segundo de fala (picos do envelope de energia).
  - Timbre: MFCC médio (coeficientes cepstrais) e LTAS (espectro médio em bandas de 1/3 de oitava).
  - Brilho: centroide espectral médio.

Compara duas vozes com uma pontuação de 0 a 100 e calcula a correção
(deslocamento de tom em semitons + equalização por banda) que aproxima uma da outra.
"""
import numpy as np
import librosa

SR = 22050
BANDAS = np.array([100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600,
                   2000, 2500, 3150, 4000, 5000, 6300, 8000], dtype=float)


def carregar(caminho, sr=SR):
    y, _ = librosa.load(caminho, sr=sr, mono=True)
    return normalizar(y)


def normalizar(y):
    y = np.asarray(y, dtype=np.float32)
    pico = np.max(np.abs(y)) + 1e-9
    return y / pico * 0.9


def trechos_com_fala(y, sr=SR, top_db=32):
    """Intervalos com fala (remove silêncios)."""
    return librosa.effects.split(y, top_db=top_db, frame_length=1024, hop_length=256)


def f0(y, sr=SR):
    f, voz, _ = librosa.pyin(y, fmin=60, fmax=320, sr=sr, frame_length=1024, hop_length=256)
    f = f[voz & np.isfinite(f)]
    if f.size < 10:
        return {"f0_hz": float("nan"), "f0_st_desvio": float("nan"), "voz_pct": 0.0}
    st = 12 * np.log2(f / np.median(f))
    return {
        "f0_hz": float(np.median(f)),
        "f0_st_desvio": float(np.std(st)),
        "voz_pct": float(voz.mean() * 100),
    }


def ritmo(y, sr=SR):
    """Sílabas por segundo de fala: conta os picos do envelope de energia (150-4000 Hz),
    cada pico é um núcleo silábico, e divide pelo tempo em que há fala."""
    from scipy.signal import find_peaks
    hop = 128
    S = np.abs(librosa.stft(y, n_fft=1024, hop_length=hop)) ** 2
    freqs = librosa.fft_frequencies(sr=sr, n_fft=1024)
    e = S[(freqs >= 150) & (freqs <= 4000)].sum(axis=0)
    fps = sr / hop
    k = max(1, int(0.04 * fps))
    w = np.hanning(2 * k + 1)
    e = np.convolve(e, w / w.sum(), mode="same")
    db = 10 * np.log10(e + 1e-12)
    limiar = db.max() - 30
    picos, _ = find_peaks(db, prominence=2.5, distance=int(0.08 * fps), height=limiar)
    fala = (db > limiar).sum() / fps
    return {"silabas_s": float(len(picos) / fala) if fala > 0.5 else float("nan"), "fala_s": float(fala)}


def ltas(y, sr=SR):
    """Espectro médio de longo prazo em bandas de 1/3 de oitava, em dB, centrado em 0."""
    partes = [y[a:b] for a, b in trechos_com_fala(y, sr)] or [y]
    z = np.concatenate(partes)
    S = np.abs(librosa.stft(z, n_fft=2048, hop_length=512)) ** 2
    P = S.mean(axis=1)
    freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
    out = []
    for fc in BANDAS:
        lo, hi = fc / 2 ** (1 / 6), fc * 2 ** (1 / 6)
        m = (freqs >= lo) & (freqs < hi)
        out.append(10 * np.log10(P[m].mean() + 1e-12))
    out = np.array(out)
    return out - out.mean()


def timbre(y, sr=SR):
    partes = [y[a:b] for a, b in trechos_com_fala(y, sr)] or [y]
    z = np.concatenate(partes)
    mf = librosa.feature.mfcc(y=z, sr=sr, n_mfcc=20)
    cent = librosa.feature.spectral_centroid(y=z, sr=sr)
    return {"mfcc": mf[1:].mean(axis=1), "centroide_hz": float(np.median(cent))}


def perfil(y, sr=SR):
    p = {}
    p.update(f0(y, sr))
    p.update(ritmo(y, sr))
    t = timbre(y, sr)
    p["centroide_hz"] = t["centroide_hz"]
    p["mfcc"] = t["mfcc"]
    p["ltas"] = ltas(y, sr)
    return p


def comparar(gen, ref, similaridade_locutor=None):
    """Pontuação 0-100 (100 = igual) e as distâncias de cada eixo."""
    d = {}
    d["tom_st"] = abs(12 * np.log2(gen["f0_hz"] / ref["f0_hz"])) if np.isfinite(gen["f0_hz"]) else 12.0
    d["entonacao_st"] = abs(gen["f0_st_desvio"] - ref["f0_st_desvio"]) if np.isfinite(gen["f0_st_desvio"]) else 6.0
    d["ritmo_pct"] = abs(gen["silabas_s"] / ref["silabas_s"] - 1) * 100 if np.isfinite(gen["silabas_s"]) else 100.0
    d["timbre_mfcc"] = float(np.linalg.norm(gen["mfcc"] - ref["mfcc"]) / np.sqrt(len(ref["mfcc"])))
    d["espectro_db"] = float(np.sqrt(np.mean((gen["ltas"] - ref["ltas"]) ** 2)))
    d["brilho_pct"] = abs(gen["centroide_hz"] / ref["centroide_hz"] - 1) * 100
    # cada eixo vira 0..1 (1 = igual) com escala de tolerância
    s = {
        "tom": np.exp(-d["tom_st"] / 2.0),
        "entonacao": np.exp(-d["entonacao_st"] / 1.5),
        "ritmo": np.exp(-d["ritmo_pct"] / 15.0),
        "timbre": np.exp(-d["timbre_mfcc"] / 12.0),
        "espectro": np.exp(-d["espectro_db"] / 4.0),
        "brilho": np.exp(-d["brilho_pct"] / 20.0),
    }
    pesos = {"tom": 0.18, "entonacao": 0.08, "ritmo": 0.12, "timbre": 0.17, "espectro": 0.10, "brilho": 0.05}
    total = sum(pesos[k] * s[k] for k in pesos)
    peso_total = sum(pesos.values())
    if similaridade_locutor is not None:
        # cosseno do embedding de locutor: 0,5 ruim, 0,9+ muito parecido
        s["locutor"] = float(np.clip((similaridade_locutor - 0.5) / 0.45, 0, 1))
        total += 0.30 * s["locutor"]
        peso_total += 0.30
    d["pontuacao"] = float(100 * total / peso_total)
    d["eixos"] = {k: round(float(v) * 100, 1) for k, v in s.items()}
    return d


def correcao(gen, ref, limite_st=3.0, limite_db=6.0):
    """Semitons e curva de EQ (dB por banda) que levam gen em direção a ref."""
    st = 0.0
    if np.isfinite(gen["f0_hz"]) and np.isfinite(ref["f0_hz"]):
        st = float(np.clip(12 * np.log2(ref["f0_hz"] / gen["f0_hz"]), -limite_st, limite_st))
    eq = np.clip(ref["ltas"] - gen["ltas"], -limite_db, limite_db)
    eq = np.convolve(np.pad(eq, 1, mode="edge"), [0.25, 0.5, 0.25], mode="valid")  # suaviza
    return {"semitons": round(st, 2), "eq_db": [round(float(x), 2) for x in eq]}


def aplicar(y, sr, semitons=0.0, eq_db=None):
    """Aplica tom (em semitons) e equalização por banda via STFT."""
    y = np.asarray(y, dtype=np.float32)
    if abs(semitons) >= 0.25:
        y = librosa.effects.pitch_shift(y, sr=sr, n_steps=float(semitons))
    if eq_db is not None and np.max(np.abs(eq_db)) >= 0.5:
        D = librosa.stft(y, n_fft=2048, hop_length=512)
        freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
        ganho_db = np.interp(np.log2(np.maximum(freqs, 1)), np.log2(BANDAS), np.asarray(eq_db, float),
                             left=eq_db[0], right=eq_db[-1])
        D *= (10 ** (ganho_db / 20))[:, None]
        y = librosa.istft(D, hop_length=512, length=len(y))
    return normalizar(y)


def resumo(p):
    return (f"tom {p['f0_hz']:.1f} Hz | entonação ±{p['f0_st_desvio']:.2f} st | "
            f"ritmo {p['silabas_s']:.2f} sílabas/s | brilho {p['centroide_hz']:.0f} Hz")
