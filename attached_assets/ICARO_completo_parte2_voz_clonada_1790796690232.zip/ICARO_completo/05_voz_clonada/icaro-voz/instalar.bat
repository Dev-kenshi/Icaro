@echo off
chcp 65001 >nul
title ICARO - Instalacao da voz clonada
cd /d "%~dp0"
echo ============================================
echo   ICARO - instalacao da voz clonada (XTTS-v2)
echo   Leva de 10 a 30 minutos na primeira vez.
echo ============================================
echo.

set PY=
for %%V in (3.11 3.12 3.10 3.13) do (
  if not defined PY (
    py -%%V -c "print()" >nul 2>&1 && set PY=py -%%V
  )
)
if not defined PY (
  echo [ERRO] Python 3.10 a 3.13 nao encontrado.
  echo Instale o Python 3.11 em https://www.python.org/downloads/release/python-3119/
  echo Marque a opcao "Add python.exe to PATH" e rode este arquivo de novo.
  pause
  exit /b 1
)
echo Usando: %PY%

if not exist venv (
  %PY% -m venv venv || (echo [ERRO] Nao consegui criar o ambiente. & pause & exit /b 1)
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip wheel

set TORCH_INDEX=https://download.pytorch.org/whl/cpu
where nvidia-smi >nul 2>&1 && set TORCH_INDEX=https://download.pytorch.org/whl/cu128
echo Instalando PyTorch de %TORCH_INDEX% ...
pip install torch==2.8.0 torchaudio==2.8.0 --index-url %TORCH_INDEX% || (echo [ERRO] Falha ao instalar o PyTorch. & pause & exit /b 1)

echo Instalando XTTS-v2 e servidor...
pip install coqui-tts==0.27.5 flask flask-cors soundfile || (echo [ERRO] Falha ao instalar o coqui-tts. & pause & exit /b 1)

echo.
echo Separando a voz da musica de fundo (opcional, melhora o clone)...
pip install demucs >nul 2>&1 && python separar_voz.py

echo.
echo ============================================
echo   Instalacao concluida!
echo   Agora de dois cliques em calibrar_voz.bat e depois em iniciar_icaro.bat
echo ============================================
pause
