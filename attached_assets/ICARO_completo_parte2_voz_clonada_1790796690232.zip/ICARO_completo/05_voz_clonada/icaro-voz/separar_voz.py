# -*- coding: utf-8 -*-
"""Opcional: separa a voz da musica de fundo do video (Demucs) e gera voz_referencia_limpa.wav."""
import os, sys, subprocess
PASTA = os.path.dirname(os.path.abspath(__file__))
orig = os.path.join(PASTA, "audio_completo_video.wav")
saida = os.path.join(PASTA, "voz_referencia_limpa.wav")
if os.path.exists(saida):
    print("voz_referencia_limpa.wav ja existe. Pulando."); sys.exit(0)
try:
    subprocess.run([sys.executable, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs",
                    "-o", os.path.join(PASTA, "separado"), orig], check=True)
    import soundfile as sf, numpy as np
    voc = os.path.join(PASTA, "separado", "htdemucs", "audio_completo_video", "vocals.wav")
    a, sr = sf.read(voc)
    if a.ndim > 1: a = a.mean(axis=1)
    trecho = a[int(13 * sr): int(30.5 * sr)]
    trecho = trecho / (np.abs(trecho).max() + 1e-9) * 0.8
    sf.write(saida, trecho.astype("float32"), sr)
    print("OK: voz_referencia_limpa.wav criada.")
except Exception as e:
    print("Nao foi possivel separar a voz (seguindo com voz_referencia.wav):", e)
