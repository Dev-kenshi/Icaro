# Ícaro: atualização "apresentador + streaming"

Base: commit `e5eba37` (main do GitHub "Respostas mais longas"). Esta atualização é **um commit** em cima dele.

## O que entra
| Arquivo | Mudança |
|---|---|
| `artifacts/api-server/src/routes/ai.ts` | nova rota `POST /api/ai/chat/stream` (SSE: meta → delta → done); persona de apresentador |
| `artifacts/api-server/src/lib/groq.ts` | `streamAnswer()` em streaming; `reasoning_effort: low` no gpt-oss, com nova tentativa sem ele se a Groq recusar |
| `artifacts/api-server/src/lib/presenter.ts` | **novo**: estilo de apresentador de palco + ganchos nas respostas prontas |
| `artifacts/api-server/src/lib/cerebro/icaro-brain.d.cts` | tipos `cat`, `score`, `thoughts` |
| `artifacts/icaro/src/lib/speech.ts` | `speakStream()`: fala cada frase assim que chega (ganchos curtos não travam a fila) |
| `artifacts/icaro/src/pages/stage.tsx` | palco usa o streaming com a Groq; frase de espera imediata; se o streaming falhar, volta sozinho para `/ai/chat` |
| `scripts/src/validate-stream.ts` + `scripts/package.json` | **novo** teste: 19 verificações com a Groq simulada |

## Como aplicar (escolha UM)

**A. Pelo Agent do Replit (mais fácil).** Envie a pasta `icaro-atualizacao/` para a raiz do projeto e cole o `PROMPT_REPLIT.md` no Agent.

**B. Pelo GitHub.** A branch já está lá: `icaro-apresentador-streaming`. Abra e faça merge em
https://github.com/Dev-kenshi/Icaro/pull/new/icaro-apresentador-streaming
e depois, no Shell do Replit:
```
git pull github main
```

**C. Manual pelo Shell do Replit**, com a pasta enviada:
```
git am icaro-atualizacao/icaro-apresentador-streaming.patch
```
Se der conflito: copie o conteúdo de `icaro-atualizacao/arquivos/` por cima do projeto (mesmos caminhos).

## Testar
```
pnpm run typecheck
pnpm --filter @workspace/scripts run validate:stream     # 19 ok
pnpm --filter @workspace/scripts run validate:all
```
No palco: pergunte algo novo (ex.: "como a IA pode ajudar na auditoria?"). Ele diz "Certo." na hora e começa a resposta na 1ª frase, sem esperar o texto inteiro.

## Depois de testar
1. **Republicar** (precisa de permissão de Publicador).
2. Em Publicação → Ajustar configurações: trocar **Autoscale → Reserved VM**. No Autoscale o servidor "dorme" e a 1ª pergunta depois de um tempo parado demora.

## Não testado ainda
Groq real, voz e rosto no navegador: medir no palco depois de aplicar.
