Aplique a atualização que está em icaro-atualizacao/ (veja icaro-atualizacao/LEIA-ME.md). Não reescreva nem "melhore" o código dela.

1. Tente: git am icaro-atualizacao/icaro-apresentador-streaming.patch
   - Se falhar: git am --abort e copie cada arquivo de icaro-atualizacao/arquivos/ para o mesmo caminho na raiz do projeto, substituindo o atual.
2. Rode e me mostre a saída:
   - pnpm run typecheck
   - pnpm --filter @workspace/scripts run validate:stream   (deve dar 19 ok)
   - pnpm --filter @workspace/scripts run validate:all
3. Reinicie os workflows.
4. Com a GROQ_API_KEY real, logado, faça POST /api/ai/chat/stream com {"provider":"groq","persona":"icaro","question":"como a IA pode ajudar na auditoria?","history":[],"dataset":null} e me diga em quantos ms chegaram o evento meta, o 1º delta e o done, e o texto final.
5. Faça commit "Ícaro apresentador: streaming e fala frase por frase" e push para o GitHub (main).
6. NÃO publique: eu reviso e publico depois.
7. Remova a pasta icaro-atualizacao/ depois de aplicar (não deve ir para o deploy).
