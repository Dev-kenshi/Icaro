# ÍCARO · Pacote Cinema

Ordem para colar no Replit Agent (um por vez, testando entre eles):
1. **PROMPT_3_CEREBRO_ECONOMIA.md**: cérebro local + economia de tokens. Vem primeiro porque gera os "pensamentos" reais.
2. **PROMPT_1_HOLOGRAMA_CINEMA.md**: interface de cinema + Fluxo de Pensamento Holográfico.
3. **PROMPT_2_ICARO_PALESTRANTE.md**: partes A e B são para você (gerar imagem, vídeo e modelo 3D); a parte C vai para o Agent.

Envie a pasta `icaro-cinema/` inteira para a raiz do projeto no Replit.

Teste do cérebro: `node icaro-cinema/cerebro/test.js` (265/265 exemplos, 18/18 paráfrases, ~0,15 ms).

## Conferir antes do ITCONT (`"verificar": true` no banco)
Dados que mudam com o tempo ou que eu não consegui confirmar na fonte oficial:
- curso de Contábeis da UEFS: departamento, duração, turno, forma de ingresso, grade;
- endereço e histórico da UEFS; ITCONT e Contador do Amanhã (nomes e créditos);
- MEI R$ 81 mil, faixas do Simples/Presumido, Exame de Suficiência;
- IR: isenção até R$ 5 mil (Lei 15.270/2025);
- reforma: ano-teste 2026, alíquota de referência, cashback;
- Feira: população, prefeito, datas históricas, Micareta.
