# PROMPT 2 · ÍCARO PALESTRANTE: corpo inteiro, andando e gesticulando

Este arquivo tem **3 partes**:
- **A.** Prompts de imagem e vídeo para gerar o Ícaro de corpo inteiro (referência visual e abertura cinematográfica).
- **B.** Como obter o modelo 3D animável (passo a passo humano, cerca de 1 h).
- **C.** O prompt para o Replit Agent montar o "Modo Palestra" em tempo real.

**Por que 3D em tempo real e não vídeo?** Vídeo gerado não reage à fala: cada resposta é diferente e os cortes entre clipes aparecem (o mesmo defeito do rosto antigo). Um modelo 3D com animações faz o Ícaro andar, parar, gesticular e mexer os lábios **sincronizados com qualquer resposta**, sem cortes. O vídeo gerado fica só para a abertura e para o material de divulgação.

---

## A. Prompts de geração (imagem e vídeo)

### A1. Retrato de corpo inteiro (Midjourney, Ideogram, Flux, ChatGPT Imagem ou Leonardo)
Use a imagem atual do rosto como **referência de personagem** (character reference / `--cref`), para manter a mesma identidade.
```
Full-body photorealistic portrait of the same man from the reference image: Brazilian, early 30s,
short dark textured hair swept back, well-groomed short beard, confident warm smile, athletic build.
Wearing a modern slim-fit charcoal suit with a subtle cyan circuit-pattern lining, open collar white shirt,
minimalist smartwatch. Standing on a dark keynote stage, three-quarter view, one hand open in an explaining
gesture. He is a holographic projection: translucent cyan-blue light body, fine glowing wireframe mesh visible
on skin and clothes, horizontal scanlines, soft particle dust rising from his feet, rim light, volumetric haze,
black background with distant star particles. Cinematic, anamorphic lens, 35mm, shallow depth of field,
ultra detailed, 8k. --ar 9:16
```
Gere também: **frente neutra (T-pose leve, braços a 45°)**, **perfil** e **costas**, com fundo cinza liso e sem efeito holográfico. Essas 3 imagens servem para criar o modelo 3D (parte B).

### A2. Vídeo de abertura (Kling 2.x, Google Veo 3, Runway Gen-4 ou Hailuo), 8 a 10 s
Use a imagem A1 como primeiro quadro (image-to-video).
```
Cinematic keynote opening. A dark futuristic stage with a reflective floor and a holographic grid.
A beam of cyan light hits the floor and the holographic man materializes from rising particles, scanline by scanline,
from feet to head. He walks confidently toward the camera with a natural gait, stops at center stage, looks into the lens,
opens both arms in a welcoming gesture and smiles. Camera: slow dolly-in from wide shot to medium shot, slight low angle.
Lighting: cyan rim light, volumetric haze, lens flares, deep blacks. Mood: Blade Runner 2049 meets Apple keynote.
Photorealistic, 24fps, film grain, no text.
```
**Negativo:** `distorted hands, extra fingers, morphing face, jitter, cartoon, text, watermark, sliding feet`.

### A3. Clipes curtos de divulgação (opcional, 5 s cada)
- *"...he raises one finger and counts on his fingers while explaining, nodding slightly"* (enumerar)
- *"...he points at a floating holographic chart that appears beside him showing 'IBS + CBS', the chart lights up"* (reforma)
- *"...he places a hand on his chest and bows his head slightly in thanks"* (encerramento)

---

## B. Modelo 3D animável (faça uma vez, cerca de 1 h)
1. **Avatar realista com rosto:** crie em **Avaturn** (avaturn.me, a partir de fotos do rosto) ou **Character Creator / Reallusion Headshot**. Exporte em **GLB** com **blendshapes ARKit** (52 morphs: `jawOpen`, `mouthFunnel`, `mouthPucker`, `mouthClose`, `mouthSmileLeft/Right`, `eyeBlinkLeft/Right`, `browInnerUp`…) e esqueleto **compatível com Mixamo**. Vista o terno escuro.
   - Sem blendshapes, a boca não mexe; confira isso no visualizador antes de seguir.
2. **Animações:** em **mixamo.com** (gratuito), faça upload do avatar, ou use o próprio esqueleto exportado, e baixe em **FBX, "Without Skin", 30 fps**:
   `Idle` (ou *Standing Idle*), `Breathing Idle`, `Walking` (marque **In Place**), `Start Walking`, `Stop Walking`, `Talking` (2 ou 3 variações), `Standing Greeting` (acenar), `Pointing Forward`, `Explaining`/`Talking` com mãos abertas, `Shrugging` (encolher ombros), `Hand Raising`, `Acknowledging`, `Thoughtful Head Shake`, `Thinking`, `Head Nod Yes`, `Bow` ou `Thankful`, `Counting` (se não houver, use *Talking* com braço direito).
3. Converta tudo para um único **`icaro-body.glb`** no **Blender** (importe o GLB e cada FBX, renomeie as actions como `idle`, `walk`, `talk_1`…, e exporte GLB com "Animations" e "Shape Keys"), ou mande os FBX para o Replit e deixe o Agent carregar com `FBXLoader`. Comprima com `gltf-transform optimize icaro-body.glb out.glb --texture-compress webp` (alvo: menos de 15 MB).
4. Suba `icaro-body.glb` em `public/models/` no Replit.

> Atalho sem Blender: no Replit Agent, peça para carregar o GLB do avatar e cada FBX do Mixamo separadamente com `FBXLoader`, reaproveitando as `AnimationClip` no mesmo esqueleto (os nomes de ossos `mixamorig:*` precisam bater).

---

## C. Prompt para o Replit Agent: "Modo Palestra"

> Cole abaixo da linha. Pré-requisitos: `public/models/icaro-body.glb` (ou GLB + FBXs) e o barramento `icaroBus` do PROMPT 1.

---

Crie o **Modo Palestra** do Ícaro: uma versão de **corpo inteiro, em 3D, em tempo real**, em que ele anda pelo palco e gesticula como um palestrante de TED enquanto fala, com lábios sincronizados à voz. Ele convive com o modo rosto atual: um botão **"🎤 Palestra / 🙂 Rosto"** alterna os dois, e `?modo=palestra` abre direto nele.

### Regras
1. **three.js** (r16x ou mais recente) com `GLTFLoader` (+ `FBXLoader` se vierem FBX), `AnimationMixer` e `DRACOLoader`/`KTX2Loader` se o arquivo vier comprimido. Nada de Unity ou Unreal no navegador.
2. **Reaproveite tudo do pipeline atual:** STT, `IcaroBrain`, LLM, TTS com timestamps (`/api/tts-ts`), legendas e o `icaroBus`. O Modo Palestra é só outro "corpo" escutando os mesmos eventos.
3. **Zero cortes:** toda troca de animação é por `crossFadeTo` (0,35 a 0,5 s) com `warp` quando os ritmos diferem. É proibido `stop()` seco.
4. **Pés não deslizam:** use a animação de andar "In Place" e mova a raiz do personagem por código, com velocidade casada com a passada (calibre `walkSpeed` até o pé "colar" no chão, tipicamente 1,1 a 1,4 m/s na escala do modelo).
5. Mesma identidade visual do holograma: o personagem usa **material holográfico** (abaixo), em palco escuro com grade e partículas.

### Cena e câmera
- Palco: piso reflexivo escuro (`MeshStandardMaterial` com roughness 0,15 + `Reflector` opcional no desktop), grade holográfica, névoa exponencial azul, 2 luzes de recorte ciano (atrás, uma de cada lado) e 1 luz frontal fraca.
- Marcas de palco: `ESQ (-1.6, 0)`, `CENTRO (0, 0)` e `DIR (1.6, 0)`, com o público na direção da câmera (+z).
- **Câmera cinematográfica** com 3 enquadramentos, interpolados com *easing* em 1,2 s:
  - `wide` (corpo inteiro com chão, na entrada e nas caminhadas);
  - `medium` (da cintura para cima, padrão de fala);
  - `close` (busto, em respostas curtas de até 8 s e em momentos de ênfase).
  - Leve *handheld* (ruído Perlin de 0,3° de amplitude) e *dolly* lento durante a fala.
- Pós-processamento (só no desktop, desliga no celular ou em FPS baixo): `UnrealBloomPass` (strength 0,9), vinheta e grão de filme sutil.

### Material holográfico (shader)
Aplique via `onBeforeCompile` sobre o material original, preservando as texturas da pele e da roupa:
- *fresnel/rim* ciano forte nas bordas da silhueta;
- scanlines horizontais rolando (posição em espaço de mundo, para não "grudar" no corpo);
- 15 a 25% de transparência no corpo e 0% no rosto (o rosto precisa ser legível);
- *flicker* raro e um "glitch" de deslocamento de 1 frame na troca de estado;
- partículas subindo dos pés (`Points` com 300 unidades).

Deixe um *toggle* `holo=0` que mostra o humano realista sem efeito, para comparação.

### Máquina de estados do corpo
```
ENTRADA → (anda de ESQ até CENTRO, para, acena) → IDLE
IDLE ⇄ OUVINDO ⇄ PENSANDO → FALANDO → IDLE
```
| Estado | Animação base | Comportamento |
|---|---|---|
| IDLE | `idle` / `breathing_idle` alternando a cada 8 a 14 s | olhar varre a plateia devagar (rotação de cabeça e pescoço por código, ±15°) e pisca |
| OUVINDO | `idle` + cabeça inclinada 6° na direção da câmera | se o volume do microfone sobe, acena levemente com a cabeça (`head_nod` aditivo, peso 0,3) |
| PENSANDO | `thinking` (mão no queixo) ou `thoughtful_head_shake` | olhar para cima e para o lado; se o PROMPT 1 estiver ativo, os cartões de pensamento orbitam **ao redor da cabeça dele** |
| FALANDO | `talk_*` + gestos (abaixo) | lábios pela fala, caminhadas entre ideias |

**Entrada:** na primeira ativação do modo, rode a coreografia de entrada (materializar com scanline dos pés à cabeça em 1,2 s, `start_walking`, `walk` até o centro, `stop_walking`, `greeting`) com câmera `wide` → `medium`.

### Gestos inteligentes (coreografia guiada pelo texto)
Os gestos são **escolhidos a partir do conteúdo da resposta** e sincronizados com as palavras (evento `word` com tempo):
1. Se a resposta veio do banco (`IcaroBrain`, `r.gestures`), use esses gestos na ordem, um por frase: `acenar`, `abrir_bracos`, `enumerar`, `apontar_publico`, `apontar_cabeca`, `mao_no_peito`, `duas_maos` (comparar), `balanca` (pesar), `dividir`, `linha_do_tempo` (mão varrendo da esquerda para a direita), `alerta` (dedo indicador para cima), `negar`, `encolher_ombros`, `sorrir`, `comemorar`.
2. Senão, aplique estas regras por frase (PT-BR, em texto normalizado):
   - números/ordinais ("primeiro", "segundo", "três", "por cento") → `enumerar` (conta nos dedos, um dedo por item);
   - "mas", "porém", "por outro lado", "enquanto" → `duas_maos`;
   - "você", "vocês", "o público", "quem" → `apontar_publico`;
   - "cuidado", "atenção", "importante", "nunca" → `alerta`;
   - "eu", "nós", "nosso" → `mao_no_peito`;
   - datas e anos ("2026", "até 2033") → `linha_do_tempo`;
   - "não" no início da frase → `negar`;
   - pergunta retórica (frase terminando em "?") → `abrir_bracos` + sobrancelhas levantadas;
   - nenhuma regra → alterna `talk_1`/`talk_2`/`talk_3` com variação de velocidade de 0,9 a 1,1.
3. **Timing:** o gesto começa **150 a 250 ms antes** da palavra-gatilho, como fazem os humanos. Mínimo de 1,8 s entre gestos grandes. Nunca repita o mesmo gesto 2 vezes seguidas.
4. Gestos são tocados como **camada sobre o tronco** (máscara só nos ossos dos braços, mãos, ombros e coluna superior, com `AnimationUtils.subclip` + filtragem de tracks), para que a base de fala/andar continue nas pernas.

### Andar enquanto fala (presença de palco)
- Resposta com mais de 3 frases → ao fim da 2ª frase, ele caminha para outra marca (CENTRO → DIR ou ESQ), **continuando a falar** (pernas com `walk`, braços com `talk` em menor peso). Ao chegar, gira o tronco para a plateia (*slerp* de 0,6 s).
- No máximo uma caminhada a cada 12 s. Na última frase, volta ou permanece no CENTRO.
- Câmera: `medium` → `wide` suave durante a caminhada e de volta a `medium` ao parar.

### Lábios, rosto e olhos
- Use os **mesmos visemas PT-BR** do pacote `icaro-humano` (`visemes-ptbr.js`), gerados a partir dos timestamps por caractere do `/api/tts-ts`, mapeados em blendshapes ARKit:
  - `A` → jawOpen 0,55 + mouthFunnel 0,1
  - `E/É` → jawOpen 0,35 + mouthStretch 0,3
  - `I` → jawOpen 0,2 + mouthSmile 0,35
  - `O/Ó` → jawOpen 0,4 + mouthFunnel 0,45
  - `U` → jawOpen 0,15 + mouthPucker 0,7
  - `M/B/P` → mouthClose 0,9 (lábios fechados por pelo menos 60 ms)
  - `F/V` → mouthRollLower 0,5 + mouthUpperUp 0,2
  - `L/N/T/D` → jawOpen 0,2 + tongueOut 0
  - `S/Z/X/CH` → jawOpen 0,1 + mouthStretch 0,4
  - `R` → jawOpen 0,25
  - silêncio → tudo a 0 em 80 ms
- Suavização *critically damped* (constante de 40 a 60 ms) entre visemas. A boca fica **parada fora do estado FALANDO**.
- Piscar a cada 2 a 6 s (aleatório), e mais vezes ao terminar frases. Sobrancelhas sobem em ênfase (palavras em CAIXA ou números).
- **Olhar:** os olhos e a cabeça seguem a câmera com atraso (*lerp*); no estado PENSANDO, o olhar desvia para cima e para o lado.
- Microexpressões: um sorriso leve (mouthSmile 0,15) em saudação, agradecimento e frases positivas.

### Responsividade e desempenho
- Celular: sem bloom e sem reflexo, sombra simples (blob), `pixelRatio` no máximo 1,5, enquadramento padrão `medium` (corpo inteiro só na entrada). Em celular em pé, a câmera fica mais distante para caber da cabeça aos joelhos.
- Pré-carregue o GLB com barra de progresso holográfica ("Materializando o Ícaro… 63%"). Se falhar o carregamento ou o WebGL, volte automaticamente ao modo rosto.
- Meta: 60 fps no desktop, 30 fps ou mais no celular. Pause o loop com `document.hidden`.

### Critérios de aceite
1. `?modo=palestra`: ele entra andando, sem deslizar os pés, para no centro e acena.
2. "Quais os regimes tributários?" → conta nos dedos ao listar os três regimes, caminha para uma marca no meio da resposta e volta ao centro.
3. "Obrigado, Ícaro" → mão no peito e sorriso.
4. Lábios fecham em "m/b/p" e ficam parados em PENSANDO e IDLE.
5. Nenhuma troca de animação com salto visível (grave 30 s de tela e confira quadro a quadro).
6. Em 375×812 o personagem aparece inteiro do topo da cabeça aos joelhos, sem cortar.
7. Botão Palestra/Rosto alterna sem recarregar a página e sem perder a conversa.

Entregue a lista de arquivos, como trocar o modelo e as animações, e os resultados dos 7 critérios.
