# PROMPT 1 · ÍCARO "NÍVEL CINEMA": interface holográfica + pensamentos visíveis

> Cole tudo abaixo da linha no **Replit Agent** do projeto `icaro-inteligencia-e-operacoes`.
> Pré-requisito: a pasta `icaro-cinema/` enviada para a raiz do projeto (contém `cerebro/`).

---

Você vai transformar a interface do **Ícaro** (assistente holográfico do projeto Contador do Amanhã · UEFS) numa experiência com estética de **cinema de ficção científica**, nível *Blade Runner 2049*, *Oblivion*, *Homem de Ferro* (JARVIS) e *Minority Report*, sem perder desempenho em celular.

A peça central é nova: o **Fluxo de Pensamento Holográfico**. Enquanto o Ícaro pensa, o público **vê os pensamentos dele surgindo no ar** como fragmentos holográficos que se conectam numa constelação e, quando ele começa a falar, se dissolvem em partículas que fluem para o rosto.

## Regras invioláveis
1. **Não quebre o que funciona.** O rosto atual (canvas do `IcaroAvatar`, se existir, ou a imagem/vídeo atual), a voz, o microfone, o teclado, "Ativar áudio" e "Legendas" continuam funcionando com a mesma lógica. Você só **envolve** o rosto com novas camadas visuais.
2. **Pensamentos reais, não teatro aleatório.** Os fragmentos exibidos vêm de eventos reais do pipeline (`thoughts` do `IcaroBrain`, etapa de STT, chamada ao LLM, TTS). Texto inventado ou lorem ipsum é proibido.
3. **60 fps em notebook comum e 30 fps ou mais em celular intermediário.** Use um único `requestAnimationFrame` para todas as camadas, limite `devicePixelRatio` a 2 e tenha níveis de qualidade automáticos.
4. **Responsivo de verdade:** de 360 px (celular em pé) até telão 4K. Nada pode cortar o rosto ou os botões. Nenhuma barra de rolagem horizontal.
5. **Acessível:** respeite `prefers-reduced-motion`, garanta contraste AA nos textos e foco visível nos botões; as legendas continuam disponíveis.
6. Sem bibliotecas pesadas além de **three.js** (opcional, só para a camada de pensamentos 3D) e **GSAP** (opcional). Shaders podem ser GLSL inline. Todos os assets são gerados por código; não use imagens de banco.

## Passo 0: mapear antes de editar
Liste num comentário no topo do componente principal:
- onde ficam os estados do HUD (ON-LINE / OUVINDO / PENSANDO / FALANDO) e como mudam;
- onde chega a pergunta do usuário (voz → texto e teclado);
- onde a resposta é pedida ao LLM e onde a voz é tocada;
- o componente/elemento do rosto e o container circular;
- a linha de onda (waveform) atual.

Crie um **barramento de eventos único** (`icaroBus`, um `EventTarget`) com os eventos:
`state` ({idle|listening|thinking|speaking}), `transcript` (texto parcial/final), `thought` ({k, t, c?}), `answer:start`, `word` ({word, t}), `answer:end`, `audio:level` (0..1). Todas as camadas visuais escutam **só** esse barramento.

## Linguagem visual (design system)
Defina tokens CSS em `:root`:
```
--holo-cyan: #39d5ff;  --holo-ice: #bff4ff;  --holo-deep: #0a5cff;
--holo-amber: #ffb347 (só para alertas ou "verificar");  --holo-violet: #8b7bff (pensamento profundo);
--bg-0: #000308; --bg-1: #020b16;  --glass: rgba(57,213,255,.06);  --line: rgba(57,213,255,.35);
--font-ui: "Rajdhani", "Orbitron" para títulos curtos; "JetBrains Mono" para dados; "Inter" para legenda.
```
Carregue as fontes pelo Google Fonts com `display=swap`.

Cada estado tem uma assinatura própria de cor e movimento:
| Estado | Cor dominante | Anéis do HUD | Rosto | Partículas |
|---|---|---|---|---|
| idle | ciano suave | giro lento, 1 volta/40 s | respiração de brilho 4 s | deriva lenta |
| listening | ciano intenso | anel interno pulsa com o volume do microfone | leve inclinação "atenta" | puxadas para o centro |
| thinking | violeta + ciano | segmentos girando em sentidos opostos, ticks "processando" | brilho na testa (ponto de origem dos pensamentos) | orbitam rápido |
| speaking | gelo/branco-ciano | anel externo vira um equalizador radial com o áudio real | sem efeito extra (o rosto fala) | pulsam com a fala |

## Camadas (de trás para frente)
1. **Espaço profundo:** campo estelar com 3 planos de paralaxe (move com o mouse/giroscópio, no máximo 12 px), névoa volumétrica azul muito sutil (gradiente radial animado) e, raramente, uma "estrela de dados" cruzando.
2. **Grade holográfica do chão:** grade em perspectiva que some no horizonte, na altura da linha de onda, com linhas que acendem quando ele fala.
3. **HUD circular do rosto (substitui os anéis atuais):** 3 anéis SVG concêntricos com marcações tipo mira (ticks a cada 6°, rótulos em mono minúsculos como `ICR-01 · SYNC 98%` e `LAT 0.42s`, com dados reais de latência), arcos de progresso durante o pensamento e um anel equalizador radial (64 barras) alimentado pelo `AnalyserNode` da voz.
4. **Rosto holográfico (efeitos por cima do rosto atual, via shader ou CSS):** scanlines horizontais finas rolando, borda com *fresnel/rim light* ciano, aberração cromática de 1 a 2 px nas bordas, *flicker* raro (1 a cada 8 a 15 s, com duração de 80 ms) e um *glitch* curto na troca de estado. Mantenha o rosto **nítido no centro**: os efeitos ficam nas bordas.
5. **FLUXO DE PENSAMENTO HOLOGRÁFICO (a estrela do show):** detalhado abaixo.
6. **Waveform cinematográfica:** substitua a linha atual por 3 ondas sobrepostas (glow, núcleo e eco atrasado) desenhadas a partir do áudio real; enquanto ele ouve, use o microfone; enquanto fala, use a voz dele.
7. **Legenda cinema:** palavra a palavra, com a palavra atual em `--holo-ice` e glow e as anteriores esmaecendo. Máximo de 2 linhas e fundo de vidro fosco.
8. **Controles:** os botões atuais redesenhados em vidro holográfico (borda gradiente animada, *hover* com varredura de luz). O microfone ganha anel de "carga" no estado listening e onda de choque ao tocar.

## Fluxo de Pensamento Holográfico: especificação
Ao entrar em `thinking`, escute os eventos `thought` e renderize cada um como um **fragmento holográfico**:
- **Origem:** um ponto de luz na testa do rosto. Cada fragmento nasce ali como um ponto e se expande para um cartão.
- **Cartão:** painel de vidro com borda de 1 px `--line`, cantos chanfrados (clip-path), ícone mínimo por tipo e texto em mono com efeito *decode* (letras aleatórias que "resolvem" no texto real em 400 ms). Tamanho máximo de 260 px, ou 70 vw no celular.
- **Tipos (`k`)** com estilo próprio:
  - `escuta` → "Pergunta recebida" + a transcrição final em itálico;
  - `termos` → chips com os termos-chave, aparecendo um a um;
  - `hipotese` → título da hipótese + **barra de confiança** (`c`) que enche; a de maior confiança brilha mais, as outras ficam translúcidas;
  - `memoria` → ícone de ciclo, "Continuando o assunto";
  - `consulta` → anel girando, "Consultando o modelo de IA", com cronômetro real em ms;
  - `resposta` → selo verde-ciano "Base própria · 92%" ou "IA verificada".
- **Coreografia 3D:** os cartões orbitam o rosto num **arco/elipse em perspectiva** (three.js com `CSS3DRenderer`, ou CSS `transform: translate3d/rotateY` puro), em camadas de profundidade: os mais antigos recuam e desfocam (`filter: blur`), os novos vêm à frente.
- **Constelação:** filamentos de luz (linhas com gradiente e partículas correndo por elas) ligam a origem a cada cartão e conectam hipóteses ao cartão `resposta` vencedor.
- **Desfecho:** em `answer:start`, os cartões perdedores se desfazem em pó; o vencedor se comprime num feixe que viaja até a boca/rosto e "acende" o anel equalizador. Duração total de 600 a 900 ms. Depois disso, o rosto fica limpo para falar.
- **Ritmo mínimo:** se o pipeline for rápido demais (resposta local em menos de 5 ms), mostre os pensamentos com 140 ms entre cada um, com no máximo cerca de 900 ms no total. O público precisa **ver** que ele pensou, mas nunca esperar à toa. Se o LLM demorar, os cartões ficam "respirando" e o cartão `consulta` mostra o tempo correndo.
- **Celular (< 768 px):** sem órbita 3D. Os cartões sobem em coluna acima do rosto (estilo *feed* holográfico), no máximo 3 visíveis, sem blur.
- **`prefers-reduced-motion`:** os cartões aparecem com *fade*, sem órbita e sem decode.
- Botão discreto **"👁 Pensamentos"** ao lado de "Legendas" para ligar e desligar (padrão: ligado). Guarde a preferência em `localStorage` dentro de try/catch.

## Sequência de abertura (boot cinematográfico, 3 s, pulável)
Na primeira visita da sessão: tela preta → uma linha horizontal de luz se abre → a grade do chão se desenha → os anéis do HUD montam segmento por segmento com som sutil de "servo" (só se o áudio estiver ativado) → o rosto materializa por scanline de baixo para cima → texto `ÍCARO · SISTEMA ONLINE` em decode → estado idle. Toque ou tecla pula a sequência. Não repita na mesma sessão (`sessionStorage`).

## Responsividade
- **Desktop/telão (≥ 1200 px):** rosto com ~44 vh, pensamentos em órbita completa, HUD com rótulos de dados.
- **Tablet (768 a 1199 px):** órbita reduzida (raio de 0,8) e rótulos de dados só nos anéis.
- **Celular em pé (< 768 px):** rosto com ~38 vh no topo, pensamentos em feed acima ou ao lado, waveform fina, controles fixos embaixo com `env(safe-area-inset-bottom)`, alvos de toque ≥ 44 px.
- **Celular deitado:** rosto à esquerda e pensamentos à direita.
- **Modo totem/telão:** `?totem=1` esconde cursor e controles secundários, aumenta legenda e volta ao idle após 60 s sem interação, com uma "respiração" de convite: "Toque para falar com o Ícaro".

## Desempenho (obrigatório)
- Um único loop `rAF` para tudo. Pause quando `document.hidden`.
- Detecção de qualidade: meça o tempo de frame nos primeiros 2 s. Acima de 22 ms, reduza o nível: menos partículas (de 1200 para 400 para 150), sem blur, sem aberração cromática, sem three.js (cai para CSS puro).
- Partículas em `Float32Array`, sem criar objetos por frame. Use canvas 2D para estrelas e partículas, SVG só para o HUD e DOM/CSS3D para os cartões (no máximo 12 vivos).
- Tempo até a primeira interação abaixo de 2 s no 4G: carregue three.js e as fontes de forma preguiçosa, depois do primeiro paint.

## Critérios de aceite (teste e mostre cada um)
1. Pergunta "o que é split payment?" → aparecem os cartões escuta, termos, 3 hipóteses com barras, e resposta "Base própria". O vencedor vira feixe e ele fala. Nenhuma chamada ao LLM na aba Network.
2. Pergunta fora da base ("qual a capital da Austrália?") → cartão `consulta` com cronômetro real → resposta do LLM.
3. Os anéis mudam de assinatura nos 4 estados, e o equalizador radial só se mexe com áudio real.
4. Em 375×812 nada corta, nada rola na horizontal e os pensamentos ficam em feed.
5. Com "reduzir movimento" ligado no sistema, não há órbita nem decode.
6. FPS ≥ 55 no desktop durante o pensamento (meça com `performance.now()` e registre no console em modo `?debug=1`).
7. O boot aparece uma vez por sessão e pode ser pulado.

Ao terminar, me entregue: a lista de arquivos alterados, o resultado dos 7 critérios e como ligar e desligar cada camada.
