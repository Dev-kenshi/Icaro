/* ÍCARO · Cérebro local (banco de respostas pré-programadas)
 * Responde sem gastar token quando a pergunta já está no banco.
 * Funciona em Node (require) e no navegador (window.IcaroBrain).
 *
 *   const brain = IcaroBrain.create(bancoJson, { now: () => new Date() });
 *   const r = brain.answer('o que é o split payment?');
 *   r.mode  -> 'local' | 'hint' | 'llm'
 *   r.text  -> resposta pronta (mode 'local')
 *   r.context -> trechos curtos para mandar ao LLM (mode 'hint')
 *   r.thoughts -> etapas reais do raciocínio, para o "Fluxo de Pensamento" holográfico
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.IcaroBrain = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const STOP = new Set(('a o as os um uma uns umas de da do das dos d em no na nos nas num numa por pelo pela pelos pelas ' +
    'para pra pro com sem sob sobre e ou que se me te lhe nos vos eu tu ele ela eles elas ' +
    'meu minha seu sua isso isto aquilo esse essa este esta ai la aqui ja mais muito muita bem tambem ' +
    'e eh foi ser sao era esta estao tem ter ha vai vou qual quais quanto quantos ' +
    'como onde quando porque pq oque sabe saber pode poderia gostaria queria quero fala falar diga vem agora ' +
    'explica explique explicar conta contar me mim icaro ola favor entao tipo coisa coisas').split(' '));

  // sinônimos e grafias faladas -> forma canônica
  const SYN = {
    uefis: 'uefs', ufs: 'uefs', 'uefs': 'uefs', estadual: 'uefs',
    feira: 'feira', fsa: 'feira', princesinha: 'princesa',
    ia: 'ia', ai: 'ia', inteligencia: 'ia', artificial: 'ia', chatgpt: 'llm', gpt: 'llm', claude: 'llm', gemini: 'llm',
    contabil: 'contabilidade', contabeis: 'contabilidade', contador: 'contabilidade', contadora: 'contabilidade', contadores: 'contabilidade',
    imposto: 'tributo', impostos: 'tributo', tributos: 'tributo', tributaria: 'tributario', tributarias: 'tributario',
    reforma: 'reforma', ibs: 'ibs', cbs: 'cbs', iva: 'iva', seletivo: 'seletivo', pecado: 'seletivo',
    split: 'split', payment: 'split', cashback: 'cashback', devolucao: 'cashback',
    balanco: 'balanco', balancete: 'balanco', dre: 'dre', resultado: 'dre',
    mei: 'mei', microempreendedor: 'mei', simples: 'simples', presumido: 'presumido', real: 'real',
    vc: 'voce', voces: 'voce', fazer: 'faz', faco: 'faz', roubar: 'substitu', tirar: 'substitu', substituir: 'substitu', trocar: 'substitu',
    vestibular: 'ingresso', sisu: 'ingresso', enem: 'ingresso', entrar: 'ingresso', ingressar: 'ingresso', vaga: 'ingresso', vagas: 'ingresso',
    oi: 'saudacao', ola: 'saudacao', eae: 'saudacao', salve: 'saudacao', bomdia: 'saudacao',
    obrigado: 'agradece', obrigada: 'agradece', valeu: 'agradece', brigado: 'agradece',
  };

  function norm(s) {
    return String(s || '').toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/\bbom dia\b|\bboa tarde\b|\bboa noite\b/g, ' bomdia ')
      .replace(/\bo que\b/g, ' oque ')
      .replace(/[^a-z0-9%\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  // radical simples PT-BR (suficiente para casar plural/gênero/derivações curtas)
  function stem(w) {
    if (w.length <= 3) return w;
    return w.replace(/(ando|endo|indo|ado|ada|ido|ida|ar|er|ir)$/, '')
      .replace(/(coes|cao|soes|sao)$/, 'c')
      .replace(/(mente|idades|idade|mento|mentos)$/, '')
      .replace(/(ais|eis|ois)$/, 'al')
      .replace(/(oes|aes|ns)$/, 'o')
      .replace(/(es|s)$/, '')
      .replace(/[aeo]$/, '');
  }
  function tokens(s) {
    const out = [];
    for (let w of norm(s).split(' ')) {
      if (!w) continue;
      if (SYN[w]) w = SYN[w];
      if (STOP.has(w)) continue;
      out.push(stem(w));
    }
    return out;
  }

  function create(bank, opts) {
    opts = opts || {};
    const now = opts.now || (() => new Date());
    const HIGH = opts.high != null ? opts.high : 0.62; // responde sozinho
    const LOW = opts.low != null ? opts.low : 0.30;    // manda dica ao LLM
    const entries = (bank.entries || bank).map((e) => {
      const qTok = e.q.map(tokens);
      const kwTok = (e.kw || []).map((k) => tokens(k)).filter((k) => k.length);
      return { e, qTok, kwTok, bag: new Set([].concat(...qTok, ...kwTok)) };
    });
    // IDF dos termos do banco
    const df = new Map();
    for (const it of entries) for (const t of it.bag) df.set(t, (df.get(t) || 0) + 1);
    const N = entries.length;
    const idf = (t) => Math.log(1 + N / (1 + (df.get(t) || 0)));

    let lastId = null;

    function score(qt, it) {
      if (!qt.length) return 0;
      const qs = new Set(qt);
      let total = 0; for (const t of qs) total += idf(t);
      // melhor pergunta-exemplo (cobertura ponderada por IDF nos dois sentidos)
      let best = 0;
      for (const ex of it.qTok) {
        const es = new Set(ex); if (!es.size) continue;
        let hit = 0, exTotal = 0;
        for (const t of es) { exTotal += idf(t); if (qs.has(t)) hit += idf(t); }
        const s = (2 * hit) / (total + exTotal);
        if (s > best) best = s;
      }
      // frases-chave: todos os termos da frase presentes
      let kw = 0;
      for (const k of it.kwTok) if (k.every((t) => qs.has(t))) kw += k.reduce((a, t) => a + idf(t), 0);
      const kwScore = Math.min(1, kw / Math.max(total, 1e-9));
      return Math.max(best, 0.55 * best + 0.6 * kwScore);
    }

    function dynamic(text, id) {
      const d = now();
      if (id === 'sys_hora') return text.replace('{hora}', d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Bahia' }));
      if (id === 'sys_data') return text.replace('{data}', d.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'America/Bahia' }));
      return text;
    }

    function answer(question) {
      const t0 = Date.now();
      const qt = tokens(question);
      const thoughts = [{ k: 'escuta', t: 'Pergunta recebida' }];
      // continuação: "e depois?", "fala mais", "continua"
      if (lastId && /^(e (depois|ai|entao)|fala mais|continua|mais detalhes|e isso|explica melhor)\b/.test(norm(question))) {
        const prev = entries.find((x) => x.e.id === lastId);
        const nxt = prev && prev.e.follow && entries.find((x) => x.e.id === prev.e.follow[0]);
        if (nxt) {
          lastId = nxt.e.id;
          thoughts.push({ k: 'memoria', t: 'Continuando o assunto anterior' }, { k: 'resposta', t: nxt.e.cat });
          return { mode: 'local', id: nxt.e.id, cat: nxt.e.cat, score: 1, text: dynamic(nxt.e.a, nxt.e.id), gestures: nxt.e.g || [], thoughts, ms: Date.now() - t0 };
        }
      }
      if (qt.length) thoughts.push({ k: 'termos', t: qt.slice(0, 6).join(' · ') });
      const ranked = entries.map((it) => ({ it, s: score(qt, it) })).sort((a, b) => b.s - a.s);
      const top = ranked.slice(0, 3).filter((r) => r.s > 0);
      for (const r of top) thoughts.push({ k: 'hipotese', t: r.it.e.cat + ' — ' + r.it.e.q[0], c: +r.s.toFixed(2) });

      const b = ranked[0];
      if (b && b.s >= HIGH) {
        lastId = b.it.e.id;
        thoughts.push({ k: 'resposta', t: 'Base própria · confiança ' + Math.round(b.s * 100) + '%' });
        return { mode: 'local', id: b.it.e.id, cat: b.it.e.cat, score: b.s, text: dynamic(b.it.e.a, b.it.e.id), follow: b.it.e.follow || [], gestures: b.it.e.g || [], thoughts, ms: Date.now() - t0 };
      }
      if (b && b.s >= LOW) {
        const ctx = top.filter((r) => r.s >= LOW).map((r) => '- ' + r.it.e.a);
        thoughts.push({ k: 'consulta', t: 'Confirmando com o modelo de IA' });
        return { mode: 'hint', score: b.s, cat: b.it.e.cat, context: ctx.join('\n'), thoughts, ms: Date.now() - t0 };
      }
      thoughts.push({ k: 'consulta', t: 'Pergunta nova · consultando o modelo de IA' });
      return { mode: 'llm', score: b ? b.s : 0, context: '', thoughts, ms: Date.now() - t0 };
    }

    return { answer, tokens, size: N, reset: () => { lastId = null; } };
  }

  // Cache de respostas do LLM (chave = termos normalizados ordenados). Em Node use com um Map persistido em JSON.
  function cacheKey(question) { return tokens(question).slice().sort().join(' '); }

  return { create, tokens, norm, cacheKey };
});
