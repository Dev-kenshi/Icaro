# PROMPT 3 · CÉREBRO DO ÍCARO: banco de respostas + economia de tokens

> Cole abaixo da linha no Replit Agent, com `icaro-cinema/cerebro/` enviado ao projeto.
> Conteúdo: `banco-respostas.json` (80 intenções: contabilidade, reforma tributária, IA, UEFS/Ciências Contábeis, Feira de Santana e conversa), `icaro-brain.js` (roteador local, cerca de 0,15 ms por pergunta) e `test.js` (`node icaro-cinema/cerebro/test.js` deve imprimir **TUDO OK**).

---

Integre o **cérebro local** do Ícaro para que a maioria das perguntas seja respondida **sem chamar o LLM** e **sem gerar áudio de novo**, reduzindo o custo de tokens e de TTS e a latência.

## Regras
1. **Não edite** `icaro-brain.js` nem o formato do `banco-respostas.json`. Para ajustar respostas, edite só o texto dos campos `a`, `q` e `kw` no JSON e rode `node icaro-cinema/cerebro/test.js` depois.
2. O roteador decide entre três caminhos pela confiança:
   - `mode: 'local'` (≥ 0,62) → responde com `r.text` direto. **Zero tokens.**
   - `mode: 'hint'` (0,30 a 0,62) → chama o LLM com prompt **curto**, mandando só `r.context` (2 ou 3 respostas do banco) como referência.
   - `mode: 'llm'` → chama o LLM normalmente, com o system prompt abaixo.
3. Os `r.thoughts` de toda resposta são emitidos no `icaroBus` como eventos `thought` (é isso que alimenta o Fluxo de Pensamento Holográfico do PROMPT 1), e `r.gestures` vai para o Modo Palestra (PROMPT 2).
4. Chaves de API só no servidor.

## Passo 1: servidor (rota única de pergunta)
Crie `POST /api/ask` com corpo `{ text, sessionId }` e resposta `{ mode, text, thoughts, gestures, cached }`:
```js
const IcaroBrain = require('./icaro-cinema/cerebro/icaro-brain');
const bank = require('./icaro-cinema/cerebro/banco-respostas.json');
const brains = new Map();                 // um cérebro por sessão (memória de "e depois?")
const brainFor = id => brains.get(id) || (brains.set(id, IcaroBrain.create(bank)), brains.get(id));
const llmCache = new Map();               // persista em JSON/SQLite/Replit DB: chave = IcaroBrain.cacheKey(text)
```
Fluxo:
1. `r = brainFor(sessionId).answer(text)`.
2. `local` → devolve `r.text`.
3. Se não for local, procure `llmCache.get(IcaroBrain.cacheKey(text))`. Se achar, devolve com `cached: true` e um thought `{k:'memoria', t:'Já respondi isso antes'}`.
4. Senão, chame o LLM (o mesmo provedor/modelo que o projeto já usa, ou o modelo mais barato disponível), com:
   - `max_tokens` (ou equivalente) = **220**; respostas faladas devem ser curtas;
   - `temperature` 0,3;
   - histórico de no máximo as **4 últimas trocas**, resumidas;
   - em `hint`, acrescente ao system: `Referências da base do Ícaro (use se forem pertinentes):\n${r.context}`.
5. Salve no `llmCache` (TTL de 30 dias) e devolva o resultado.
6. Registre em log (sem dados pessoais): `mode`, `score`, `cat`, tokens de entrada e saída, ms. Exponha `GET /api/ask/stats` com a taxa de respostas locais, a de cache e os tokens economizados (estimativa: 350 tokens por resposta evitada).

## Passo 2: system prompt do LLM (curto, cerca de 230 tokens)
```
Você é o Ícaro, assistente holográfico do projeto Contador do Amanhã, criado por estudantes de Ciências Contábeis da UEFS
(Universidade Estadual de Feira de Santana, Bahia) e apresentado no ITCONT. Especialista em contabilidade, reforma tributária
(EC 132/2023, LC 214/2025: CBS, IBS, Imposto Seletivo, split payment, transição 2026–2033) e inteligência artificial aplicada
à contabilidade. Conhece o curso de Ciências Contábeis da UEFS e a cidade de Feira de Santana.
Regras: responda em português do Brasil, falado e natural, em 2 a 4 frases (máx. 70 palavras), sem listas, markdown, emojis
ou siglas soletradas sem explicar. Se não tiver certeza de um número, prazo ou lei, diga isso e indique a fonte oficial
(Receita Federal, CFC, CRC-BA, UEFS, Prefeitura). Nunca invente leis. Fora do seu domínio, responda brevemente e traga
a conversa de volta para contabilidade, tecnologia ou a UEFS. Seja caloroso, confiante e didático, como um palestrante.
```

## Passo 3: áudio pré-gerado (a maior economia)
O TTS custa mais que o LLM. Para respostas locais e de cache:
1. Crie `scripts/pregen-voz.js`: para cada entrada do banco **sem** `{hora}`/`{data}`, chame a mesma rota de TTS com timestamps (`/api/tts-ts`, se existir, ou o TTS atual) e salve `public/voz/<id>.mp3` + `public/voz/<id>.json` (os timestamps/alinhamento). Rode uma vez e sempre que um texto `a` mudar (compare pelo hash do texto, guardado em `public/voz/manifest.json`).
2. No front, se `/api/ask` retornar `mode:'local'` com `id`, toque o arquivo pré-gerado com os mesmos timestamps (o avatar e a legenda funcionam igual). Só chame o TTS ao vivo para respostas do LLM.
3. Também guarde o áudio de respostas do LLM em cache pela mesma chave.
4. Inclua o `id` na resposta do `/api/ask` quando `mode === 'local'`.

## Passo 4: front
- Troque a chamada atual do LLM por `POST /api/ask`.
- Ao enviar a pergunta, emita `state: thinking`. Para cada `thought` recebido, emita `icaroBus.dispatchEvent(new CustomEvent('thought', {detail}))` com 140 ms entre eles (o PROMPT 1 cuida do visual). Depois emita `answer:start`.
- Se `mode === 'local'`, a resposta chega em menos de 50 ms. Mesmo assim, deixe os pensamentos aparecerem (até cerca de 900 ms) antes de falar, para o público ver o Ícaro "pensar".

## Passo 5: painel de curadoria (rota protegida `/admin/cerebro`, senha em Secret `ADMIN_PASS`)
- Lista das **perguntas que foram para o LLM** (mais frequentes primeiro), com a resposta dada.
- Botão **"Promover ao banco"**: cria uma entrada nova (`id`, `cat`, `q` com a pergunta, `a` com a resposta editável, `kw`) e grava no JSON. Assim o banco cresce com o uso real e o gasto de tokens cai a cada evento.
- Filtro das entradas `verificar: true`, para a equipe conferir antes do ITCONT (datas, nomes e números que mudam).

## Critérios de aceite
1. `node icaro-cinema/cerebro/test.js` → TUDO OK.
2. "O que é split payment?" → `mode: local`, nenhuma requisição ao LLM nem ao TTS ao vivo (o áudio vem de `/voz/rt_split.mp3`).
3. "Quando o ICMS acaba?" → local (`rt_cronograma`); em seguida, "e depois?" → `rt_2026` (memória de continuação).
4. "Qual a capital da Austrália?" → `mode: llm`, resposta de no máximo 70 palavras; repetida a pergunta → `cached: true`.
5. `/api/ask/stats` mostra a taxa local e os tokens economizados.
6. "Que horas são?" → hora certa de Feira de Santana, sem LLM.

Entregue a lista de arquivos, a saída do teste e um print do `/api/ask/stats` após 20 perguntas de teste.
