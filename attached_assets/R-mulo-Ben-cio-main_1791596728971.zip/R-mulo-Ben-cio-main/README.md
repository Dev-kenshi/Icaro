# ÍCARO

Assistente pessoal de voz e especialista em contabilidade do professor Rômulo Benício (UEFS).
Inteligência, Contabilidade, Análises, Resultados e Operações.

Rosto em holograma diante de um planeta Terra em 3D, conversa por voz em português e em espanhol
do Uruguai, base local de normas contábeis (Lei 4.320, MCASP, Lei 6.404, CPCs e IFRS, NBC, reforma
tributária), música pelo Spotify, painel financeiro, agenda e apresentação guiada dos sistemas
Discipulus e LabEduContábil UEFS.

## Requisitos

- Windows com Python 3.10 ou mais novo (o `ICARO.bat` oferece instalar se faltar).
- Microsoft Edge (reconhecimento de voz e vozes naturais).
- Chave da Anthropic e/ou chave gratuita do Google AI Studio (Gemini), coladas nas configurações
  do próprio Ícaro. Nenhuma chave fica neste repositório: o `config.json` é criado na primeira
  execução e está no `.gitignore`.

## Como rodar

```
ICARO.bat
```

O Edge abre em `http://127.0.0.1:8765`. Clique em ATIVAR ÍCARO e diga "Olá, Ícaro".

O manual completo, com todos os comandos de voz, está em [LEIA-ME.md](LEIA-ME.md).

## Sem dependências

Servidor em Python puro (biblioteca padrão). A interface é um único `ui/index.html`. O globo usa o
MapLibre GL JS 5.24.0 (licença BSD, em `ui/vendor`).
