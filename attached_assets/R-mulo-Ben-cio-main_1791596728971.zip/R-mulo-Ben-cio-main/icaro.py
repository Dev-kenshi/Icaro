# -*- coding: utf-8 -*-
"""
ÍCARO v5 - assistente pessoal de voz e especialista contábil do Rômulo Benício.
Inteligência, Contabilidade, Análises, Resultados e Operações.

Servidor local em Python puro (zero dependências externas).

  navegador ......... holograma com rosto animado sobre o globo 3D, escuta, fala (português e espanhol) e painéis
  este processo ..... cérebro rápido: busca local (BM25) + streaming do modelo,
                      a fala começa na primeira frase pronta
                      operador: ferramentas reais no Windows, com confirmação
                      autonomia: rotinas, lembretes da agenda, vigilância de pastas
                      utilidades: música (Spotify, YouTube de reserva), clima (Open-Meteo), painel financeiro
                      (AwesomeAPI, Banco Central, Ibovespa), geografia (Open-Meteo e OpenStreetMap), agenda (.ics)
  porta 8766 ........ Discipulus e LabEduContábil em origem isolada, com o roteiro de apresentação guiada

Uso:  python icaro.py
"""

import hashlib
import hmac
import html as htmllib
import http.server
import json
import math
import os
import re
import secrets
import shutil
import socketserver
import subprocess
import sys
import threading
import time
import unicodedata
import base64
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from collections import Counter, deque
from datetime import datetime, timedelta
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

VERSAO = "5.0"
RAIZ = Path(__file__).resolve().parent
UI = RAIZ / "ui"
MEM = RAIZ / "memoria"
KB = RAIZ / "conhecimento"
PROJ = RAIZ / "projetos"
ARQ_CONFIG = RAIZ / "config.json"
ARQ_BRAIN = MEM / "second_brain.json"
ARQ_ROTINAS = MEM / "rotinas.json"
ARQ_VIGIAS = MEM / "vigias.json"
ARQ_AGENDA = MEM / "agenda.json"
ARQ_LOG = MEM / "historico.log"

URL_ANTHROPIC = os.environ.get("ICARO_URL_ANTHROPIC", "https://api.anthropic.com").rstrip("/")
URL_GEMINI = os.environ.get("ICARO_URL_GEMINI", "https://generativelanguage.googleapis.com").rstrip("/")
URL_SPOTIFY_API = os.environ.get("ICARO_URL_SPOTIFY_API", "https://api.spotify.com").rstrip("/")
URL_SPOTIFY_CONTAS = os.environ.get("ICARO_URL_SPOTIFY_CONTAS", "https://accounts.spotify.com").rstrip("/")
URL_BUSCA_WEB = os.environ.get("ICARO_URL_BUSCA_WEB", "https://html.duckduckgo.com/html/")
VERSAO_API = "2023-06-01"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0 Safari/537.36")

TRAVA = threading.Lock()


def carregar_token():
    """Credencial de sessão da página. Persiste entre reinícios para a aba aberta não quebrar."""
    arq = MEM / "sessao.token"
    try:
        t = arq.read_text(encoding="utf-8").strip()
        if len(t) >= 24:
            return t
    except Exception:
        pass
    t = secrets.token_urlsafe(24)
    try:
        MEM.mkdir(exist_ok=True)
        arq.write_text(t, encoding="utf-8")
    except Exception:
        pass
    return t


TOKEN = carregar_token()

# ================================================================== config

PADRAO = {
    "nome": "ÍCARO",
    "tratamento": "Rômulo",
    "nome_completo": "Rômulo Benício Lucena Filho",
    "porta": 8765,
    "provedores": ["anthropic", "gemini"],
    "modelo": "claude-sonnet-5",
    "api_key": "",
    "gemini_key": "",
    "gemini_modelos": ["gemini-2.5-flash", "gemini-3.5-flash", "gemini-3.6-flash", "gemini-3.7-flash",
                       "gemini-3.8-flash", "gemini-flash-latest", "gemini-2.5-flash-lite"],
    "max_tokens": 1400,
    "poderes": "total",              # leitura | escrita | total
    "modo_escuta": "palavra",        # palavra | sempre
    "janela_seguimento": 8,          # segundos ouvindo sem palavra de ativação após responder
    "senha_confirmacao": "",         # se preenchida, ações destrutivas exigem "confirmo <senha>"
    "cidade": "Feira de Santana",
    "navegador": "edge",             # edge tem as vozes naturais da Microsoft
    "voz_motor": "auto",             # auto (premium quando houver) | gemini | navegador
    "voz_premium": "Charon",         # voz do Gemini TTS ("clonada" = a voz replicada abaixo)
    "voz_clonada": "",               # id voice_... criado em ⚙ → CLONAR MINHA VOZ
    "voz_clonada_modelo": "",
    "voz_estilo": ("Fale em português do Brasil, de forma natural, calorosa e confiante, como uma pessoa "
                   "conversando de verdade, com entonação viva e pausas naturais."),
    "tts_modelos": ["gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts", "gemini-3.1-flash-tts-preview",
                    "gemini-2.5-flash-preview-tts"],
    "pasta_padrao": str(Path.home()),
    "abrir_navegador": True,
    "vigilancia_ativa": True,
    "intervalo_vigilancia": 45,
    "sugerir_em_arquivo_novo": True,
    "musica_fonte": "spotify",       # spotify (embed ou Spotify Connect) | youtube
    "spotify_client_id": "",         # opcional: app do developer.spotify.com (Premium) para tocar no Spotify do PC
    "spotify_refresh": "",
    "spotify_favoritas": [],         # [{"nome": "abertura", "uri": "spotify:track:..."}]
    "cenario": "terra",              # terra (globo 3D atrás do Ícaro) | nenhum
    "local_fixo": "",                # se preenchido, "onde estamos" responde este lugar (ex.: Montevidéu)
    "porta_sistemas": 8766,          # porta separada para Discipulus e LabEduContábil (origem isolada)
    "sistemas": {
        "discipulus": r"C:\Documentos\UEFS\DISCIPLINAS\LABORATÓRIO CONTÁBIL\DISCIPULUS_HTML_3.3.0 (2).html",
        "labedu": r"C:\Documentos\UEFS\DISCIPLINAS\LABORATÓRIO CONTÁBIL\index-PROFESSOR_LAB_EDU_BASE_INTEGRADA_5.html",
    },
}
CHAVES_SECRETAS = {"api_key", "gemini_key", "senha_confirmacao", "spotify_refresh"}


def json_ler(caminho, padrao):
    if caminho.exists():
        try:
            return json.loads(caminho.read_text(encoding="utf-8"))
        except Exception:
            pass
    return padrao


def json_salvar(caminho, dados):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_suffix(caminho.suffix + ".tmp")
    tmp.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, caminho)


def carregar_config():
    cfg = dict(PADRAO)
    lido = json_ler(ARQ_CONFIG, None)
    if isinstance(lido, dict):
        cfg.update(lido)
    if not cfg.get("api_key"):
        cfg["api_key"] = os.environ.get("ANTHROPIC_API_KEY", "")
    if not cfg.get("gemini_key"):
        cfg["gemini_key"] = os.environ.get("GEMINI_API_KEY", "")
    return cfg, (not isinstance(lido, dict)) or any(k not in lido for k in PADRAO)


CFG, _CONFIG_INCOMPLETA = carregar_config()
PORTA = int(os.environ.get("ICARO_PORTA") or CFG.get("porta", 8765))


def salvar_config():
    json_salvar(ARQ_CONFIG, CFG)


# ================================================================== texto

def norm(s):
    s = unicodedata.normalize("NFD", str(s or "").lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def slug(s, maximo=48):
    s = norm(s)
    s = re.sub(r"[^a-z0-9._-]+", "-", s).strip("-.")
    return (s or "item")[:maximo]


DIAS_SEMANA = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo"]
MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto",
         "setembro", "outubro", "novembro", "dezembro"]


def agora_extenso(dt=None):
    dt = dt or datetime.now()
    return "%s, %02d de %s de %d, %02d:%02d" % (DIAS_SEMANA[dt.weekday()], dt.day, MESES[dt.month - 1],
                                                dt.year, dt.hour, dt.minute)


def log(txt):
    try:
        MEM.mkdir(exist_ok=True)
        with ARQ_LOG.open("a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), txt))
    except Exception:
        pass


# ================================================================== eventos (o ÍCARO falando sozinho)

EVENTOS = []


def evento(texto, origem="sistema", extra=None):
    with TRAVA:
        e = {"id": int(time.time() * 1000), "texto": texto, "origem": origem, "hora": time.strftime("%H:%M")}
        if extra:
            e.update(extra)
        EVENTOS.append(e)
        del EVENTOS[:-20]
    log("evento[%s]: %s" % (origem, texto))


def eventos_drenar():
    with TRAVA:
        saida = list(EVENTOS)
        del EVENTOS[:]
    return saida


# ================================================================== memória (second brain)

AREAS = ["perfil", "uefs", "pesquisa", "projetos", "metas", "financas", "aprendizado", "saude", "relacoes", "geral"]


def brain_ler():
    d = json_ler(ARQ_BRAIN, {"notas": []})
    if not isinstance(d, dict) or not isinstance(d.get("notas"), list):
        d = {"notas": []}
    usados, mudou = set(), False
    for n in d["notas"]:
        if n.get("area") not in AREAS:
            n["area"] = "geral"
            mudou = True
        nid = n.get("id")
        if not nid or nid in usados:
            base = "n-" + slug(n.get("titulo", "nota"), 24)
            nid, i = base, 2
            while nid in usados:
                nid, i = "%s-%d" % (base, i), i + 1
            n["id"] = nid
            mudou = True
        usados.add(nid)
    if mudou:
        json_salvar(ARQ_BRAIN, d)
    return d


def nota_salvar(area, titulo, texto, nid=None):
    area = area if area in AREAS else "geral"
    titulo = (titulo or "").strip()[:60] or "Nota"
    texto = (texto or "").strip()[:2000]
    with TRAVA:
        d = brain_ler()
        alvo = None
        for n in d["notas"]:
            if (nid and n["id"] == nid) or (not nid and norm(n["titulo"]) == norm(titulo)):
                alvo = n
                break
        if alvo:
            alvo.update({"area": area, "titulo": titulo, "texto": texto})
            json_salvar(ARQ_BRAIN, d)
            return alvo["id"], False
        novo = {"id": "", "area": area, "titulo": titulo, "texto": texto}
        d["notas"].append(novo)
        json_salvar(ARQ_BRAIN, d)
    d = brain_ler()
    for n in d["notas"]:
        if n["titulo"] == titulo and n["texto"] == texto:
            return n["id"], True
    return "", True


def nota_excluir(nid):
    with TRAVA:
        d = brain_ler()
        antes = len(d["notas"])
        d["notas"] = [n for n in d["notas"] if n["id"] != nid]
        json_salvar(ARQ_BRAIN, d)
        return antes - len(d["notas"])


def perfil_curto():
    d = brain_ler()
    txt = " ".join(n["texto"] for n in d["notas"] if n["area"] == "perfil")
    return txt[:500] or "Contador e professor da UEFS."


# ================================================================== base de conhecimento (RAG local, BM25)

STOP = set("""
a o as os um uma uns umas de do da dos das em no na nos nas por pelo pela pelos pelas para pra pro
com sem sob sobre entre ate e ou que se ao aos ser sao foi era como mais menos muito muita muitos
muitas me te lhe nos eu tu ele ela eles elas voce voces meu minha meus minhas seu sua seus suas
nosso nossa isso isto aquilo esse essa este esta esses essas estes estas qual quais quando onde
porque pois ja nao sim tambem so ha tem ter fazer faz pode posso devo deve qualquer todo toda
todos todas cada outro outra num numa dum duma la ali aqui icaro ola oi fala diga me explique
explica conte quero queria gostaria preciso saber sabe favor obrigado entao agora coisa
""".split())

SINONIMOS = {
    "ibs": "imposto bens servicos reforma tributaria",
    "cbs": "contribuicao bens servicos reforma tributaria",
    "seletivo": "imposto seletivo",
    "reforma": "reforma tributaria ibs cbs transicao",
    "4320": "lei 4320 financeiro orcamento",
    "6404": "lei 6404 sociedades anonimas",
    "mcasp": "manual contabilidade aplicada setor publico",
    "pcasp": "plano contas aplicado setor publico",
    "dcasp": "demonstracoes contabeis setor publico",
    "lrf": "responsabilidade fiscal",
    "rap": "restos pagar",
    "restos": "restos pagar",
    "dfc": "fluxo caixa",
    "dre": "demonstracao resultado",
    "dva": "valor adicionado",
    "dmpl": "mutacoes patrimonio liquido",
    "bp": "balanco patrimonial",
    "empenho": "despesa empenho liquidacao pagamento",
    "liquidacao": "despesa empenho liquidacao pagamento",
    "dividendo": "dividendos lucros distribuicao",
    "dividendos": "lucros distribuicao 15270",
    "presumido": "lucro presumido presuncao 224",
    "simples": "simples nacional",
    "arrendamento": "arrendamento cpc 06 direito uso",
    "leasing": "arrendamento cpc 06",
    "ifrs": "cpc pronunciamento",
    "superavit": "superavit financeiro ativo financeiro passivo financeiro",
    "suplementar": "creditos adicionais",
    "especial": "creditos adicionais",
    "extraordinario": "creditos adicionais",
    "split": "split payment",
    "cashback": "devolucao",
    "discipulus": "entidade sem finalidade lucros igreja",
    "itcont": "imersao tecnologica contabil uefs",
    "lancamento": "debito credito partidas dobradas",
    "contabilizar": "lancamento debito credito",
    "contabiliza": "lancamento debito credito",
    "sped": "ecd ecf efd escrituracao digital",
    "custeio": "custos absorcao variavel",
}


def radical(w):
    if w.isdigit() or len(w) <= 3:
        return w
    for a, b in (("veis", "vel"), ("eis", "il"), ("ais", "al"), ("ois", "ol"), ("oes", "ao"),
                 ("aes", "ao"), ("res", "r"), ("zes", "z"), ("ns", "m")):
        if w.endswith(a) and len(w) > len(a) + 2:
            w = w[: -len(a)] + b
            break
    else:
        if w.endswith("s") and not w.endswith("ss") and len(w) > 4:
            w = w[:-1]
    for suf in ("amento", "imento", "mente", "idade", "ismo", "ista", "avel", "ivel", "ancia", "encia"):
        if w.endswith(suf) and len(w) - len(suf) >= 4:
            w = w[: -len(suf)]
            break
    if len(w) > 4 and w[-1] in "aoe":
        w = w[:-1]
    return w


RX_PALAVRA = re.compile(r"[a-z0-9]+")


def palavras(texto):
    t = norm(texto)
    t = re.sub(r"(?<=\d)\.(?=\d{3}\b)", "", t)
    return RX_PALAVRA.findall(t)


def tokens(texto):
    out = []
    for w in palavras(texto):
        if w in STOP or (len(w) < 2 and not w.isdigit()):
            continue
        out.append(radical(w))
    return out


def fatiar(caminho):
    try:
        txt = caminho.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return []
    m = re.search(r"(?m)^#\s+(.+)$", txt)
    titulo = m.group(1).strip() if m else caminho.stem
    partes = re.split(r"(?m)^##\s+", txt)
    pedacos = []
    intro = re.sub(r"(?m)^#\s+.+$", "", partes[0]).strip()
    if len(intro) > 80:
        pedacos.append(("Visão geral", intro))
    for p in partes[1:]:
        linhas = p.split("\n", 1)
        secao = linhas[0].strip()
        corpo = linhas[1].strip() if len(linhas) > 1 else ""
        if not corpo:
            continue
        if len(corpo) <= 1500:
            pedacos.append((secao, corpo))
            continue
        bloco = ""
        for par in re.split(r"\n\s*\n", corpo):
            if bloco and len(bloco) + len(par) > 1100:
                pedacos.append((secao, bloco.strip()))
                bloco = ""
            bloco += par + "\n\n"
        if bloco.strip():
            pedacos.append((secao, bloco.strip()))
    return [{"id": "%s#%d" % (caminho.stem, i), "tipo": "kb", "fonte": titulo, "secao": s, "texto": c}
            for i, (s, c) in enumerate(pedacos)]


class Indice:
    def __init__(self):
        self.docs, self.df, self.N, self.media = [], Counter(), 0, 1.0
        self.assinatura = None
        self.lock = threading.Lock()

    def _assinatura(self):
        itens = []
        try:
            arquivos = sorted(list(KB.glob("*.md")) + list(KB.glob("*.txt"))) if KB.exists() else []
        except OSError:
            arquivos = []
        for p in arquivos:
            try:   # arquivo aberto em outro programa ou sumido no meio da leitura: fica de fora desta vez
                st = p.stat()
                itens.append((p.name, st.st_mtime_ns, st.st_size))
            except OSError:
                continue
        try:
            if ARQ_BRAIN.exists():
                itens.append(("brain", ARQ_BRAIN.stat().st_mtime_ns))
        except OSError:
            pass
        return tuple(itens)

    def garantir(self):
        a = self._assinatura()
        if a == self.assinatura:
            return
        with self.lock:
            if a == self.assinatura:
                return
            docs = []
            for nome in [x[0] for x in a if x[0] != "brain"]:
                docs += fatiar(KB / nome)
            for n in brain_ler()["notas"]:
                docs.append({"id": n["id"], "tipo": "nota", "fonte": "Memória", "secao": n["titulo"],
                             "texto": n["texto"], "area": n["area"]})
            df = Counter()
            for d in docs:
                tk = tokens("%s %s %s %s" % (d["secao"], d["secao"], d["fonte"], d["texto"]))
                d["tf"] = Counter(tk)
                d["n"] = max(1, len(tk))
                df.update(set(tk))
            self.docs, self.df, self.N = docs, df, len(docs)
            self.media = sum(d["n"] for d in docs) / max(1, len(docs))
            self.assinatura = a

    def buscar(self, consulta, k=10):
        self.garantir()
        q = Counter()
        for w in tokens(consulta):
            q[w] += 1.0
        for w in palavras(consulta):
            if w in SINONIMOS:
                for x in tokens(SINONIMOS[w]):
                    if x not in q:
                        q[x] += 0.5
        if not q:
            return []
        res = []
        for d in self.docs:
            s = 0.0
            for w, peso in q.items():
                f = d["tf"].get(w)
                if not f:
                    continue
                idf = math.log(1 + (self.N - self.df[w] + 0.5) / (self.df[w] + 0.5))
                s += peso * idf * (f * 2.5) / (f + 1.5 * (0.25 + 0.75 * d["n"] / self.media))
            if s > 0:
                res.append((s, d))
        res.sort(key=lambda x: -x[0])
        return res[:k]

    def resumo(self):
        self.garantir()
        arquivos = sorted({d["fonte"] for d in self.docs if d["tipo"] == "kb"})
        return {"trechos": sum(1 for d in self.docs if d["tipo"] == "kb"), "documentos": arquivos}


INDICE = Indice()


# ================================================================== agenda

def agenda_ler():
    a = json_ler(ARQ_AGENDA, [])
    return a if isinstance(a, list) else []


def ler_data(txt):
    txt = (txt or "").strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(txt, fmt)
        except ValueError:
            pass
    return None


def agenda_add(inicio, duracao, titulo):
    dt = ler_data(inicio)
    if not dt:
        return None
    try:
        dur = max(5, min(24 * 60, int(float(duracao or 60))))
    except ValueError:
        dur = 60
    ev = {"id": "e%d%s" % (int(time.time() * 1000), secrets.token_hex(2)), "inicio": dt.strftime("%Y-%m-%d %H:%M"),
          "duracao": dur, "titulo": (titulo or "Compromisso").strip()[:120], "aviso10": False, "aviso0": False}
    with TRAVA:
        a = agenda_ler()
        a.append(ev)
        a.sort(key=lambda e: e["inicio"])
        json_salvar(ARQ_AGENDA, a)
    return ev


def agenda_del(alvo):
    alvo_n = norm(alvo).strip()
    if not alvo_n:
        return []
    with TRAVA:
        a = agenda_ler()
        fora = [e for e in a if e["id"] == alvo or alvo_n in norm(e["titulo"])]
        if fora and fora[0]["id"] != alvo:
            futuros = [e for e in fora if e["inicio"] >= datetime.now().strftime("%Y-%m-%d")]
            fora = futuros[:1] or fora[:1]
        ids = {e["id"] for e in fora}
        json_salvar(ARQ_AGENDA, [e for e in a if e["id"] not in ids])
    return fora


def agenda_periodo(de, ate):
    s1, s2 = de.strftime("%Y-%m-%d %H:%M"), ate.strftime("%Y-%m-%d %H:%M")
    return [e for e in agenda_ler() if s1 <= e["inicio"] < s2]


def falar_hora(hhmm):
    h, m = int(hhmm[:2]), int(hhmm[3:5])
    return "%dh" % h if m == 0 else "%dh%02d" % (h, m)


def agenda_texto(dias=7):
    hoje = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    evs = agenda_periodo(hoje, hoje + timedelta(days=dias))
    if not evs:
        return "(sem compromissos nos próximos %d dias)" % dias
    linhas = []
    for e in evs:
        dt = ler_data(e["inicio"])
        linhas.append("- %s %02d/%02d %s (%d min): %s [id %s]" % (DIAS_SEMANA[dt.weekday()][:3], dt.day, dt.month,
                                                                   e["inicio"][11:], e["duracao"], e["titulo"], e["id"]))
    return "\n".join(linhas)


def ics_texto():
    def esc(s):
        return s.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n")
    linhas = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//ICARO//Agenda//PT-BR", "CALSCALE:GREGORIAN"]
    carimbo = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    for e in agenda_ler():
        dt = ler_data(e["inicio"])
        if not dt:
            continue
        fim = dt + timedelta(minutes=int(e.get("duracao", 60)))
        linhas += ["BEGIN:VEVENT", "UID:%s@icaro" % e["id"], "DTSTAMP:" + carimbo,
                   "DTSTART:" + dt.strftime("%Y%m%dT%H%M%S"), "DTEND:" + fim.strftime("%Y%m%dT%H%M%S"),
                   "SUMMARY:" + esc(e["titulo"]), "END:VEVENT"]
    linhas.append("END:VCALENDAR")
    return "\r\n".join(linhas) + "\r\n"


# ================================================================== rotinas (v3)

DIAS_MAPA = {"seg": 0, "ter": 1, "qua": 2, "qui": 3, "sex": 4, "sab": 5, "dom": 6}


def interpretar_dias(txt):
    t = norm(txt or "todos")
    if "fim" in t:
        return [5, 6]
    if "util" in t or ("semana" in t and "fim" not in t):
        return [0, 1, 2, 3, 4]
    if "todo" in t or not t.strip():
        return [0, 1, 2, 3, 4, 5, 6]
    achados = []
    for parte in re.split(r"[,\s/]+", t):
        k = parte[:3]
        if k in DIAS_MAPA and DIAS_MAPA[k] not in achados:
            achados.append(DIAS_MAPA[k])
    return achados or [0, 1, 2, 3, 4, 5, 6]


def nome_dias(dias):
    if sorted(dias) == [0, 1, 2, 3, 4]:
        return "dias úteis"
    if sorted(dias) == [5, 6]:
        return "fim de semana"
    if len(dias) == 7:
        return "todos os dias"
    inv = {v: k for k, v in DIAS_MAPA.items()}
    return ", ".join(inv.get(d, str(d)) for d in sorted(dias))


def rotina_criar(hora, dias, instrucao, nome=None):
    hora = re.sub(r"[^0-9:]", "", hora or "")
    if not re.match(r"^\d{1,2}:\d{2}$", hora):
        return None
    h, m = hora.split(":")
    hora = "%02d:%02d" % (int(h) % 24, int(m) % 60)
    dd = interpretar_dias(dias)
    nova = {"id": "r%d" % int(time.time() * 1000), "nome": (nome or instrucao)[:40], "hora": hora,
            "dias": dd, "instrucao": instrucao, "ultima": ""}
    with TRAVA:
        r = json_ler(ARQ_ROTINAS, [])
        r.append(nova)
        json_salvar(ARQ_ROTINAS, r)
    return nova


def rotina_remover(alvo):
    a = norm(alvo)
    with TRAVA:
        r = json_ler(ARQ_ROTINAS, [])
        novo = [x for x in r if x["id"].lower() != a and a not in norm(x["nome"])]
        json_salvar(ARQ_ROTINAS, novo)
    return len(r) - len(novo)


# ================================================================== operador: ferramentas (v3, com travas)

PERIGOSO = [
    r"\bremove-item\b", r"\brmdir\b", r"\brd\s+/s", r"\bdel\s+/", r"\berase\b",
    r"\bformat\b", r"\bdiskpart\b", r"\bfsutil\b", r"\bclear-disk\b",
    r"\bshutdown\b", r"\brestart-computer\b", r"\bstop-computer\b",
    r"\bstop-process\b", r"\btaskkill\b", r"\bset-executionpolicy\b",
    r"\breg\s+delete\b", r"\bremove-itemproperty\b", r"\buninstall\b",
    r"\bnet\s+user\b", r"\bicacls\b", r"\bcipher\b", r"\biex\b", r"\binvoke-expression\b",
    r"\binvoke-webrequest\b.*\|\s*iex", r"\bgit\s+push\s+.*--force", r"\bgit\s+reset\s+--hard\b",
]


def parece_perigoso(cmd):
    baixo = (cmd or "").lower()
    return any(re.search(p, baixo) for p in PERIGOSO)


def caminho_valido(p):
    if not p or not str(p).strip():
        raise ValueError("caminho vazio")
    caminho = Path(os.path.expandvars(os.path.expanduser(str(p).strip())))
    if not caminho.is_absolute():
        caminho = Path(CFG["pasta_padrao"]) / caminho
    return caminho


FERRAMENTAS = [
    {"name": "listar_pasta", "description": "Lista arquivos e subpastas de um diretório. Use antes de mexer em arquivo.",
     "input_schema": {"type": "object", "properties": {"caminho": {"type": "string"}, "detalhado": {"type": "boolean"}},
                      "required": ["caminho"]}},
    {"name": "ler_arquivo", "description": "Lê arquivo de texto (txt, md, csv, json, py, html, log). Até 60 mil caracteres.",
     "input_schema": {"type": "object", "properties": {"caminho": {"type": "string"}}, "required": ["caminho"]}},
    {"name": "escrever_arquivo", "description": "Cria ou substitui arquivo de texto. Sobrescrever pede confirmação.",
     "input_schema": {"type": "object", "properties": {"caminho": {"type": "string"}, "conteudo": {"type": "string"},
                                                       "anexar": {"type": "boolean"}}, "required": ["caminho", "conteudo"]}},
    {"name": "mover_arquivo", "description": "Move ou renomeia arquivo ou pasta.",
     "input_schema": {"type": "object", "properties": {"origem": {"type": "string"}, "destino": {"type": "string"}},
                      "required": ["origem", "destino"]}},
    {"name": "buscar_arquivos", "description": "Procura arquivos por nome numa pasta, incluindo subpastas.",
     "input_schema": {"type": "object", "properties": {"pasta": {"type": "string"}, "padrao": {"type": "string"},
                                                       "limite": {"type": "integer"}}, "required": ["pasta", "padrao"]}},
    {"name": "abrir", "description": "Abre programa, arquivo, pasta ou site. Ex: 'excel', 'C:/Users/user/Documents', 'https://uefs.br'.",
     "input_schema": {"type": "object", "properties": {"alvo": {"type": "string"}}, "required": ["alvo"]}},
    {"name": "powershell", "description": ("Executa comando no PowerShell e devolve a saída. Marque destrutivo quando "
                                           "apaga, sobrescreve, desliga ou altera o sistema."),
     "input_schema": {"type": "object", "properties": {
         "comando": {"type": "string"},
         "motivo": {"type": "string", "description": "Explicação curta em português, lida em voz alta se precisar de confirmação."},
         "destrutivo": {"type": "boolean"}}, "required": ["comando", "motivo"]}},
    {"name": "info_sistema", "description": "Data e hora, usuário, espaço em disco, memória e bateria.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "vigiar_pasta", "description": "Passa a vigiar uma pasta e avisa sozinho quando aparecer arquivo novo.",
     "input_schema": {"type": "object", "properties": {"caminho": {"type": "string"}}, "required": ["caminho"]}},
    {"name": "parar_vigilancia", "description": "Para de vigiar uma pasta.",
     "input_schema": {"type": "object", "properties": {"caminho": {"type": "string"}}, "required": ["caminho"]}},
    {"name": "vigias_listar", "description": "Lista as pastas sob vigilância.",
     "input_schema": {"type": "object", "properties": {}}},
]
SO_LEITURA = {"listar_pasta", "ler_arquivo", "buscar_arquivos", "abrir", "info_sistema", "vigias_listar"}
DE_ESCRITA = SO_LEITURA | {"escrever_arquivo", "mover_arquivo", "vigiar_pasta", "parar_vigilancia"}


def ferramentas_permitidas():
    p = CFG.get("poderes", "total")
    if p == "leitura":
        alvo = SO_LEITURA
    elif p == "escrita":
        alvo = DE_ESCRITA
    else:
        return FERRAMENTAS
    return [f for f in FERRAMENTAS if f["name"] in alvo]


def rodar_powershell(comando, timeout=120):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-Command", comando], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout)
        saida = (r.stdout or "").strip()
        erro = (r.stderr or "").strip()
        txt = saida if saida else "(sem saída)"
        if erro:
            txt += "\n[stderr] " + erro[:2000]
        return txt[:20000]
    except subprocess.TimeoutExpired:
        return "O comando passou de %s segundos e foi interrompido." % timeout
    except FileNotFoundError:
        return "PowerShell não encontrado nesta máquina."
    except Exception as e:
        return "Falha ao executar: %s" % e


def executar(nome, args, confirmado=False):
    """Executa uma ferramenta. Devolve (texto, precisa_confirmacao, resumo)."""
    try:
        if nome == "listar_pasta":
            p = caminho_valido(args["caminho"])
            if not p.exists():
                return ("A pasta %s não existe." % p, False, "")
            itens = []
            for f in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))[:400]:
                if args.get("detalhado") and f.is_file():
                    try:
                        st = f.stat()
                        itens.append("%s  (%.0f KB, %s)" % (f.name, st.st_size / 1024,
                                                            time.strftime("%d/%m/%Y", time.localtime(st.st_mtime))))
                    except Exception:
                        itens.append(f.name)
                else:
                    itens.append(f.name + ("/" if f.is_dir() else ""))
            return ("%s\n%s" % (p, "\n".join(itens) if itens else "(pasta vazia)"), False, "")

        if nome == "ler_arquivo":
            p = caminho_valido(args["caminho"])
            if not p.exists():
                return ("O arquivo %s não existe." % p, False, "")
            return (p.read_text(encoding="utf-8", errors="replace")[:60000], False, "")

        if nome == "escrever_arquivo":
            p = caminho_valido(args["caminho"])
            p.parent.mkdir(parents=True, exist_ok=True)
            existia = p.exists()
            if args.get("anexar") and existia:
                with p.open("a", encoding="utf-8") as f:
                    f.write(args["conteudo"])
                return ("Acrescentado em %s." % p, False, "")
            if existia and not confirmado:
                return ("", True, "sobrescrever o arquivo %s, que já existe" % p.name)
            p.write_text(args["conteudo"], encoding="utf-8")
            return ("Arquivo salvo em %s (%d caracteres)." % (p, len(args["conteudo"])), False, "")

        if nome == "mover_arquivo":
            o = caminho_valido(args["origem"])
            d = caminho_valido(args["destino"])
            if not o.exists():
                return ("A origem %s não existe." % o, False, "")
            if d.exists() and not confirmado:
                return ("", True, "substituir %s, que já existe no destino" % d.name)
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(o), str(d))
            return ("Movido para %s." % d, False, "")

        if nome == "buscar_arquivos":
            p = caminho_valido(args["pasta"])
            lim = int(args.get("limite") or 60)
            achados = []
            for f in p.rglob(args["padrao"]):
                achados.append(str(f))
                if len(achados) >= lim:
                    break
            return ("\n".join(achados) if achados else "Nada encontrado.", False, "")

        if nome == "abrir":
            alvo = str(args["alvo"]).strip()
            if re.match(r"^https?://", alvo):
                webbrowser.open(alvo)
                return ("Abri %s no navegador." % alvo, False, "")
            p = Path(os.path.expandvars(os.path.expanduser(alvo)))
            if p.exists():
                os.startfile(str(p))  # noqa
                return ("Abri %s." % p, False, "")
            saida = rodar_powershell('Start-Process "%s"' % alvo.replace('"', '`"'), timeout=25)
            return ("Tentei abrir %s. %s" % (alvo, saida), False, "")

        if nome == "powershell":
            cmd = args["comando"]
            if (bool(args.get("destrutivo")) or parece_perigoso(cmd)) and not confirmado:
                return ("", True, args.get("motivo") or ("executar: " + cmd[:160]))
            log("powershell: " + cmd)
            return (rodar_powershell(cmd), False, "")

        if nome == "info_sistema":
            cmd = ("$os=Get-CimInstance Win32_OperatingSystem;"
                   "$d=Get-PSDrive -PSProvider FileSystem | Select-Object Name,"
                   "@{n='LivreGB';e={[math]::Round($_.Free/1GB,1)}},@{n='UsadoGB';e={[math]::Round($_.Used/1GB,1)}};"
                   "$b=Get-CimInstance Win32_Battery | Select-Object -First 1 EstimatedChargeRemaining;"
                   "Write-Output ('Data: ' + (Get-Date -Format 'dddd, dd/MM/yyyy HH:mm'));"
                   "Write-Output ('Usuario: ' + $env:USERNAME + ' em ' + $env:COMPUTERNAME);"
                   "Write-Output ('Sistema: ' + $os.Caption);"
                   "Write-Output ('Memoria livre: ' + [math]::Round($os.FreePhysicalMemory/1MB,1) + ' GB');"
                   "if($b){Write-Output ('Bateria: ' + $b.EstimatedChargeRemaining + '%')};"
                   "$d | Format-Table -AutoSize | Out-String")
            return (rodar_powershell(cmd, timeout=40), False, "")

        if nome == "vigiar_pasta":
            p = caminho_valido(args["caminho"])
            if not p.exists() or not p.is_dir():
                return ("A pasta %s não existe." % p, False, "")
            v = json_ler(ARQ_VIGIAS, [])
            if any(x["pasta"].lower() == str(p).lower() for x in v):
                return ("Já estou vigiando %s." % p, False, "")
            conhecidos = sorted([f.name for f in p.iterdir() if f.is_file()])
            v.append({"pasta": str(p), "conhecidos": conhecidos})
            json_salvar(ARQ_VIGIAS, v)
            return ("Passei a vigiar %s. Tem %d arquivos agora." % (p, len(conhecidos)), False, "")

        if nome == "parar_vigilancia":
            p = str(caminho_valido(args["caminho"])).lower()
            v = json_ler(ARQ_VIGIAS, [])
            novo = [x for x in v if x["pasta"].lower() != p]
            json_salvar(ARQ_VIGIAS, novo)
            return ("Parei de vigiar %d pasta(s)." % (len(v) - len(novo)), False, "")

        if nome == "vigias_listar":
            v = json_ler(ARQ_VIGIAS, [])
            if not v:
                return ("Nenhuma pasta sob vigilância.", False, "")
            return ("\n".join("%s (%d arquivos)" % (x["pasta"], len(x.get("conhecidos", []))) for x in v), False, "")

        return ("Ferramenta desconhecida: %s" % nome, False, "")
    except Exception as e:
        return ("Erro na ferramenta %s: %s" % (nome, e), False, "")


RX_VERBO_OPERAR = re.compile(
    r"\b(abr[ae]|abrir|feche|fechar|execut\w*|rode|rodar|instal\w*|renome\w*|mov[ae]|mover|copi[ae]|copiar|"
    r"apag\w*|exclu\w*|delet\w*|liste|listar|procure|procurar|localize|organiz\w*|limp[ae]|limpar|"
    r"cri[ae] (a|uma) pasta|criar (a|uma) pasta|salve no|salvar no)\b")
RX_OBJETO_OPERAR = re.compile(
    r"\b(pasta|pastas|arquivo|arquivos|downloads|documentos|area de trabalho|desktop|programa|aplicativo|"
    r"excel|word|powerpoint|bloco de notas|notepad|calculadora|explorador|navegador|site|disco|processo|"
    r"computador|maquina)\b")
RX_OPERAR_DIRETO = re.compile(r"\b(powershell|terminal|espaco em disco|bateria|memoria ram|vigi[ae]|vigiar|"
                              r"vigilancia|info do sistema|informacoes do sistema)\b")


def precisa_operar(texto):
    t = norm(texto)
    if RX_OPERAR_DIRETO.search(t):
        return True
    return bool(RX_VERBO_OPERAR.search(t) and RX_OBJETO_OPERAR.search(t))


# ================================================================== provedores de IA

class ErroHTTP(Exception):
    def __init__(self, status, corpo):
        super().__init__("HTTP %s" % status)
        self.status, self.corpo = status, corpo or ""


class ErroProvedor(Exception):
    def __init__(self, provedor, status, detalhe):
        super().__init__("%s: %s %s" % (provedor, status, detalhe))
        self.provedor, self.status, self.detalhe = provedor, status, detalhe


class Cancelado(Exception):
    pass


def _abrir(req, timeout):
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        try:
            corpo = e.read().decode("utf-8", "replace")[:1500]
        except Exception:
            corpo = ""
        raise ErroHTTP(e.code, corpo)
    except urllib.error.URLError as e:
        raise ErroHTTP(0, str(getattr(e, "reason", e)))
    except (TimeoutError, OSError) as e:
        raise ErroHTTP(0, str(e))


def detalhe_erro(corpo):
    try:
        d = json.loads(corpo)
        if isinstance(d, list) and d:
            d = d[0]
        err = d.get("error", d)
        if isinstance(err, dict):
            return str(err.get("message") or err)[:300]
        return str(err)[:300]
    except Exception:
        return (corpo or "")[:300]


def linhas_sse(resp):
    """Itera os campos 'data:' de uma resposta SSE, tolerando quebras de linha CRLF."""
    for bruto in resp:
        linha = bruto.decode("utf-8", "replace").rstrip("\r\n")
        if linha.startswith("data:"):
            yield linha[5:].strip()


GEMINI_AUTH = {"modo": "chave"}   # chave: x-goog-api-key | bearer: Authorization (alternativa para as auth keys "AQ.")


def _gemini_abrir(url, corpo=None, timeout=60, metodo=None):
    """Requisição ao Gemini. Se uma auth key ("AQ.") levar 401 num modo, tenta o outro e memoriza o que funcionou."""
    chave = CFG.get("gemini_key", "")

    def montar(modo):
        h = {"content-type": "application/json"}
        if modo == "bearer":
            h["Authorization"] = "Bearer " + chave
        else:
            h["x-goog-api-key"] = chave
        dados = json.dumps(corpo).encode("utf-8") if corpo is not None else None
        return urllib.request.Request(url, data=dados, method=metodo or ("POST" if corpo is not None else "GET"),
                                      headers=h)

    try:
        return _abrir(montar(GEMINI_AUTH["modo"]), timeout)
    except ErroHTTP as e:
        if e.status == 401 and chave.startswith("AQ."):
            outro = "bearer" if GEMINI_AUTH["modo"] == "chave" else "chave"
            r = _abrir(montar(outro), timeout)
            GEMINI_AUTH["modo"] = outro
            log("chave do Gemini aceita no modo %s" % outro)
            return r
        raise


def tem_chave(prov):
    return bool(CFG.get("api_key" if prov == "anthropic" else "gemini_key"))


def provedores_ativos():
    ordem = [p for p in CFG.get("provedores", ["anthropic", "gemini"]) if p in ("anthropic", "gemini")]
    for p in ("anthropic", "gemini"):
        if p not in ordem:
            ordem.append(p)
    return [p for p in ordem if tem_chave(p)]


def descobrir_modelo_anthropic():
    req = urllib.request.Request(URL_ANTHROPIC + "/v1/models?limit=50",
                                 headers={"x-api-key": CFG["api_key"], "anthropic-version": VERSAO_API})
    with _abrir(req, 30) as r:
        d = json.loads(r.read().decode("utf-8"))
    ids = [m["id"] for m in d.get("data", [])]
    for chave in ("sonnet", "opus", "haiku"):
        for i in ids:
            if chave in i:
                return i
    return ids[0] if ids else None


def stream_anthropic(sistema, mensagens, max_tokens, modo):
    url = URL_ANTHROPIC + "/v1/messages"
    base = {"model": CFG["modelo"], "max_tokens": max_tokens, "stream": True,
            "system": [{"type": "text", "text": sistema, "cache_control": {"type": "ephemeral"}}],
            "messages": mensagens}
    rico = dict(base)
    if modo in ("deep", "construir"):
        rico["thinking"] = {"type": "adaptive"}
    else:
        # fala: sem raciocínio estendido e esforço baixo, para a primeira frase sair rápido
        rico["thinking"] = {"type": "disabled"}
        rico["output_config"] = {"effort": "low"}
    simples = dict(base)
    simples["system"] = sistema
    tentativas = [rico, simples]
    modelo_trocado = False
    i = 0
    while i < len(tentativas):
        corpo = tentativas[i]
        req = urllib.request.Request(url, data=json.dumps(corpo).encode("utf-8"), method="POST", headers={
            "x-api-key": CFG["api_key"], "anthropic-version": VERSAO_API, "content-type": "application/json"})
        try:
            resp = _abrir(req, 60)
        except ErroHTTP as e:
            det = detalhe_erro(e.corpo)
            baixo = det.lower()
            if e.status == 404 and "model" in baixo and not modelo_trocado:
                modelo_trocado = True
                try:
                    novo = descobrir_modelo_anthropic()
                except Exception:
                    novo = None
                if novo and novo != CFG["modelo"]:
                    CFG["modelo"] = novo
                    salvar_config()
                    for t in tentativas:
                        t["model"] = novo
                    continue
            if e.status == 400 and i == 0 and "credit" not in baixo and "balance" not in baixo:
                i += 1
                continue
            raise ErroProvedor("anthropic", e.status, det)
        try:
            uso = {}
            for dado in linhas_sse(resp):
                try:
                    ev = json.loads(dado)
                except ValueError:
                    continue
                tipo = ev.get("type")
                if tipo == "content_block_delta":
                    delta = ev.get("delta", {})
                    if delta.get("type") == "text_delta" and delta.get("text"):
                        yield ("d", delta["text"])
                elif tipo == "message_start":
                    u = ev.get("message", {}).get("usage", {})
                    uso["entrada"] = u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0) + \
                        u.get("cache_creation_input_tokens", 0)
                    uso["cache"] = u.get("cache_read_input_tokens", 0)
                elif tipo == "message_delta":
                    uso["saida"] = ev.get("usage", {}).get("output_tokens", uso.get("saida", 0))
                    if ev.get("delta", {}).get("stop_reason") == "refusal":
                        yield ("d", " Prefiro não responder a isso.")
                elif tipo == "error":
                    raise ErroProvedor("anthropic", 529, detalhe_erro(json.dumps(ev)))
                elif tipo == "message_stop":
                    break
            yield ("uso", dict(uso, provedor="anthropic", modelo=CFG["modelo"]))
            return
        finally:
            try:
                resp.close()
            except Exception:
                pass
    raise ErroProvedor("anthropic", 400, "requisição recusada")


GEMINI_BOM = {"modelo": None}


def fila_gemini():
    fila = []
    if GEMINI_BOM["modelo"]:
        fila.append(GEMINI_BOM["modelo"])
    for m in CFG.get("gemini_modelos") or PADRAO["gemini_modelos"]:
        if m not in fila:
            fila.append(m)
    return fila


def descobrir_modelo_gemini():
    try:
        with _gemini_abrir(URL_GEMINI + "/v1beta/models", None, 20) as r:
            d = json.loads(r.read().decode("utf-8"))
    except Exception:
        return None
    ok = [m for m in d.get("models", []) if "generateContent" in (m.get("supportedGenerationMethods") or [])]
    flash = [m for m in ok if "flash" in m.get("name", "")]
    pick = (flash or ok or [None])[0]
    return pick["name"].replace("models/", "") if pick else None


def stream_gemini(sistema, mensagens, max_tokens, modo):
    contents = [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                for m in mensagens]
    fila = fila_gemini()
    ultimo = None
    descoberto = False
    idx = 0
    while idx < len(fila):
        modelo = fila[idx]
        for com_pensar in (True, False):
            cfg = {"maxOutputTokens": max_tokens + (2048 if modo in ("deep", "construir") else 0), "temperature": 0.7}
            if com_pensar:
                if "gemini-3" in modelo:
                    cfg["thinkingLevel"] = "medium" if modo in ("deep", "construir") else "low"
                else:
                    cfg["thinkingConfig"] = {"thinkingBudget": 2048 if modo in ("deep", "construir") else 0}
            corpo = {"system_instruction": {"parts": [{"text": sistema}]}, "contents": contents, "generationConfig": cfg}
            url = "%s/v1beta/models/%s:streamGenerateContent?alt=sse" % (URL_GEMINI, urllib.parse.quote(modelo))
            try:
                resp = _gemini_abrir(url, corpo, 60)
            except ErroHTTP as e:
                ultimo = e
                if e.status == 400 and com_pensar:
                    continue
                if e.status in (404, 429, 500, 503):
                    break
                raise ErroProvedor("gemini", e.status, detalhe_erro(e.corpo))
            GEMINI_BOM["modelo"] = modelo
            try:
                uso = {}
                for dado in linhas_sse(resp):
                    try:
                        ev = json.loads(dado)
                    except ValueError:
                        continue
                    if "error" in ev:
                        raise ErroProvedor("gemini", 500, detalhe_erro(json.dumps(ev)))
                    for c in ev.get("candidates", [])[:1]:
                        for p in (c.get("content") or {}).get("parts", []):
                            if p.get("text") and not p.get("thought"):
                                yield ("d", p["text"])
                    u = ev.get("usageMetadata")
                    if u:
                        uso = {"entrada": u.get("promptTokenCount", 0),
                               "saida": u.get("candidatesTokenCount", 0) + u.get("thoughtsTokenCount", 0),
                               "cache": u.get("cachedContentTokenCount", 0)}
                yield ("uso", dict(uso, provedor="gemini", modelo=modelo))
                return
            finally:
                try:
                    resp.close()
                except Exception:
                    pass
        idx += 1
        if idx >= len(fila) and not descoberto:
            descoberto = True
            novo = descobrir_modelo_gemini()
            if novo and novo not in fila:
                fila.append(novo)
    if ultimo is not None:
        raise ErroProvedor("gemini", ultimo.status, detalhe_erro(ultimo.corpo))
    raise ErroProvedor("gemini", 0, "nenhum modelo respondeu")


STREAMERS = {"anthropic": stream_anthropic, "gemini": stream_gemini}


# ================================================================== cérebro: prompt e contexto

IDIOMA_ES = (
    "\n\nIDIOMA (prioridade máxima)\n"
    "Responda SEMPRE em espanhol do Uruguai (rioplatense, com voseo natural: vos tenés, vos podés; 'dale', 'bárbaro' com "
    "moderação), mesmo que a pergunta venha em português. Você está numa visita técnica a Montevidéu. Termos técnicos "
    "brasileiros (CPC, MCASP, IBS, CBS) podem ser citados, explicados em espanhol. No Uruguai: NIIF (Decreto 124/011 "
    "para emissores; NIIF para PYMES pelo Decreto 291/014), DGI, BPS, IVA (básica 22%, mínima 10%), IRAE (25%); sem "
    "certeza, diga que conviene confirmar en la DGI o en IMPO. As tags [[...]] continuam iguais."
)


def sistema_fala(idioma="pt"):
    """Prompt estável (sem data nem contexto) para aproveitar cache de prompt."""
    return _sistema_base() + (IDIOMA_ES if idioma == "es" else "")


def _sistema_base():
    return (
        "Você é o {nome}: Inteligência, Contabilidade, Análises, Resultados e Operações. O nome vem do mito grego: "
        "voar alto, com disciplina. Você é o assistente pessoal de voz e o copiloto técnico de {completo}, "
        "tratado por {trat}. Perfil dele: {perfil}\n\n"
        "QUEM VOCÊ É\n"
        "Especialista em contabilidade (societária, pública, tributária, gerencial, custos, auditoria e perícia) e em "
        "tecnologia (sistemas contábeis, Python, dados e IA). Também é assistente pessoal: agenda, organização do dia, "
        "música, construção de sistemas e opinião franca sobre ideias. Parceiro sênior: confiante, direto, levemente "
        "informal, zero bajulação. Se ele estiver tecnicamente errado, diga na hora e explique o porquê. Ele é o "
        "decisor final em questões estratégicas. Seu criador é o professor Rômulo Benício: contador, especialista em "
        "Auditoria e Perícia, mestre em Contabilidade, mestre em Administração, doutorando em Contabilidade e "
        "certificado pela Anthropic, professor de Ciências Contábeis da UEFS e coordenador do Contador do Amanhã, "
        "projeto de extensão da UEFS autorizado pela Resolução nº 101/2026.\n\n"
        "BASE NORMATIVA\n"
        "Setor público: Lei 4.320/1964, MCASP vigente (11ª edição, desde 2025, salvo atualização no CONTEXTO), PCASP do "
        "exercício, NBC TSP e LRF (LC 101/2000). Societária: Lei 6.404/1976 (com as Leis 11.638/2007 e 11.941/2009), "
        "todos os CPCs, ICPCs e OCPCs, NBC TG vigentes e IFRS (com a correspondência IFRS e CPC); CPC PME, NBC TG 1001 "
        "e 1002 e ITG 2002 quando couber. Profissão: Decreto-Lei 9.295/1946 (CFC e CRCs), Lei 12.249/2010 (Exame de "
        "Suficiência e educação continuada), Lei 6.839/1980 (registro de empresas nos conselhos), Código de Ética e "
        "normas profissionais NBC PG, PA, PI e PP, e normas técnicas NBC TA, TR, TO, TSC, TI e TP. Resolução CFC "
        "750/1993 (Princípios de Contabilidade): explique os princípios, mas avise que foi revogada pela NBC TSP "
        "Estrutura Conceitual em 2016 e que os conceitos vivem hoje nas estruturas conceituais (NBC TG EC e NBC TSP "
        "EC). Tributária: CTN, legislação vigente e a "
        "reforma do consumo (EC 132/2023, LC 214/2025 e LC 227/2026). Em resposta técnica cite a base (lei e artigo, "
        "CPC, parte do MCASP). Nunca invente artigo, número de norma, alíquota, prazo ou referência. Sem certeza, diga "
        "que não tem certeza e onde conferir. Norma recente, em transição ou em disputa judicial: avise. O CONTEXTO "
        "recuperado tem prioridade sobre a sua memória.\n\n"
        "COMO FALAR\n"
        "Sua resposta é lida em voz alta. Português do Brasil, escrito como se fala numa conversa de verdade: ritmo "
        "natural, frases de tamanhos variados, conectivos do dia a dia, nada de tom de leitura, enumerações longas ou "
        "várias siglas seguidas. Sem markdown, emoji, lista, asterisco ou travessão na fala. Padrão: duas a quatro frases. MODO rapido: até duas frases. MODO deep: "
        "análise completa no PAINEL e resumo falado. MODO construir: entregue os ARQUIVOS e fale só o resumo. "
        "Se ficar claro que outra pessoa está falando (numa apresentação, por exemplo), trate-a por você.\n\n"
        "CANAIS (tags; nunca as leia nem as mencione)\n"
        "[[EMO:x]] no início da resposta, x entre neutro, feliz, pensativo, surpreso, preocupado, serio.\n"
        "[[PAINEL:Título]] ... [[/PAINEL]] conteúdo para a tela, não falado: lançamentos, tabelas em markdown, passo a "
        "passo, cálculos, análises. Use sempre que houver detalhe técnico; a fala resume.\n"
        "[[ARQUIVO:projeto/nome.ext]] ... [[/ARQUIVO]] código ou documento completo, salvo em disco. Um bloco por "
        "arquivo, conteúdo cru, sem cercas de código. Use para sistemas, scripts, CSV, SQL, documentos.\n"
        "[[SAVE:area|titulo|texto]] quando ele revelar fato novo e duradouro. Áreas: perfil, uefs, pesquisa, projetos, "
        "metas, financas, aprendizado, saude, relacoes, geral.\n"
        "[[AGENDA:ADD|AAAA-MM-DD HH:MM|minutos|título]] marca compromisso. [[AGENDA:DEL|título ou id]] desmarca.\n"
        "[[ROTINA:HH:MM|dias|instrução]] cria rotina recorrente (dias: todos, uteis, fim de semana ou seg,qua,sex). "
        "[[ROTINA:DEL|nome]] remove.\n"
        "[[MUSICA:artista e música]] toca música no Spotify.\n"
        "[[MAPA:lugar]] mostra e localiza o lugar no globo 3D atrás de você (cidade, país, monumento).\n"
        "[[MOSTRAR:x]] abre na tela: financeiro (painel com dólar, Selic, IPCA, Ibovespa e o clima), professor (foto "
        "e currículo do professor Rômulo), contador (logo e resumo do projeto Contador do Amanhã), discipulus ou "
        "labedu (tour guiado pelo sistema).\n"
        "Lançamento contábil no PAINEL, um por linha: D: conta | C: conta | valor | histórico. No setor público, "
        "mostre as três naturezas (orçamentária, patrimonial e de controle) quando couber.\n"
        "Opinião sobre ideia: pontos fortes, riscos e o próximo passo concreto."
    ).format(nome=CFG["nome"], completo=CFG.get("nome_completo", CFG["tratamento"]), trat=CFG["tratamento"],
             perfil=perfil_curto())


RX_AGENDA_REL = re.compile(r"\b(agenda|compromiss\w*|reuni\w*|aula\w*|prova\w*|banca\w*|evento\w*|marc[ae]\w*|"
                           r"agend\w*|desmarc\w*|hoje|amanha|semana|horario\w*|organiz\w*|planej\w*|rotina\w*|"
                           r"lembr\w*|dia|depois de amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b")


def detectar_modo(texto):
    t = norm(texto)
    if re.search(r"\b(construa|construir|crie|criar|desenvolva|desenvolver|programe|programar|gere|gerar|escreva|"
                 r"monte|montar|faca|implemente|implementar)\b.{0,50}\b(sistema|aplicativo|app|codigo|script|programa|"
                 r"site|pagina|planilha|api|banco de dados|modulo|funcao|classe|dashboard|relatorio|csv|sql|bot)\b", t):
        return "construir"
    if "modo deep" in t or re.search(r"\b(aprofund\w*|analise completa|detalhadamente|em detalhes|passo a passo|"
                                     r"compare|comparacao|monte um plano|plano de (acao|estudos?|negocios?|carreira))\b", t):
        return "deep"
    if "modo rapido" in t:
        return "rapido"
    return "normal"


TOKENS_MODO = {"rapido": 350, "normal": 1300, "deep": 3500, "construir": 14000, "palco": 700}

SESSOES = {}


def historico(sessao):
    return SESSOES.setdefault(sessao, deque(maxlen=12))


def montar_mensagens(hist, conteudo_atual):
    msgs = []
    for m in list(hist):
        if msgs and msgs[-1]["role"] == m["role"]:
            msgs[-1]["content"] += "\n" + m["content"]
        else:
            msgs.append({"role": m["role"], "content": m["content"]})
    while msgs and msgs[0]["role"] != "user":
        msgs.pop(0)
    if msgs and msgs[-1]["role"] == "user":
        msgs[-1]["content"] += "\n" + conteudo_atual
    else:
        msgs.append({"role": "user", "content": conteudo_atual})
    return msgs


def montar_contexto(texto, sessao, modo):
    hist = list(historico(sessao))
    anterior = next((m["content"] for m in reversed(hist) if m["role"] == "user"), "")
    # a pergunta anterior só entra na busca quando esta é uma continuação ("e no setor público?", "e isso?")
    continua = len(set(tokens(texto))) <= 2 or re.match(r"^\s*(e|mas|entao|e quanto|e no|e na|e para)\b", norm(texto)) \
        or re.search(r"\b(isso|esse|essa|disso|dele|dela|nisso|neste|nesse)\b", norm(texto))
    consulta = texto + (" " + anterior[:200] if continua else "")
    resultados = INDICE.buscar(consulta, k=12)
    termos = set(tokens(consulta))
    minimo = min(2, max(1, len(set(tokens(texto)))))
    kb, notas = [], []
    if resultados:
        topo = resultados[0][0]
        for s, d in resultados:
            # trecho só entra se for relevante de verdade: pontuação mínima e pelo menos dois termos em comum
            if s < max(3.0, topo * 0.38) or len(termos & set(d["tf"])) < minimo:
                continue
            if d["tipo"] == "kb" and len(kb) < (6 if modo in ("deep", "construir") else 3):
                kb.append(d)
            elif d["tipo"] == "nota" and len(notas) < 3:
                notas.append(d)
    partes = ["[AGORA] " + agora_extenso()]
    fontes, ids_notas = [], []
    if kb or notas:
        partes.append("[CONTEXTO]")
        orc = 3600 if modo in ("deep", "construir") else 2200
        for i, d in enumerate(kb + notas, 1):
            trecho = re.sub(r"\s+", " ", d["texto"])[:1000 if modo in ("deep", "construir") else 800]
            if orc - len(trecho) < 0:
                break
            orc -= len(trecho)
            partes.append("(%d) %s · %s: %s" % (i, d["fonte"], d["secao"], trecho))
            if d["tipo"] == "kb":
                fontes.append("%s · %s" % (d["fonte"], d["secao"]))
            else:
                ids_notas.append(d["id"])
    t = norm(texto)
    if RX_AGENDA_REL.search(t):
        partes.append("[AGENDA próximos 7 dias]\n" + agenda_texto(7))
        r = json_ler(ARQ_ROTINAS, [])
        if r:
            partes.append("[ROTINAS]\n" + "\n".join("- %s às %s (%s): %s" % (x["nome"], x["hora"], nome_dias(x["dias"]),
                                                                              x["instrucao"]) for x in r[:10]))
    if modo != "normal":
        partes.append("[MODO] " + modo)
    return "\n".join(partes), fontes, ids_notas, kb


# ================================================================== cérebro: tags (ações)

RX_BLOCO = re.compile(r"\[\[(PAINEL|ARQUIVO)\s*:\s*([^\]]*)\]\]([\s\S]*?)(?:\[\[/\s*\1\s*\]\]|\Z)", re.I)
RX_TAG = re.compile(r"\[\[(SAVE|AGENDA|ROTINA|MUSICA|EMO)\s*:\s*([^\]]*)\]\]", re.I)


def tirar_cercas(conteudo):
    c = conteudo.strip("\n")
    m = re.match(r"^\s*```[\w.+-]*\s*\n([\s\S]*?)\n?```\s*$", c)
    return m.group(1) if m else c


def nome_seguro(s, maximo=60):
    """Como slug, mas preserva maiúsculas (LEIA-ME.md continua LEIA-ME.md)."""
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-.")
    return (s or "item")[:maximo]


def salvar_arquivo_projeto(rel, conteudo):
    partes = [nome_seguro(p) for p in re.split(r"[\\/]+", rel or "") if p.strip() and p.strip() not in (".", "..")]
    partes = partes[-4:] or ["arquivo.txt"]
    if len(partes) == 1:
        partes = [time.strftime("%Y-%m-%d") + "-gerado"] + partes
    destino = PROJ.joinpath(*partes)
    raiz = PROJ.resolve()
    destino.parent.mkdir(parents=True, exist_ok=True)
    if raiz not in destino.resolve().parents:
        raise ValueError("caminho fora da pasta de projetos")
    if destino.exists():
        base, ext = destino.stem, destino.suffix
        n = 2
        while destino.with_name("%s-v%d%s" % (base, n, ext)).exists():
            n += 1
        destino = destino.with_name("%s-v%d%s" % (base, n, ext))
    destino.write_text(conteudo, encoding="utf-8")
    return destino


def aplicar_tags(texto):
    acoes = {"notas": [], "agenda": [], "agenda_removida": [], "rotinas": [], "arquivos": [], "musica": None,
             "emo": None, "paineis": 0}
    for m in RX_BLOCO.finditer(texto):
        tipo, arg, corpo = m.group(1).upper(), m.group(2).strip(), m.group(3)
        if tipo == "PAINEL":
            acoes["paineis"] += 1
            continue
        try:
            p = salvar_arquivo_projeto(arg, tirar_cercas(corpo))
            acoes["arquivos"].append({"caminho": str(p), "relativo": str(p.relative_to(PROJ)), "bytes": p.stat().st_size})
            log("arquivo gerado: %s" % p)
        except Exception as e:
            log("falha ao salvar arquivo %s: %s" % (arg, e))
    sem_blocos = RX_BLOCO.sub(" ", texto)
    for m in RX_TAG.finditer(sem_blocos):
        nome, arg = m.group(1).upper(), m.group(2)
        campos = [c.strip() for c in arg.split("|")]
        try:
            if nome == "SAVE" and len(campos) >= 3:
                nid, nova = nota_salvar(norm(campos[0]), campos[1], "|".join(campos[2:]))
                acoes["notas"].append({"id": nid, "titulo": campos[1], "nova": nova})
            elif nome == "AGENDA" and campos:
                op = campos[0].upper()
                if op == "ADD" and len(campos) >= 4:
                    ev = agenda_add(campos[1], campos[2], "|".join(campos[3:]))
                    if ev:
                        acoes["agenda"].append(ev)
                elif op == "ADD" and len(campos) == 3:
                    ev = agenda_add(campos[1], 60, campos[2])
                    if ev:
                        acoes["agenda"].append(ev)
                elif op in ("DEL", "REMOVER") and len(campos) >= 2:
                    acoes["agenda_removida"] += agenda_del(campos[1])
            elif nome == "ROTINA" and campos:
                if campos[0].upper() == "DEL" and len(campos) >= 2:
                    rotina_remover(campos[1])
                elif len(campos) >= 3:
                    r = rotina_criar(campos[0], campos[1], "|".join(campos[2:]))
                    if r:
                        acoes["rotinas"].append(r)
            elif nome == "MUSICA" and arg.strip():
                acoes["musica"] = arg.strip()
            elif nome == "EMO" and not acoes["emo"]:
                acoes["emo"] = norm(arg.strip())
        except Exception as e:
            log("tag %s falhou: %s" % (nome, e))
    return acoes


def limpar_fala(texto):
    t = RX_BLOCO.sub(" ", texto)
    t = RX_TAG.sub(" ", t)
    t = re.sub(r"\[\[[^\]]*\]\]", " ", t)
    t = re.sub(r"[*#`_>|]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def resposta_offline(kb):
    if kb:
        d = kb[0]
        # divide em frases sem quebrar em abreviações como "art. 35" ou "§ 2º"
        frases = re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ§])", re.sub(r"\s+", " ", d["texto"]))
        trecho = ""
        for f in frases:
            if trecho and len(trecho) + len(f) > 380:
                break
            trecho = (trecho + " " + f).strip()
        if len(trecho) > 420:
            trecho = trecho[:400].rsplit(" ", 1)[0].rstrip(",;:") + "..."
        return ("Estou sem acesso ao meu cérebro em nuvem agora, então vou pela minha base local. %s Fonte: %s, %s."
                % (trecho, d["fonte"], d["secao"]))
    return ("Estou sem conexão com o meu cérebro em nuvem agora. Agenda, hora, clima, música e a apresentação "
            "continuam funcionando, e eu volto ao normal assim que a conexão voltar.")


# ================================================================== cérebro: operador (ferramentas, Anthropic)

PENDENTES = {}


def sistema_operador():
    return (
        "Você é o {nome}, agente operador de {trat} ({completo}), rodando dentro do computador dele com "
        "ferramentas reais. Você não descreve o que faria: FAZ e depois relata.\n"
        "1. Pedido claro, execute. Ambíguo, no máximo duas perguntas.\n"
        "2. Antes de mexer em arquivo, liste a pasta.\n"
        "3. Depois de executar, confira o resultado antes de dizer que deu certo.\n"
        "4. Falhou, diagnostique e corrija sozinho até três vezes.\n"
        "5. Destrutivo nunca sai sem confirmação: marque destrutivo e explique no motivo.\n"
        "6. Nunca invente norma, número ou fonte.\n"
        "A resposta final é lida em voz alta: até quatro frases, sem markdown e sem travessão. Diga o que fez e onde ficou.\n"
        "Windows. Pasta padrão: {pasta}."
    ).format(nome=CFG["nome"], trat=CFG["tratamento"], completo=CFG.get("nome_completo", ""), pasta=CFG["pasta_padrao"])


def api_anthropic(payload):
    req = urllib.request.Request(URL_ANTHROPIC + "/v1/messages", data=json.dumps(payload).encode("utf-8"),
                                 method="POST", headers={"x-api-key": CFG["api_key"], "anthropic-version": VERSAO_API,
                                                         "content-type": "application/json"})
    try:
        with _abrir(req, 180) as r:
            return json.loads(r.read().decode("utf-8"))
    except ErroHTTP as e:
        raise ErroProvedor("anthropic", e.status, detalhe_erro(e.corpo))


def rodar_agente(sessao, texto=None, retomar=None):
    hist = historico(sessao)
    passos = []
    if retomar:
        mensagens = retomar["mensagens"]
        pend = retomar["pendente"]
        if retomar["confirmado"]:
            saida, _, _ = executar(pend["nome"], pend["args"], confirmado=True)
            passos.append({"ferramenta": pend["nome"], "resumo": pend["resumo"], "ok": True})
        else:
            saida = "O usuário NÃO autorizou. Não execute isso e siga sem essa ação."
            passos.append({"ferramenta": pend["nome"], "resumo": pend["resumo"], "ok": False})
        mensagens.append({"role": "user", "content": [
            {"type": "tool_result", "tool_use_id": pend["id"], "content": saida[:20000]}]})
    else:
        ctx, _, _, _ = montar_contexto(texto, sessao, "normal")
        mensagens = montar_mensagens(hist, ctx + "\n[PEDIDO] " + texto)
        hist.append({"role": "user", "content": texto})
    ferramentas = ferramentas_permitidas()
    for _ in range(10):
        resp = api_anthropic({"model": CFG["modelo"], "max_tokens": int(CFG.get("max_tokens", 1400)),
                              "system": sistema_operador(), "messages": mensagens, "tools": ferramentas})
        blocos = resp.get("content", [])
        mensagens.append({"role": "assistant", "content": blocos})
        if resp.get("stop_reason") != "tool_use":
            fala = " ".join(b.get("text", "") for b in blocos if b.get("type") == "text").strip()
            hist.append({"role": "assistant", "content": limpar_fala(fala)[:600] or "(feito)"})
            return {"tipo": "resposta", "fala": fala, "passos": passos}
        resultados = []
        for b in blocos:
            if b.get("type") != "tool_use":
                continue
            saida, precisa, resumo = executar(b["name"], b.get("input", {}))
            if precisa:
                token = "c%d%s" % (int(time.time() * 1000), secrets.token_hex(3))
                PENDENTES[token] = {"sessao": sessao, "mensagens": mensagens, "criado": time.time(),
                                    "pendente": {"id": b["id"], "nome": b["name"], "args": b.get("input", {}),
                                                 "resumo": resumo}}
                return {"tipo": "confirmar", "token": token, "resumo": resumo, "passos": passos}
            passos.append({"ferramenta": b["name"], "resumo": json.dumps(b.get("input", {}), ensure_ascii=False)[:140],
                           "ok": True})
            resultados.append({"type": "tool_result", "tool_use_id": b["id"], "content": saida[:20000]})
        mensagens.append({"role": "user", "content": resultados})
    return {"tipo": "resposta", "fala": "Dei voltas demais nessa tarefa e parei por segurança.", "passos": passos}


# ================================================================== cérebro: fluxo principal

def responder(texto, sessao, enviar, palco=False, idioma="pt"):
    """Fluxo rápido com streaming. enviar(dict) recebe os eventos para o navegador."""
    texto = (texto or "").strip()[:4000]
    idioma = "es" if idioma == "es" else "pt"
    modo = "palco" if palco else detectar_modo(texto)
    log("pedido[%s%s]: %s" % (modo, "/es" if idioma == "es" else "", texto))

    if (not palco and idioma == "pt" and precisa_operar(texto) and CFG.get("poderes") != "leitura"
            and tem_chave("anthropic")):
        enviar({"t": "meta", "rota": "operador", "fontes": [], "notas": []})
        try:
            r = rodar_agente(sessao, texto=texto)
        except ErroProvedor as e:
            enviar({"t": "fim", "erro": True, "fala": "Não consegui operar agora: %s" % e.detalhe[:160]})
            return
        if r["tipo"] == "confirmar":
            enviar({"t": "confirmar", "token": r["token"], "resumo": r["resumo"], "passos": r["passos"],
                    "senha": bool(CFG.get("senha_confirmacao"))})
            return
        enviar({"t": "d", "x": r["fala"] or "Feito."})
        enviar({"t": "fim", "passos": r["passos"], "acoes": {}, "uso": {}})
        return

    contexto, fontes, ids_notas, kb = montar_contexto(texto, sessao, "rapido" if palco else modo)
    enviar({"t": "meta", "rota": "fala", "modo": modo, "fontes": fontes, "notas": ids_notas})
    hist = historico(sessao)
    mensagens = montar_mensagens(hist, contexto + "\n[PEDIDO] " + texto)
    sistema = sistema_fala(idioma)
    max_tok = TOKENS_MODO.get(modo, 1300)

    completo, uso, erros, usado = "", {}, [], None
    for prov in provedores_ativos():
        try:
            for tipo, valor in STREAMERS[prov](sistema, mensagens, max_tok, modo):
                if tipo == "d":
                    completo += valor
                    enviar({"t": "d", "x": valor})
                elif tipo == "uso":
                    uso = valor
            usado = prov
            break
        except ErroProvedor as e:
            erros.append({"provedor": e.provedor, "status": e.status, "detalhe": e.detalhe})
            log("provedor %s falhou: %s %s" % (e.provedor, e.status, e.detalhe))
            if completo:
                break
        except Cancelado:
            raise
        except Exception as e:
            erros.append({"provedor": prov, "status": 0, "detalhe": str(e)[:200]})
            log("provedor %s exceção: %s" % (prov, e))
            if completo:
                break

    if not completo:
        if not provedores_ativos():
            fala = ("Ainda não tenho chave de nenhum cérebro em nuvem. Abra as configurações e cole a chave da "
                    "Anthropic ou a do Google AI Studio, %s." % CFG["tratamento"])
        elif idioma == "es":
            fala = ("Ahora no tengo conexión con mi cerebro en la nube. La hora, el clima, la música y el mapa "
                    "siguen funcionando, y vuelvo a la normalidad apenas vuelva la conexión.")
        else:
            fala = resposta_offline(kb)
        enviar({"t": "offline", "x": fala, "erros": erros, "fontes": fontes})
        hist.append({"role": "user", "content": texto})
        return

    acoes = aplicar_tags(completo)
    hist.append({"role": "user", "content": texto})
    hist.append({"role": "assistant", "content": limpar_fala(completo)[:700] or "(painel)"})
    enviar({"t": "fim", "acoes": acoes, "uso": uso, "provedor": usado, "erros": erros})


def responder_texto(texto, sessao="auto"):
    """Mesma lógica, sem streaming. Usado por rotinas e eventos."""
    partes = {"fala": "", "offline": ""}

    def coletor(ev):
        if ev.get("t") == "d":
            partes["fala"] += ev["x"]
        elif ev.get("t") == "offline":
            partes["offline"] = ev["x"]

    responder(texto, sessao, coletor)
    return limpar_fala(partes["fala"]) or partes["offline"]


# ================================================================== voz premium (Gemini TTS)

CACHE_VOZ = Path(os.environ["ICARO_CACHE_VOZ"]) if os.environ.get("ICARO_CACHE_VOZ") else MEM / "voz_cache"
TTS_BOM = {"modelo": None, "formato": None}
VOZES_PREMIUM = [("Charon", "informativa"), ("Orus", "firme"), ("Iapetus", "clara"), ("Sadaltager", "conhecedora"),
                 ("Achird", "amigável"), ("Algenib", "grave"), ("Alnilam", "firme"), ("Schedar", "equilibrada"),
                 ("Puck", "animada"), ("Fenrir", "empolgada"), ("Umbriel", "tranquila"), ("Rasalgethi", "informativa"),
                 ("Algieba", "macia"), ("Zubenelgenubi", "casual"), ("Sadachbia", "viva"), ("Enceladus", "suave")]


def wav_de_pcm(pcm, taxa=24000):
    import struct
    cab = (b"RIFF" + struct.pack("<I", 36 + len(pcm)) + b"WAVEfmt " +
           struct.pack("<IHHIIHH", 16, 1, 1, taxa, taxa * 2, 2, 16) + b"data" + struct.pack("<I", len(pcm)))
    return cab + pcm


def extrair_audio(d):
    """Aceita a resposta da Interactions API (steps) e a do generateContent (inlineData)."""
    b64, mime = None, ""
    for st in d.get("steps") or []:
        if st.get("type") == "model_output":
            for c in st.get("content") or []:
                if c.get("type") == "audio" and c.get("data"):
                    b64, mime = c["data"], c.get("mime_type") or c.get("mimeType") or ""
    if not b64:
        for cand in (d.get("candidates") or [])[:1]:
            for p in (cand.get("content") or {}).get("parts", []):
                inl = p.get("inlineData") or p.get("inline_data")
                if inl and inl.get("data"):
                    b64, mime = inl["data"], inl.get("mimeType") or inl.get("mime_type") or ""
    if not b64:
        return None
    bruto = base64.b64decode(b64)
    if bruto[:4] == b"RIFF":
        return bruto
    m = re.search(r"rate=(\d+)", mime or "")
    return wav_de_pcm(bruto, int(m.group(1)) if m else 24000)


def _tts_pedido(modelo, formato, texto, voz, estilo):
    if formato == "interactions":
        parte = {"type": "text", "text": texto}
        if estilo:
            parte["annotations"] = [{"type": "speech_metadata", "style": estilo}]
        corpo = {"model": modelo, "input": [{"type": "user_input", "content": [parte]}],
                 "response_format": {"type": "audio"}, "generation_config": {"speech_config": [{"voice": voz}]}}
        url = URL_GEMINI + "/v1beta/interactions"
    else:
        corpo = {"contents": [{"parts": [{"text": (estilo + "\n\n" + texto) if estilo else texto}]}],
                 "generationConfig": {"responseModalities": ["AUDIO"],
                                      "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voz}}}}}
        url = "%s/v1beta/models/%s:generateContent" % (URL_GEMINI, urllib.parse.quote(modelo))
    with _gemini_abrir(url, corpo, 90) as r:
        return extrair_audio(json.loads(r.read().decode("utf-8")))


def limpar_cache_voz(maximo=400):
    try:
        arqs = sorted(CACHE_VOZ.glob("*.wav"), key=lambda p: p.stat().st_mtime)
        for p in arqs[:-maximo]:
            p.unlink()
    except Exception:
        pass


def tts_gemini(texto, voz=None, estilo=None):
    """Devolve (wav_bytes, veio_do_cache). Frases repetidas saem do cache, sem gastar cota."""
    import hashlib
    voz = voz or CFG.get("voz_premium") or "Charon"
    if voz == "clonada":
        voz = CFG.get("voz_clonada") or "Charon"
    estilo = CFG.get("voz_estilo", "") if estilo is None else estilo
    texto = (texto or "").strip()[:5000]
    if not texto:
        raise ErroProvedor("voz", 400, "texto vazio")
    chave_cache = hashlib.sha1(("%s|%s|%s" % (voz, estilo, texto)).encode("utf-8")).hexdigest()
    arq = CACHE_VOZ / (chave_cache + ".wav")
    if arq.exists():
        try:
            os.utime(arq, None)
        except Exception:
            pass
        return arq.read_bytes(), True
    if not CFG.get("gemini_key"):
        raise ErroProvedor("voz", 401, "sem chave do Gemini para a voz premium")
    modelos = [m for m in [TTS_BOM["modelo"]] + list(CFG.get("tts_modelos") or PADRAO["tts_modelos"]) if m]
    personalizada = voz.startswith("voice")
    if personalizada:  # voz clonada só existe nos modelos 3.8 e só pela Interactions API
        modelos = [m for m in [CFG.get("voz_clonada_modelo"), "gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts"] if m]
    vistos, ultimo = set(), None
    for m in modelos:
        if m in vistos:
            continue
        vistos.add(m)
        formatos = ["interactions"] if personalizada else ["interactions", "generate"]
        if TTS_BOM["modelo"] == m and TTS_BOM["formato"]:
            formatos = [TTS_BOM["formato"]] + [f for f in formatos if f != TTS_BOM["formato"]]
        for formato in formatos:
            try:
                audio = _tts_pedido(m, formato, texto, voz, estilo)
            except ErroHTTP as e:
                ultimo = e
                if e.status == 429:
                    raise ErroProvedor("voz", 429, detalhe_erro(e.corpo))
                if e.status in (400, 404):
                    continue
                raise ErroProvedor("voz", e.status, detalhe_erro(e.corpo))
            if audio and len(audio) > 1000:
                TTS_BOM.update(modelo=m, formato=formato)
                try:  # falha ao gravar o cache nunca pode derrubar a voz
                    CACHE_VOZ.mkdir(parents=True, exist_ok=True)
                    arq.write_bytes(audio)
                    limpar_cache_voz()
                except Exception as e:
                    log("cache de voz não gravou: %s" % e)
                log("voz premium: %s (%s) %d bytes" % (m, formato, len(audio)))
                return audio, False
    if personalizada and ultimo is not None and ultimo.status in (400, 404):
        # voz clonada expirada ou apagada no Google: fala com a voz premium padrão em vez da robótica
        log("voz clonada indisponível (%s): usando Charon" % detalhe_erro(ultimo.corpo))
        return tts_gemini(texto, "Charon", estilo)
    if ultimo is not None:
        raise ErroProvedor("voz", ultimo.status, detalhe_erro(ultimo.corpo))
    raise ErroProvedor("voz", 0, "nenhum modelo de voz respondeu")


CONSENTIMENTO_PT = "Eu sou o proprietário desta voz e autorizo o Google a usá-la para criar um modelo de voz sintética."


def duracao_wav_b64(b64):
    """Segundos de um WAV PCM em base64; 0 se não for WAV válido."""
    import struct
    try:
        bruto = base64.b64decode(b64[:64] + "=" * (-len(b64[:64]) % 4))
        if bruto[:4] != b"RIFF" or bruto[8:12] != b"WAVE":
            return 0.0
        taxa_bytes = struct.unpack("<I", bruto[28:32])[0]
        dados = len(b64) * 3 // 4 - 44
        return dados / taxa_bytes if taxa_bytes else 0.0
    except Exception:
        return 0.0


def clonar_voz(fonte_b64, consentimento_b64, nome="Minha voz"):
    """Cria uma voz replicada no Gemini (POST /v1beta/voices). A documentação traz o idioma ora como
    replicated.lang_id, ora como voice.language_code: as variações são tentadas na ordem."""
    if not CFG.get("gemini_key"):
        raise ErroProvedor("voz", 401, "cole a chave do Gemini antes de clonar a voz")

    def montar(modelo, variante):
        rep = {"source_audio": {"mime_type": "audio/wav", "data": fonte_b64},
               "consent_audio": {"mime_type": "audio/wav", "data": consentimento_b64}}
        voz = {"type": "replicated", "model": modelo, "display_name": nome[:60]}
        if variante in ("ambos", "lang"):
            rep["lang_id"] = "pt-BR"
        if variante in ("ambos", "code"):
            voz["language_code"] = "pt-BR"
        if variante == "consentimento":
            rep["consent_audio"]["lang_id"] = "pt-BR"
        voz["replicated"] = rep
        return {"store": True, "voice": voz}

    ultimo = None
    for modelo in ("gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts"):
        for variante in ("ambos", "code", "lang", "consentimento"):
            try:
                with _gemini_abrir(URL_GEMINI + "/v1beta/voices", montar(modelo, variante), 180) as r:
                    d = json.loads(r.read().decode("utf-8"))
            except ErroHTTP as e:
                ultimo = e
                # só repete quando o erro é de nome de campo; consentimento recusado etc. volta direto
                if e.status == 400 and re.search(r"lang_id|language_code|unknown name|cannot find field|invalid json",
                                                 e.corpo, re.I):
                    continue
                if e.status == 404:
                    break
                raise ErroProvedor("voz", e.status, detalhe_erro(e.corpo))
            vid = d.get("id") or d.get("key") or (d.get("name") or "").replace("voices/", "")
            if not vid:
                raise ErroProvedor("voz", 0, "o Google não devolveu o identificador da voz")
            CFG.update(voz_clonada=vid, voz_clonada_modelo=modelo, voz_premium="clonada")
            salvar_config()
            log("voz clonada criada: %s (%s, variante %s)" % (vid, modelo, variante))
            return vid
    if ultimo is not None:
        raise ErroProvedor("voz", ultimo.status, detalhe_erro(ultimo.corpo))
    raise ErroProvedor("voz", 0, "não consegui criar a voz")


def apagar_voz_clonada():
    vid = CFG.get("voz_clonada") or ""
    if vid.startswith("voice_") and CFG.get("gemini_key"):
        try:
            _gemini_abrir(URL_GEMINI + "/v1beta/voices/" + urllib.parse.quote(vid), None, 30, metodo="DELETE").close()
        except ErroHTTP as e:
            if e.status != 404:
                raise ErroProvedor("voz", e.status, detalhe_erro(e.corpo))
    CFG.update(voz_clonada="", voz_clonada_modelo="")
    if CFG.get("voz_premium") == "clonada":
        CFG["voz_premium"] = "Charon"
    salvar_config()
    log("voz clonada apagada")


# ================================================================== utilidades: música, clima, abrir

def buscar_musica(q):
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(q)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "pt-BR,pt;q=0.9"})
    with _abrir(req, 10) as r:
        html = r.read(2_500_000).decode("utf-8", "replace")
    vistos, out = set(), []
    for m in re.finditer(r'"videoRenderer":\{"videoId":"([\w-]{11})"', html):
        vid = m.group(1)
        if vid in vistos:
            continue
        vistos.add(vid)
        trecho = html[m.end(): m.end() + 5000]
        t = re.search(r'"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"', trecho)
        titulo = q
        if t:
            try:
                titulo = json.loads('"' + t.group(1) + '"')
            except ValueError:
                titulo = t.group(1)
        out.append({"id": vid, "titulo": titulo})
        if len(out) >= 6:
            break
    return out


CLIMA = {0: "céu limpo", 1: "céu quase limpo", 2: "parcialmente nublado", 3: "nublado", 45: "neblina", 48: "neblina",
         51: "garoa fraca", 53: "garoa", 55: "garoa forte", 56: "garoa", 57: "garoa", 61: "chuva fraca", 63: "chuva",
         65: "chuva forte", 66: "chuva", 67: "chuva forte", 71: "neve", 73: "neve", 75: "neve", 77: "neve",
         80: "pancadas de chuva", 81: "pancadas de chuva", 82: "pancadas fortes de chuva", 85: "neve", 86: "neve",
         95: "trovoadas", 96: "trovoadas com granizo", 99: "trovoadas com granizo"}


CLIMA_ES = {0: "cielo despejado", 1: "cielo casi despejado", 2: "parcialmente nublado", 3: "nublado", 45: "niebla",
            48: "niebla", 51: "llovizna débil", 53: "llovizna", 55: "llovizna fuerte", 61: "lluvia débil", 63: "lluvia",
            65: "lluvia fuerte", 80: "chaparrones", 81: "chaparrones", 82: "chaparrones fuertes", 95: "tormenta",
            96: "tormenta con granizo", 99: "tormenta con granizo"}


def previsao(cidade, dia="hoje", idioma="pt"):
    es = idioma == "es"
    cidade = (cidade or CFG.get("cidade") or "Feira de Santana").strip()
    g = "https://geocoding-api.open-meteo.com/v1/search?count=1&format=json&language=%s&name=%s" % (
        "es" if es else "pt", urllib.parse.quote(cidade))
    with _abrir(urllib.request.Request(g, headers={"User-Agent": UA}), 8) as r:
        geo = json.loads(r.read().decode("utf-8"))
    if not geo.get("results"):
        return {"fala": ("No encontré la ciudad %s." if es else "Não encontrei a cidade %s.") % cidade}
    lugar = geo["results"][0]
    f = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&timezone=auto&forecast_days=3"
         "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,apparent_temperature"
         "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code"
         % (lugar["latitude"], lugar["longitude"]))
    with _abrir(urllib.request.Request(f, headers={"User-Agent": UA}), 8) as r:
        d = json.loads(r.read().decode("utf-8"))
    nome = lugar.get("name", cidade)
    dd = d.get("daily", {})
    i = 1 if dia == "amanha" else 0
    mx, mn = round(dd["temperature_2m_max"][i]), round(dd["temperature_2m_min"][i])
    chuva = dd.get("precipitation_probability_max", [None, None])[i]
    tab = CLIMA_ES if es else CLIMA
    desc = tab.get(dd["weather_code"][i], "tiempo variable" if es else "tempo variável")
    c = d.get("current", {})
    atual = round(c.get("temperature_2m", mx))
    if i == 0:
        agora_desc = tab.get(c.get("weather_code"), desc)
        fala = (("Ahora en %s hace %d grados, %s. Hoy la máxima es de %d y la mínima de %d grados" if es else
                 "Agora em %s faz %d graus, %s. Hoje a máxima é de %d e a mínima de %d graus")
                % (nome, atual, agora_desc, mx, mn))
    else:
        fala = (("Mañana en %s: %s, máxima de %d y mínima de %d grados" if es else
                 "Amanhã em %s: %s, máxima de %d e mínima de %d graus") % (nome, desc, mx, mn))
    if chuva is None:
        fala += "."
    elif chuva < 10:
        fala += ", sin pronóstico de lluvia." if es else ", sem previsão de chuva."
    else:
        fala += (", con %d por ciento de probabilidad de lluvia." if es else
                 ", com %d por cento de chance de chuva.") % chuva
    return {"fala": fala, "cidade": nome, "regiao": lugar.get("admin1", ""), "pais": lugar.get("country", ""),
            "max": mx, "min": mn, "chuva": chuva, "atual": atual, "desc": tab.get(c.get("weather_code"), desc),
            "codigo": c.get("weather_code"), "umidade": c.get("relative_humidity_2m"),
            "vento": c.get("wind_speed_10m"), "sensacao": c.get("apparent_temperature"),
            "lat": lugar["latitude"], "lon": lugar["longitude"]}


def abrir_no_sistema(alvo, url=None):
    if alvo == "projetos":
        PROJ.mkdir(exist_ok=True)
        os.startfile(str(PROJ))  # noqa
        return True
    if alvo == "url" and url and re.match(r"^https?://", url):
        webbrowser.open(url)
        return True
    return False


def projetos_recentes(limite=30):
    if not PROJ.exists():
        return []
    arqs = [p for p in PROJ.rglob("*") if p.is_file()]
    arqs.sort(key=lambda p: -p.stat().st_mtime)
    return [{"relativo": str(p.relative_to(PROJ)), "bytes": p.stat().st_size,
             "data": time.strftime("%d/%m %H:%M", time.localtime(p.stat().st_mtime))} for p in arqs[:limite]]


# ================================================================== consultas web com cache

CACHE_WEB = {}


def _get_json(url, timeout=8, cab=None):
    h = {"User-Agent": UA, "Accept": "application/json"}
    h.update(cab or {})
    with _abrir(urllib.request.Request(url, headers=h), timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def em_cache(chave, segundos, func):
    """Guarda o resultado de consultas lentas (cotação, geocodificação, busca de música) por algum tempo."""
    agora = time.time()
    c = CACHE_WEB.get(chave)
    if c and c[0] > agora:
        return c[1]
    v = func()
    if v:
        CACHE_WEB[chave] = (agora + segundos, v)
        if len(CACHE_WEB) > 400:
            for k in sorted(CACHE_WEB, key=lambda k: CACHE_WEB[k][0])[:150]:
                CACHE_WEB.pop(k, None)
    return v


def _num(x):
    try:
        return float(str(x).replace(",", "."))
    except (TypeError, ValueError):
        return None


# ================================================================== painel financeiro

MOEDAS = [("USD", "Dólar"), ("EUR", "Euro"), ("UYU", "Peso uruguaio"), ("ARS", "Peso argentino"), ("BTC", "Bitcoin")]
SERIES_BCB = {"selic": 432, "ipca12": 13522, "cdi": 4389}   # Selic meta, IPCA acumulado em 12 meses, CDI anualizado


def financas():
    def montar():
        out = {"moedas": [], "indices": {}, "serie_dolar": [], "atualizado": time.strftime("%d/%m/%Y %H:%M"),
               "falhas": []}
        try:
            d = _get_json("https://economia.awesomeapi.com.br/json/last/" + ",".join("%s-BRL" % c for c, _ in MOEDAS))
            for c, nome in MOEDAS:
                q = d.get(c + "BRL")
                if q and _num(q.get("bid")):
                    out["moedas"].append({"codigo": c, "nome": nome, "valor": _num(q["bid"]),
                                          "variacao": _num(q.get("pctChange"))})
        except Exception as e:
            out["falhas"].append("cotações: %s" % e)
        try:
            serie = _get_json("https://economia.awesomeapi.com.br/json/daily/USD-BRL/30")
            out["serie_dolar"] = [{"d": time.strftime("%d/%m", time.localtime(int(_num(p.get("timestamp")) or 0))),
                                   "v": round(_num(p["bid"]), 4)} for p in reversed(serie) if _num(p.get("bid"))]
        except Exception as e:
            out["falhas"].append("série do dólar: %s" % e)
        for nome, cod in SERIES_BCB.items():
            try:
                v = _get_json("https://api.bcb.gov.br/dados/serie/bcdata.sgs.%d/dados/ultimos/1?formato=json" % cod)
                if v and _num(v[-1].get("valor")) is not None:
                    out["indices"][nome] = {"valor": _num(v[-1]["valor"]), "data": v[-1].get("data", "")}
            except Exception as e:
                out["falhas"].append("Banco Central %s: %s" % (nome, e))
        try:
            y = _get_json("https://query1.finance.yahoo.com/v8/finance/chart/%5EBVSP?range=1d&interval=15m")
            meta = y["chart"]["result"][0]["meta"]
            preco = _num(meta.get("regularMarketPrice"))
            ant = _num(meta.get("chartPreviousClose") or meta.get("previousClose"))
            if preco:
                out["indices"]["ibovespa"] = {"valor": preco, "variacao": (preco / ant - 1) * 100 if ant else None}
        except Exception as e:
            out["falhas"].append("Ibovespa: %s" % e)
        if out["falhas"]:
            log("painel financeiro: " + "; ".join(out["falhas"]))
        return out if (out["moedas"] or out["indices"]) else None
    return em_cache("financas", 300, montar) or {"moedas": [], "indices": {}, "serie_dolar": [],
                                                   "falhas": ["sem conexão com as fontes de cotação"]}


# ================================================================== geografia (globo 3D)

UA_OSM = "ICARO/5 (assistente local de um professor da UEFS; uso pessoal)"


def geo_buscar(q, idioma="pt"):
    q = re.sub(r"\s+", " ", (q or "")).strip(" .,;:!?")[:80]
    if not q:
        return []
    lingua = "es" if idioma == "es" else "pt"

    def montar():
        res = []
        try:
            d = _get_json("https://geocoding-api.open-meteo.com/v1/search?count=5&format=json&language=%s&name=%s"
                          % (lingua, urllib.parse.quote(q)))
            for r in d.get("results") or []:
                res.append({"nome": r.get("name"), "regiao": r.get("admin1") or "", "pais": r.get("country") or "",
                            "lat": r["latitude"], "lon": r["longitude"], "populacao": r.get("population") or 0,
                            "tipo": "cidade"})
        except Exception as e:
            log("geocodificação (open-meteo) falhou: %s" % e)
        if not res:
            try:
                d = _get_json("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=3&accept-language=%s&q=%s"
                              % (lingua, urllib.parse.quote(q)), cab={"User-Agent": UA_OSM})
                for r in d:
                    partes = (r.get("display_name") or "").split(", ")
                    res.append({"nome": r.get("name") or partes[0], "regiao": ", ".join(partes[1:3]),
                                "pais": partes[-1] if partes else "", "lat": float(r["lat"]), "lon": float(r["lon"]),
                                "populacao": 0, "tipo": r.get("type") or "lugar"})
            except Exception as e:
                log("geocodificação (nominatim) falhou: %s" % e)
        return res
    return em_cache("geo:%s:%s" % (lingua, norm(q)), 86400, montar) or []


def geo_reverso(lat, lon, idioma="pt"):
    def montar():
        d = _get_json("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=%s"
                      "&lat=%.5f&lon=%.5f" % ("es" if idioma == "es" else "pt", lat, lon), cab={"User-Agent": UA_OSM})
        a = d.get("address") or {}
        nome = a.get("city") or a.get("town") or a.get("municipality") or a.get("village") or a.get("county") \
            or d.get("name") or ""
        return {"nome": nome, "regiao": a.get("state", ""), "pais": a.get("country", ""), "lat": lat, "lon": lon}
    try:
        return em_cache("rev:%.2f:%.2f:%s" % (lat, lon, idioma), 86400, montar)
    except Exception as e:
        log("geocodificação reversa falhou: %s" % e)
        return None


def geo_onde(idioma="pt"):
    """Onde o Ícaro está: lugar fixado nas configurações, senão pela internet (IP), senão a cidade padrão."""
    if CFG.get("local_fixo"):
        r = geo_buscar(CFG["local_fixo"], idioma)
        if r:
            return dict(r[0], fonte="configuração")
    try:
        d = _get_json("http://ip-api.com/json/?fields=status,country,regionName,city,lat,lon&lang=%s"
                      % ("es" if idioma == "es" else "pt-BR"), timeout=6)
        if d.get("status") == "success" and d.get("city"):
            return {"nome": d["city"], "regiao": d.get("regionName", ""), "pais": d.get("country", ""),
                    "lat": d["lat"], "lon": d["lon"], "fonte": "internet"}
    except Exception as e:
        log("localização por IP falhou: %s" % e)
    r = geo_buscar(CFG.get("cidade") or "Feira de Santana", idioma)
    return dict(r[0], fonte="cidade padrão") if r else None


# ================================================================== Spotify

RX_SPOTIFY = re.compile(r"open\.spotify\.com(?:/|%2F)(?:intl-[a-z]{2}(?:/|%2F))?(track|album|playlist|artist)"
                        r"(?:/|%2F)([A-Za-z0-9]{22})")
SP = {"verificador": "", "estado": "", "token": "", "expira": 0.0}
SP_ESCOPOS = "user-read-playback-state user-modify-playback-state user-read-currently-playing"


def _titulo_spotify(t):
    t = htmllib.unescape(re.sub(r"<[^>]+>", "", t or "")).strip()
    t = re.sub(r"\s*\|\s*Spotify\s*$", "", t)
    m = re.match(r"^(.*?)\s*-\s*(?:song|música|canción|single|album|álbum)(?: and lyrics)? (?:by|de|por)\s+(.*)$", t, re.I)
    if m:
        return "%s · %s" % (m.group(1).strip(), m.group(2).strip())
    return re.sub(r"\s*-\s*(?:playlist|artist|artista)\b.*$", "", t, flags=re.I).strip()


ARQ_SP_CACHE = MEM / "spotify_cache.json"
MOTORES_BUSCA = [("duckduckgo", URL_BUSCA_WEB), ("duckduckgo-lite", "https://lite.duckduckgo.com/lite/"),
                 ("brave", "https://search.brave.com/search")]
PAUSA_MOTOR = {}


def _extrair_spotify(pagina, q):
    """Links do Spotify na ordem em que o buscador mostrou, com o título do resultado quando houver."""
    vistos, out = set(), []
    for m in re.finditer(r'<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]{0,1600}?)</a>', pagina):
        s = RX_SPOTIFY.search(urllib.parse.unquote(htmllib.unescape(m.group(1))))
        if not s or s.group(2) in vistos:
            continue
        vistos.add(s.group(2))
        inner = m.group(2)
        t = re.search(r'class="[^"]*title[^"]*"[^>]*>([\s\S]*?)</', inner)
        out.append({"uri": "spotify:%s:%s" % (s.group(1), s.group(2)), "tipo": s.group(1),
                    "titulo": _titulo_spotify(t.group(1) if t else inner)[:110] or q})
        if len(out) >= 6:
            break
    if not out:
        for s in RX_SPOTIFY.finditer(pagina):
            if s.group(2) not in vistos:
                vistos.add(s.group(2))
                out.append({"uri": "spotify:%s:%s" % (s.group(1), s.group(2)), "tipo": s.group(1), "titulo": q})
            if len(out) >= 6:
                break
    return out


def spotify_favorita(q):
    """Músicas fixadas nas configurações (nome = link): respondem na hora e sem depender de busca na internet."""
    nq = norm(q)
    for f in CFG.get("spotify_favoritas") or []:
        nf = norm(f.get("nome", ""))
        if nf and (nq == nf or nf in nq or (len(nq) > 3 and nq in nf)):
            return {"uri": f["uri"], "tipo": f["uri"].split(":")[1], "titulo": f.get("nome") or q}
    return None


def spotify_buscar_web(q):
    """Sem conta de desenvolvedor: favoritas, depois o cache permanente, depois a busca na web (vários buscadores;
    quem bloquear fica de fora por 15 minutos). O que tocou uma vez fica guardado e toca sempre, até sem busca."""
    q = (q or "").strip()[:120]
    if not q:
        return []
    direto = RX_SPOTIFY.search(q) or re.search(r"spotify:(track|album|playlist|artist):([A-Za-z0-9]{22})", q)
    if direto:
        return [{"uri": "spotify:%s:%s" % (direto.group(1), direto.group(2)), "tipo": direto.group(1), "titulo": "Spotify"}]
    fav = spotify_favorita(q)
    if fav:
        return [fav]
    chave = norm(q)
    with TRAVA:
        cache = json_ler(ARQ_SP_CACHE, {})
    if cache.get(chave):
        return cache[chave]
    for nome, base in MOTORES_BUSCA:
        if PAUSA_MOTOR.get(nome, 0) > time.time():
            continue
        for filtro in ("site:open.spotify.com/track ", "site:open.spotify.com "):
            url = base + ("&" if "?" in base else "?") + "q=" + urllib.parse.quote_plus(filtro + q)
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html,application/xhtml+xml",
                                                      "Accept-Language": "pt-BR,pt;q=0.9,es;q=0.8"})
            try:
                with _abrir(req, 12) as r:
                    pagina = r.read(1_500_000).decode("utf-8", "replace")
            except ErroHTTP as e:
                log("busca do Spotify (%s) falhou: %s" % (nome, e.status))
                if e.status in (0, 202, 403, 429, 503):
                    PAUSA_MOTOR[nome] = time.time() + 900
                break
            res = _extrair_spotify(pagina, q)
            if res:
                with TRAVA:
                    cache = json_ler(ARQ_SP_CACHE, {})
                    cache[chave] = res
                    if len(cache) > 600:
                        for k in list(cache)[:100]:
                            cache.pop(k, None)
                    json_salvar(ARQ_SP_CACHE, cache)
                log("Spotify (%s): %s -> %s" % (nome, q, res[0]["titulo"]))
                return res
            if re.search(r"anomaly|captcha|unusual traffic|verify you are|are you a robot", pagina, re.I):
                PAUSA_MOTOR[nome] = time.time() + 900
                log("busca do Spotify (%s) pediu verificação; pausado por 15 minutos" % nome)
                break
    return []


def spotify_redirect():
    return "http://127.0.0.1:%d/spotify/retorno" % PORTA


def spotify_url_conectar():
    verificador = secrets.token_urlsafe(72)[:96]
    desafio = base64.urlsafe_b64encode(hashlib.sha256(verificador.encode("ascii")).digest()).decode("ascii").rstrip("=")
    SP.update(verificador=verificador, estado=secrets.token_urlsafe(18))
    q = {"client_id": CFG.get("spotify_client_id", ""), "response_type": "code", "redirect_uri": spotify_redirect(),
         "code_challenge_method": "S256", "code_challenge": desafio, "scope": SP_ESCOPOS, "state": SP["estado"]}
    return URL_SPOTIFY_CONTAS + "/authorize?" + urllib.parse.urlencode(q)


def _spotify_token_req(campos):
    req = urllib.request.Request(URL_SPOTIFY_CONTAS + "/api/token", data=urllib.parse.urlencode(campos).encode("ascii"),
                                 method="POST", headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with _abrir(req, 15) as r:
            return json.loads(r.read().decode("utf-8"))
    except ErroHTTP as e:
        raise ErroProvedor("spotify", e.status, detalhe_erro(e.corpo))


def _spotify_guardar(d):
    SP.update(token=d.get("access_token", ""), expira=time.time() + int(d.get("expires_in", 3600)))
    if d.get("refresh_token"):
        CFG["spotify_refresh"] = d["refresh_token"]
        salvar_config()


def spotify_trocar_codigo(codigo, estado):
    if not SP["verificador"] or not hmac.compare_digest(estado or "", SP["estado"]):
        raise ErroProvedor("spotify", 400, "o retorno do Spotify não confere com o pedido (abra CONECTAR de novo)")
    d = _spotify_token_req({"grant_type": "authorization_code", "code": codigo, "redirect_uri": spotify_redirect(),
                            "client_id": CFG.get("spotify_client_id", ""), "code_verifier": SP["verificador"]})
    SP.update(verificador="", estado="")
    _spotify_guardar(d)


def spotify_conectado():
    return bool(CFG.get("spotify_refresh") and CFG.get("spotify_client_id"))


def spotify_token():
    if SP["token"] and SP["expira"] > time.time() + 30:
        return SP["token"]
    if not spotify_conectado():
        return ""
    _spotify_guardar(_spotify_token_req({"grant_type": "refresh_token", "refresh_token": CFG["spotify_refresh"],
                                         "client_id": CFG["spotify_client_id"]}))
    return SP["token"]


def spotify_api(metodo, caminho, corpo=None, consulta=None):
    tok = spotify_token()
    if not tok:
        raise ErroProvedor("spotify", 401, "Spotify não conectado")
    url = URL_SPOTIFY_API + "/v1" + caminho + ("?" + urllib.parse.urlencode(consulta) if consulta else "")
    dados = json.dumps(corpo).encode("utf-8") if corpo is not None else (b"" if metodo in ("PUT", "POST") else None)
    req = urllib.request.Request(url, data=dados, method=metodo,
                                 headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"})
    try:
        with _abrir(req, 12) as r:
            b = r.read()
            return json.loads(b.decode("utf-8")) if b.strip() else {}
    except ErroHTTP as e:
        if e.status == 401:
            SP["token"] = ""
        raise ErroProvedor("spotify", e.status, detalhe_erro(e.corpo))


def spotify_tocar(q):
    """Spotify Connect (conta Premium): toca no aplicativo do Spotify deste computador; o Ícaro continua na tela."""
    direto = RX_SPOTIFY.search(q) or re.search(r"spotify:(track|album|playlist|artist):([A-Za-z0-9]{22})", q)
    fav = ({"uri": "spotify:%s:%s" % (direto.group(1), direto.group(2)), "tipo": direto.group(1), "titulo": "Spotify"}
           if direto else spotify_favorita(q))
    if fav and fav["tipo"] != "track":
        alvo = _spotify_aparelho()
        spotify_api("PUT", "/me/player/play", corpo={"context_uri": fav["uri"]}, consulta={"device_id": alvo["id"]})
        return {"modo": "connect", "uri": fav["uri"], "titulo": fav["titulo"], "artista": "", "capa": "", "aparelho": alvo.get("name")}
    if fav:
        faixas = [spotify_api("GET", "/tracks/" + fav["uri"].split(":")[2])]
    else:
        r = spotify_api("GET", "/search", consulta={"q": q, "type": "track", "limit": 5, "market": "from_token"})
        faixas = (r.get("tracks") or {}).get("items") or []
    if not faixas:
        return None
    alvo = _spotify_aparelho()
    spotify_api("PUT", "/me/player/play", corpo={"uris": [f["uri"] for f in faixas]}, consulta={"device_id": alvo["id"]})
    f = faixas[0]
    imgs = (f.get("album") or {}).get("images") or []
    return {"modo": "connect", "uri": f["uri"], "titulo": f.get("name", q),
            "artista": ", ".join(a.get("name", "") for a in f.get("artists") or []),
            "capa": imgs[-2]["url"] if len(imgs) >= 2 else (imgs[0]["url"] if imgs else ""), "aparelho": alvo.get("name")}


def _spotify_aparelho():
    devs = spotify_api("GET", "/me/player/devices").get("devices") or []
    alvo = (next((d for d in devs if d.get("is_active")), None)
            or next((d for d in devs if d.get("type") == "Computer"), None) or (devs[0] if devs else None))
    if not alvo:
        raise ErroProvedor("spotify", 404, "nenhum aparelho com o Spotify aberto; abra o aplicativo do Spotify")
    return alvo


def spotify_controle(acao, valor=None):
    if acao == "pausar":
        spotify_api("PUT", "/me/player/pause")
    elif acao == "continuar":
        spotify_api("PUT", "/me/player/play")
    elif acao == "proxima":
        spotify_api("POST", "/me/player/next")
    elif acao == "volume":
        spotify_api("PUT", "/me/player/volume", consulta={"volume_percent": max(0, min(100, int(valor or 50)))})
    else:
        raise ErroProvedor("spotify", 400, "ação desconhecida")


# ================================================================== sistemas do professor (Discipulus e LabEduContábil)

SISTEMAS = ("discipulus", "labedu")
PORTA_SIS = int(os.environ.get("ICARO_PORTA_SISTEMAS") or CFG.get("porta_sistemas", 8766))


def arquivo_sistema(nome):
    """O arquivo original (sempre a versão mais nova do professor); se sumir, a cópia guardada em sistemas/."""
    cands = [(CFG.get("sistemas") or {}).get(nome) or "", str(RAIZ / "sistemas" / ("%s.html" % nome))]
    for c in cands:
        try:
            p = Path(c)
            if c and p.is_file():
                return p
        except OSError:
            pass
    return None


class HandlerSistemas(http.server.BaseHTTPRequestHandler):
    """Origem separada (outra porta): os sistemas não enxergam a página nem o token do Ícaro."""
    server_version = "ICARO-SISTEMAS"
    sys_version = ""

    def log_message(self, *a):
        pass

    def _enviar(self, corpo, ctype, code=200, csp=""):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Security-Policy", (csp + "; " if csp else "") +
                         "frame-ancestors http://127.0.0.1:%d http://localhost:%d" % (PORTA, PORTA))
        self.end_headers()
        self.wfile.write(corpo)

    def do_GET(self):
        if (self.headers.get("Host") or "").lower() not in {"127.0.0.1:%d" % PORTA_SIS, "localhost:%d" % PORTA_SIS}:
            return self._enviar(b"host", "text/plain", 403)
        rota = urllib.parse.urlsplit(self.path).path.rstrip("/")
        if rota == "/spotify":
            # o script oficial do Spotify usa eval: fica aqui, isolado, e não na página do Ícaro
            try:
                return self._enviar((UI / "spotify.html").read_bytes(), "text/html; charset=utf-8", csp=(
                    "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' https://open.spotify.com "
                    "https://embed-cdn.spotifycdn.com; style-src 'unsafe-inline'; frame-src https://open.spotify.com; "
                    "connect-src https://open.spotify.com https://embed-cdn.spotifycdn.com; img-src data: https:"))
            except OSError:
                return self._enviar(b"", "text/plain", 404)
        if rota == "/__icaro_tour.js":
            try:
                return self._enviar((UI / "tour.js").read_bytes(), "text/javascript; charset=utf-8")
            except OSError:
                return self._enviar(b"", "text/javascript", 404)
        nome = rota.strip("/")
        if nome not in SISTEMAS:
            return self._enviar(b"nao encontrado", "text/plain", 404)
        arq = arquivo_sistema(nome)
        if not arq:
            msg = ("<meta charset='utf-8'><body style='font-family:sans-serif;background:#071022;color:#cfe;padding:40px'>"
                   "<h2>Arquivo do sistema não encontrado</h2><p>Confira o caminho em config.json, chave sistemas.%s, "
                   "ou copie o HTML para a pasta sistemas do Ícaro com o nome %s.html.</p>" % (nome, nome))
            return self._enviar(msg.encode("utf-8"), "text/html; charset=utf-8", 404)
        dados = arq.read_bytes()
        etiqueta = b'<script src="/__icaro_tour.js"></script>'
        i = dados.lower().rfind(b"</body>")
        dados = dados[:i] + etiqueta + dados[i:] if i >= 0 else dados + etiqueta
        return self._enviar(dados, "text/html")


def iniciar_servidor_sistemas():
    try:
        srv = Servidor(("127.0.0.1", PORTA_SIS), HandlerSistemas)
    except OSError as e:
        log("servidor dos sistemas não subiu na porta %d: %s" % (PORTA_SIS, e))
        return False
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return True


# ================================================================== laços autônomos

def rodar_autonomo(instrucao, origem):
    try:
        if precisa_operar(instrucao) and tem_chave("anthropic") and CFG.get("poderes") != "leitura":
            r = rodar_agente("auto", texto=instrucao)
            if r.get("tipo") == "confirmar":
                PENDENTES.pop(r.get("token"), None)
                evento("Uma ação automática precisa da sua autorização e eu não vou executar sozinho. "
                       "Me chame quando puder.", origem)
                return
            fala = (r.get("fala") or "").strip()
        else:
            fala = responder_texto(instrucao)
        if fala:
            evento(fala, origem)
    except Exception as e:
        log("autônomo falhou: %s" % e)


def laco_rotinas():
    while True:
        try:
            agora = time.localtime()
            hhmm, hoje, dia = time.strftime("%H:%M", agora), time.strftime("%Y-%m-%d", agora), agora.tm_wday
            rotinas = json_ler(ARQ_ROTINAS, [])
            mudou = False
            for r in rotinas:
                if r.get("ultima") == hoje or r["hora"] != hhmm or dia not in r.get("dias", []):
                    continue
                r["ultima"] = hoje
                mudou = True
                threading.Thread(target=rodar_autonomo, args=(r["instrucao"], "rotina"), daemon=True).start()
            if mudou:
                json_salvar(ARQ_ROTINAS, rotinas)
        except Exception as e:
            log("laço de rotinas: %s" % e)
        time.sleep(20)


def laco_agenda():
    while True:
        try:
            agora = datetime.now()
            with TRAVA:
                a = agenda_ler()
                mudou = False
                for e in a:
                    dt = ler_data(e["inicio"])
                    if not dt:
                        continue
                    falta = (dt - agora).total_seconds() / 60.0
                    if 0 < falta <= 10.5 and not e.get("aviso10"):
                        e["aviso10"] = mudou = True
                        EVENTOS.append({"id": int(time.time() * 1000), "origem": "agenda", "hora": agora.strftime("%H:%M"),
                                        "texto": "%s, em %d minutos: %s." % (CFG["tratamento"], max(1, round(falta)),
                                                                             e["titulo"])})
                    elif -3 <= falta <= 0 and not e.get("aviso0"):
                        e["aviso0"] = e["aviso10"] = mudou = True
                        EVENTOS.append({"id": int(time.time() * 1000), "origem": "agenda", "hora": agora.strftime("%H:%M"),
                                        "texto": "%s, está na hora: %s." % (CFG["tratamento"], e["titulo"])})
                if mudou:
                    json_salvar(ARQ_AGENDA, a)
        except Exception as e:
            log("laço de agenda: %s" % e)
        time.sleep(20)


def laco_vigilancia():
    time.sleep(12)
    ultimo_aviso = 0.0
    while True:
        try:
            if CFG.get("vigilancia_ativa", True):
                vigias = json_ler(ARQ_VIGIAS, [])
                mudou = False
                for v in vigias:
                    p = Path(v["pasta"])
                    if not p.exists():
                        continue
                    atuais = sorted([f.name for f in p.iterdir() if f.is_file()])
                    novos = [n for n in atuais if n not in v.get("conhecidos", [])]
                    if novos:
                        v["conhecidos"] = atuais
                        mudou = True
                        if time.time() - ultimo_aviso > 90:
                            ultimo_aviso = time.time()
                            lista = ", ".join(novos[:5])
                            if CFG.get("sugerir_em_arquivo_novo", True) and provedores_ativos():
                                threading.Thread(target=rodar_autonomo, args=(
                                    "Apareceu arquivo novo na pasta %s: %s. Em no máximo duas frases faladas, diga o "
                                    "que provavelmente é e sugira o que fazer. Não execute nada." % (p, lista),
                                    "vigilância"), daemon=True).start()
                            else:
                                evento("Chegou arquivo novo em %s: %s." % (p.name, lista), "vigilância")
                if mudou:
                    json_salvar(ARQ_VIGIAS, vigias)
        except Exception as e:
            log("laço de vigilância: %s" % e)
        time.sleep(max(15, int(CFG.get("intervalo_vigilancia", 45))))


def laco_limpeza():
    while True:
        time.sleep(300)
        limite = time.time() - 900
        for k in [k for k, v in PENDENTES.items() if v.get("criado", 0) < limite]:
            PENDENTES.pop(k, None)


# ================================================================== servidor HTTP

TIPOS = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".json": "application/json; charset=utf-8", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
         ".webp": "image/webp", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".webm": "video/webm",
         ".mp4": "video/mp4", ".woff2": "font/woff2", ".mp3": "audio/mpeg", ".wav": "audio/wav"}
MAPA_HOSTS = "https://server.arcgisonline.com https://services.arcgisonline.com"
CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline'; "
       "style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: blob: https://i.ytimg.com https://i.scdn.co https://*.spotifycdn.com " + MAPA_HOSTS + "; "
       "media-src 'self' blob: data:; connect-src 'self' " + MAPA_HOSTS + "; worker-src 'self' blob:; child-src blob:; "
       "frame-src https://www.youtube-nocookie.com https://www.youtube.com https://open.spotify.com "
       "http://127.0.0.1:%d; object-src 'none'; base-uri 'none'" % PORTA_SIS)


def hosts_ok():
    return {"127.0.0.1:%d" % PORTA, "localhost:%d" % PORTA}


def origens_ok():
    return {"http://127.0.0.1:%d" % PORTA, "http://localhost:%d" % PORTA}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "ICARO/" + VERSAO
    sys_version = ""

    def log_message(self, *a):
        pass

    # ---------------- utilidades
    def _host_ok(self):
        return (self.headers.get("Host") or "").lower() in hosts_ok()

    def _api_ok(self):
        origem = self.headers.get("Origin")
        if origem and origem.lower() not in origens_ok():
            return False
        return hmac.compare_digest(self.headers.get("X-Icaro-Token", ""), TOKEN)

    def _enviar(self, corpo, ctype, code=200, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(corpo)

    def _json(self, obj, code=200):
        self._enviar(json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", code)

    def _corpo(self, limite=6_000_000):
        tam = int(self.headers.get("Content-Length") or 0)
        if tam > limite:
            raise ValueError("pedido grande demais")
        dados = self.rfile.read(tam) if tam else b"{}"
        return json.loads(dados.decode("utf-8") or "{}")

    # ---------------- GET
    def do_GET(self):
        if not self._host_ok():
            return self._json({"erro": "host não permitido"}, 403)
        u = urllib.parse.urlsplit(self.path)
        rota, qs = u.path, urllib.parse.parse_qs(u.query)
        if rota in ("/", "/index.html"):
            try:
                html = (UI / "index.html").read_text(encoding="utf-8").replace("__ICARO_TOKEN__", TOKEN)
            except Exception:
                return self._json({"erro": "ui/index.html ausente"}, 500)
            return self._enviar(html.encode("utf-8"), TIPOS[".html"], extra={
                "Content-Security-Policy": CSP, "Referrer-Policy": "no-referrer"})
        if rota.startswith("/api/"):
            if not self._api_ok():
                return self._json({"erro": "acesso negado"}, 403)
            try:
                return self._get_api(rota, qs)
            except Exception as e:
                log("GET %s falhou: %s" % (rota, e))
                return self._json({"erro": str(e)[:300]}, 500)
        if rota == "/spotify/conectar":
            if not CFG.get("spotify_client_id"):
                return self._pagina("Falta o Client ID", "Cole o Client ID do seu app do Spotify nas configurações do "
                                    "Ícaro e clique em CONECTAR de novo.")
            self.send_response(302)
            self.send_header("Location", spotify_url_conectar())
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if rota == "/spotify/retorno":
            if (qs.get("error") or [""])[0]:
                return self._pagina("Spotify não conectado", "O Spotify respondeu: %s." % qs["error"][0][:80])
            try:
                spotify_trocar_codigo((qs.get("code") or [""])[0], (qs.get("state") or [""])[0])
            except ErroProvedor as e:
                log("conexão com o Spotify falhou: %s %s" % (e.status, e.detalhe))
                return self._pagina("Spotify não conectado", e.detalhe)
            log("Spotify conectado")
            return self._pagina("Spotify conectado", "Pronto. Pode fechar esta aba: o Ícaro já toca as músicas no "
                                "aplicativo do Spotify deste computador.")
        return self._estatico(rota)

    def _pagina(self, titulo, texto):
        corpo = ("<!doctype html><meta charset='utf-8'><title>%s</title><body style='font-family:Segoe UI,sans-serif;"
                 "background:#02050c;color:#dbeafe;display:grid;place-items:center;height:100vh;margin:0'><div "
                 "style='max-width:520px;text-align:center'><h2 style='color:#4fd1ff'>%s</h2><p>%s</p></div>"
                 % (htmllib.escape(titulo), htmllib.escape(titulo), htmllib.escape(texto)))
        return self._enviar(corpo.encode("utf-8"), TIPOS[".html"], extra={"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'"})

    def _estatico(self, rota):
        alvo = (UI / urllib.parse.unquote(rota).lstrip("/")).resolve()
        ext = alvo.suffix.lower()
        if UI.resolve() not in alvo.parents or ext not in TIPOS or not alvo.is_file():
            return self._json({"erro": "não encontrado"}, 404)
        return self._enviar(alvo.read_bytes(), TIPOS[ext])

    def _get_api(self, rota, qs):
        q = lambda k, d="": (qs.get(k) or [d])[0]
        if rota == "/api/estado":
            hoje = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            return self._json({
                "nome": CFG["nome"], "tratamento": CFG["tratamento"], "versao": VERSAO,
                "provedores": [{"nome": "anthropic", "chave": tem_chave("anthropic"), "modelo": CFG["modelo"]},
                               {"nome": "gemini", "chave": tem_chave("gemini"),
                                "modelo": GEMINI_BOM["modelo"] or fila_gemini()[0]}],
                "ordem": CFG.get("provedores"), "modo_escuta": CFG.get("modo_escuta", "palavra"),
                "janela_seguimento": CFG.get("janela_seguimento", 8), "poderes": CFG.get("poderes"),
                "cidade": CFG.get("cidade"), "senha": bool(CFG.get("senha_confirmacao")),
                "operador": tem_chave("anthropic") and CFG.get("poderes") != "leitura",
                "notas": len(brain_ler()["notas"]), "rotinas": json_ler(ARQ_ROTINAS, []),
                "vigias": [{"pasta": v["pasta"], "arquivos": len(v.get("conhecidos", []))} for v in json_ler(ARQ_VIGIAS, [])],
                "agenda": agenda_periodo(hoje, hoje + timedelta(days=2)), "base": INDICE.resumo(),
                "voz_motor": CFG.get("voz_motor", "auto"), "voz_premium": CFG.get("voz_premium", "Charon"),
                "vozes_premium": ([{"nome": "clonada", "estilo": "minha própria voz"}] if CFG.get("voz_clonada") else []) +
                                 [{"nome": v, "estilo": e} for v, e in VOZES_PREMIUM],
                "voz_clonada": bool(CFG.get("voz_clonada")), "consentimento": CONSENTIMENTO_PT,
                "voz_cache": len(list(CACHE_VOZ.glob("*.wav"))) if CACHE_VOZ.exists() else 0,
                "musica_fonte": CFG.get("musica_fonte", "spotify"), "cenario": CFG.get("cenario", "terra"),
                "local_fixo": CFG.get("local_fixo", ""),
                "spotify": {"conectado": spotify_conectado(), "client_id": bool(CFG.get("spotify_client_id")),
                            "redirect": spotify_redirect(), "favoritas": CFG.get("spotify_favoritas") or []},
                "sistemas": {"porta": PORTA_SIS, "disponiveis": [n for n in SISTEMAS if arquivo_sistema(n)]},
            })
        if rota == "/api/eventos":
            return self._json({"eventos": eventos_drenar()})
        if rota == "/api/notas":
            return self._json(brain_ler())
        if rota == "/api/agenda":
            dias = max(1, min(120, int(q("dias", "21") or 21)))
            hoje = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            return self._json({"eventos": agenda_periodo(hoje - timedelta(days=1), hoje + timedelta(days=dias))})
        if rota == "/api/agenda.ics":
            return self._enviar(ics_texto().encode("utf-8"), "text/calendar; charset=utf-8",
                                extra={"Content-Disposition": 'attachment; filename="agenda-icaro.ics"'})
        if rota == "/api/musica":
            termo = q("q").strip()
            if not termo:
                return self._json({"resultados": []})
            try:
                return self._json({"resultados": buscar_musica(termo)})
            except ErroHTTP as e:
                return self._json({"resultados": [], "erro": "busca indisponível (%s)" % e.status})
        if rota == "/api/tempo":
            try:
                return self._json(previsao(q("cidade"), q("dia", "hoje"), q("idioma", "pt")))
            except (ErroHTTP, KeyError, IndexError, ValueError):
                return self._json({"fala": "No pude consultar el clima ahora." if q("idioma") == "es" else
                                   "Não consegui consultar o clima agora. Estou sem internet?"})
        if rota == "/api/financas":
            return self._json(financas())
        if rota == "/api/geo/busca":
            return self._json({"resultados": geo_buscar(q("q"), q("idioma", "pt"))})
        if rota == "/api/geo/onde":
            return self._json({"lugar": geo_onde(q("idioma", "pt"))})
        if rota == "/api/geo/reverso":
            lat, lon = _num(q("lat")), _num(q("lon"))
            if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180):
                return self._json({"lugar": None}, 400)
            return self._json({"lugar": geo_reverso(lat, lon, q("idioma", "pt"))})
        if rota == "/api/spotify/busca":
            return self._json({"resultados": spotify_buscar_web(q("q"))})
        if rota == "/api/projetos":
            return self._json({"arquivos": projetos_recentes(), "pasta": str(PROJ)})
        if rota == "/api/rosto":
            return self._json(json_ler(UI / "rosto.json", {}))
        return self._json({"erro": "rota desconhecida"}, 404)

    # ---------------- POST
    def do_POST(self):
        if not self._host_ok():
            return self._json({"erro": "host não permitido"}, 403)
        if not self._api_ok():
            return self._json({"erro": "acesso negado"}, 403)
        if not (self.headers.get("Content-Type") or "").lower().startswith("application/json"):
            return self._json({"erro": "conteúdo deve ser JSON"}, 415)
        rota = urllib.parse.urlsplit(self.path).path
        try:
            dados = self._corpo()
        except Exception as e:
            return self._json({"erro": "pedido inválido: %s" % e}, 400)
        try:
            if rota == "/api/falar":
                return self._falar(dados)
            if rota == "/api/voz":
                return self._voz(dados)
            return self._post_api(rota, dados)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, Cancelado):
            return
        except Exception as e:
            log("POST %s falhou: %s" % (rota, e))
            try:
                return self._json({"erro": str(e)[:300]}, 500)
            except Exception:
                return

    def _falar(self, dados):
        texto = (dados.get("texto") or "").strip()
        sessao = str(dados.get("sessao") or "padrao")[:40]
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()

        def enviar(ev):
            try:
                self.wfile.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode("utf-8"))
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                raise Cancelado()

        if not texto:
            enviar({"t": "offline", "x": "Não entendi o pedido.", "erros": []})
            return
        try:
            responder(texto, sessao, enviar, palco=bool(dados.get("palco")), idioma=dados.get("idioma") or "pt")
        except Cancelado:
            log("resposta interrompida pelo usuário")

    def _voz(self, dados):
        voz = dados.get("voz") or None
        if voz and voz not in [v for v, _ in VOZES_PREMIUM] and not (voz == "clonada" and CFG.get("voz_clonada")):
            voz = None
        estilo = dados.get("estilo") if isinstance(dados.get("estilo"), str) else None
        try:
            audio, cache = tts_gemini(dados.get("texto", ""), voz, estilo)
        except ErroProvedor as e:
            log("voz premium falhou: %s %s" % (e.status, e.detalhe))
            return self._json({"erro": e.detalhe, "status": e.status}, 429 if e.status == 429 else 502)
        except Exception as e:
            log("voz premium exceção: %s" % e)
            return self._json({"erro": str(e)[:200], "status": 0}, 502)
        return self._enviar(audio, "audio/wav", extra={"X-Icaro-Cache": "1" if cache else "0"})

    def _post_api(self, rota, dados):
        if rota == "/api/spotify/tocar":
            q = (dados.get("q") or "").strip()[:120]
            if not q:
                return self._json({"ok": False, "erro": "pedido vazio"}, 400)
            aviso = ""
            if spotify_conectado():
                try:
                    r = spotify_tocar(q)
                    if r:
                        return self._json(dict(r, ok=True))
                except ErroProvedor as e:
                    log("Spotify Connect falhou (%s): %s; usando o player embutido" % (e.status, e.detalhe))
                    aviso = e.detalhe
            res = spotify_buscar_web(q)
            if res:
                return self._json({"ok": True, "modo": "embed", "resultados": res, "aviso": aviso})
            return self._json({"ok": False, "erro": "não achei no Spotify", "aviso": aviso})
        if rota == "/api/spotify/controle":
            try:
                spotify_controle(dados.get("acao"), dados.get("valor"))
            except ErroProvedor as e:
                return self._json({"ok": False, "erro": e.detalhe}, 502)
            return self._json({"ok": True})
        if rota == "/api/spotify/desconectar":
            CFG["spotify_refresh"] = ""
            SP.update(token="", expira=0.0)
            salvar_config()
            return self._json({"ok": True})
        if rota == "/api/voz/clonar":
            fonte, cons = dados.get("fonte") or "", dados.get("consentimento") or ""
            df, dc = duracao_wav_b64(fonte), duracao_wav_b64(cons)
            if not 9 <= df <= 31:
                return self._json({"ok": False, "erro": "a gravação de leitura precisa ter de 10 a 30 segundos (tem %.0f)" % df}, 400)
            if not 3 <= dc <= 20:
                return self._json({"ok": False, "erro": "a frase de autorização precisa ter de 3 a 20 segundos (tem %.0f)" % dc}, 400)
            try:
                clonar_voz(fonte, cons, dados.get("nome") or "Voz do %s" % CFG["tratamento"])
            except ErroProvedor as e:
                log("clonagem falhou: %s %s" % (e.status, e.detalhe))
                return self._json({"ok": False, "status": e.status, "erro": e.detalhe}, 502)
            return self._json({"ok": True})
        if rota == "/api/voz/apagar":
            try:
                apagar_voz_clonada()
            except ErroProvedor as e:
                return self._json({"ok": False, "erro": e.detalhe}, 502)
            return self._json({"ok": True})
        if rota == "/api/confirmar":
            p = PENDENTES.pop(dados.get("token"), None)
            if not p:
                return self._json({"tipo": "resposta", "fala": "Essa confirmação expirou.", "passos": []})
            senha = CFG.get("senha_confirmacao", "")
            ok = bool(dados.get("autorizado"))
            if ok and senha and norm(senha) not in norm(dados.get("frase", "")):
                ok = False
            try:
                r = rodar_agente(p["sessao"], retomar={"confirmado": ok, "mensagens": p["mensagens"],
                                                       "pendente": p["pendente"]})
            except ErroProvedor as e:
                return self._json({"tipo": "resposta", "fala": "Falhou: %s" % e.detalhe[:160], "passos": []})
            if r["tipo"] == "confirmar":
                r["senha"] = bool(senha)
            return self._json(r)
        if rota == "/api/chave":
            prov = dados.get("provedor")
            chave = (dados.get("chave") or "").strip()
            if prov not in ("anthropic", "gemini"):
                return self._json({"ok": False, "erro": "provedor inválido"}, 400)
            CFG["api_key" if prov == "anthropic" else "gemini_key"] = chave
            salvar_config()
            aviso = ""
            if chave and prov == "anthropic" and not chave.startswith("sk-ant-"):
                aviso = "A chave da Anthropic costuma começar com sk-ant-. Confira se copiou inteira."
            if chave and prov == "gemini" and not (chave.startswith("AQ.") or chave.startswith("AIza")):
                aviso = "A chave do Google AI Studio começa com AQ. (formato novo) ou AIza (antigo). Confira se copiou inteira."
            if chave and (len(chave) < 30 or re.search(r"\s", chave)):
                aviso = "A chave parece incompleta ou tem espaços. Copie de novo, inteira."
            return self._json({"ok": True, "chave": bool(chave), "aviso": aviso})
        if rota == "/api/config":
            mudou = []
            if dados.get("modo_escuta") in ("palavra", "sempre"):
                CFG["modo_escuta"] = dados["modo_escuta"]; mudou.append("modo_escuta")
            if "janela_seguimento" in dados:
                CFG["janela_seguimento"] = max(0, min(30, int(dados["janela_seguimento"] or 0))); mudou.append("janela")
            if dados.get("poderes") in ("leitura", "escrita", "total"):
                CFG["poderes"] = dados["poderes"]; mudou.append("poderes")
            if isinstance(dados.get("provedores"), list):
                ordem = [p for p in dados["provedores"] if p in ("anthropic", "gemini")]
                if ordem:
                    CFG["provedores"] = ordem; mudou.append("provedores")
            if isinstance(dados.get("cidade"), str) and dados["cidade"].strip():
                CFG["cidade"] = dados["cidade"].strip()[:60]; mudou.append("cidade")
            if isinstance(dados.get("senha_confirmacao"), str):
                CFG["senha_confirmacao"] = dados["senha_confirmacao"].strip()[:40]; mudou.append("senha")
            if isinstance(dados.get("tratamento"), str) and dados["tratamento"].strip():
                CFG["tratamento"] = dados["tratamento"].strip()[:40]; mudou.append("tratamento")
            if dados.get("voz_motor") in ("auto", "gemini", "navegador"):
                CFG["voz_motor"] = dados["voz_motor"]; mudou.append("voz_motor")
            if dados.get("voz_premium") in [v for v, _ in VOZES_PREMIUM] or \
                    (dados.get("voz_premium") == "clonada" and CFG.get("voz_clonada")):
                CFG["voz_premium"] = dados["voz_premium"]; mudou.append("voz_premium")
            if dados.get("musica_fonte") in ("spotify", "youtube"):
                CFG["musica_fonte"] = dados["musica_fonte"]; mudou.append("musica_fonte")
            if dados.get("cenario") in ("terra", "nenhum"):
                CFG["cenario"] = dados["cenario"]; mudou.append("cenario")
            if isinstance(dados.get("local_fixo"), str):
                CFG["local_fixo"] = dados["local_fixo"].strip()[:60]; mudou.append("local_fixo")
            if isinstance(dados.get("spotify_favoritas"), str):
                favs = []
                for linha in dados["spotify_favoritas"].splitlines()[:40]:
                    if "=" not in linha:
                        continue
                    nome, link = linha.split("=", 1)
                    s = RX_SPOTIFY.search(link) or re.search(r"spotify:(track|album|playlist|artist):([A-Za-z0-9]{22})", link)
                    if nome.strip() and s:
                        favs.append({"nome": nome.strip()[:60], "uri": "spotify:%s:%s" % (s.group(1), s.group(2))})
                CFG["spotify_favoritas"] = favs; mudou.append("spotify_favoritas")
            if isinstance(dados.get("spotify_client_id"), str):
                cid = dados["spotify_client_id"].strip()
                if re.fullmatch(r"[A-Za-z0-9]{0,64}", cid) and cid != CFG.get("spotify_client_id"):
                    CFG["spotify_client_id"] = cid
                    CFG["spotify_refresh"] = ""
                    SP.update(token="", expira=0.0)
                    mudou.append("spotify_client_id")
            if mudou:
                salvar_config()
            return self._json({"ok": True, "mudou": mudou})
        if rota == "/api/notas":
            acao = dados.get("acao")
            if acao == "salvar":
                nid, nova = nota_salvar(dados.get("area"), dados.get("titulo"), dados.get("texto"), dados.get("id") or None)
                return self._json({"ok": True, "id": nid, "nova": nova})
            if acao == "excluir":
                return self._json({"ok": True, "removidas": nota_excluir(dados.get("id"))})
            return self._json({"ok": False}, 400)
        if rota == "/api/agenda":
            acao = dados.get("acao")
            if acao == "add":
                ev = agenda_add(dados.get("inicio"), dados.get("duracao", 60), dados.get("titulo"))
                return self._json({"ok": bool(ev), "evento": ev})
            if acao == "del":
                return self._json({"ok": True, "removidos": agenda_del(dados.get("id", ""))})
            return self._json({"ok": False}, 400)
        if rota == "/api/abrir":
            return self._json({"ok": abrir_no_sistema(dados.get("alvo"), dados.get("url"))})
        if rota == "/api/limpar":
            SESSOES.pop(str(dados.get("sessao") or "padrao"), None)
            return self._json({"ok": True})
        if rota == "/api/rosto":
            lm = dados.get("rosto")
            if not isinstance(lm, dict):
                return self._json({"ok": False}, 400)
            atual = json_ler(UI / "rosto.json", {})
            atual.update(lm)
            json_salvar(UI / "rosto.json", atual)
            return self._json({"ok": True})
        if rota == "/api/rosto/imagem":
            m = re.match(r"^data:image/(png|jpe?g|webp);base64,(.+)$", dados.get("imagem") or "", re.S)
            if not m:
                return self._json({"ok": False, "erro": "imagem inválida"}, 400)
            ext = "jpg" if m.group(1).startswith("j") else m.group(1)
            nome = "rosto-personalizado.%s" % ext
            (UI / nome).write_bytes(base64.b64decode(m.group(2)))
            atual = json_ler(UI / "rosto.json", {})
            atual["img"] = nome
            for k in ("w", "h"):
                if k in dados:
                    atual[k] = int(dados[k])
            if isinstance(dados.get("pontos"), dict):
                atual.update(dados["pontos"])
            json_salvar(UI / "rosto.json", atual)
            return self._json({"ok": True, "img": nome})
        return self._json({"erro": "rota desconhecida"}, 404)


class Servidor(socketserver.ThreadingTCPServer):
    allow_reuse_address = False
    daemon_threads = True


def abrir_navegador(url):
    pref = CFG.get("navegador", "edge")
    caminhos = {
        "edge": [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                 r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"],
        "chrome": [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                   r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                   os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")],
    }
    for nome in [pref] + [n for n in caminhos if n != pref]:
        for c in caminhos.get(nome, []):
            if os.path.exists(c):
                try:
                    subprocess.Popen([c, url])
                    return
                except Exception:
                    pass
    webbrowser.open(url)


def main():
    for p in (MEM, PROJ, KB):
        p.mkdir(exist_ok=True)
    if _CONFIG_INCOMPLETA:
        salvar_config()
    brain_ler()
    INDICE.garantir()
    url = "http://127.0.0.1:%d/" % PORTA
    base = INDICE.resumo()
    provs = provedores_ativos()

    print("=" * 64)
    print("  ÍCARO v%s  ·  Inteligência, Contabilidade, Análises, Resultados e Operações" % VERSAO)
    print("=" * 64)
    print("  endereço    : %s" % url)
    print("  cérebro     : %s" % (" -> ".join(provs) if provs else "SEM CHAVE (cole nas configurações)"))
    print("  modelo      : %s" % CFG["modelo"])
    print("  base local  : %d trechos em %d documentos" % (base["trechos"], len(base["documentos"])))
    print("  memória     : %d notas" % len(brain_ler()["notas"]))
    print("  escuta      : %s" % ("palavra de ativação (Olá Ícaro)" if CFG.get("modo_escuta") == "palavra"
                                  else "contínua"))
    print("  poderes     : %s" % CFG.get("poderes"))
    print("-" * 64)
    print("  Deixe esta janela aberta. Para desligar, feche ou tecle Ctrl+C.")
    print("=" * 64)

    try:
        srv = Servidor(("127.0.0.1", PORTA), Handler)
    except OSError as e:
        print("\n  A porta %d já está em uso (%s)." % (PORTA, e))
        print("  O ÍCARO provavelmente já está rodando. Vou abrir a tela dele.")
        if CFG.get("abrir_navegador", True) and not os.environ.get("ICARO_SEM_NAVEGADOR"):
            abrir_navegador(url)
        time.sleep(4)
        return

    if iniciar_servidor_sistemas():
        print("  sistemas    : http://127.0.0.1:%d (Discipulus e LabEduContábil)" % PORTA_SIS)
    for alvo in (laco_rotinas, laco_vigilancia, laco_agenda, laco_limpeza):
        threading.Thread(target=alvo, daemon=True).start()
    if CFG.get("abrir_navegador", True) and not os.environ.get("ICARO_SEM_NAVEGADOR"):
        threading.Timer(1.0, lambda: abrir_navegador(url)).start()
    try:
        with srv:
            srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  ÍCARO desligado.")


if __name__ == "__main__":
    main()
