@echo off
chcp 65001 >nul
title ICARO - desligar
echo.
echo   Procurando o ICARO em execucao...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p=Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*icaro.py*' };" ^
  "if($p){ $p | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }; Write-Output '  ICARO desligado.' }" ^
  "else { Write-Output '  O ICARO nao estava rodando.' }"
echo.
pause
