@echo off
chcp 65001 >nul
title ICARO - assistente do Romulo
cd /d "%~dp0"

rem Procura o Python. Sem blocos entre parenteses: um ")" num texto quebraria o arquivo inteiro.
set "PYEXE="
py -3 --version >nul 2>&1 && set "PYEXE=py -3" && goto TEMPY
python --version >nul 2>&1 && set "PYEXE=python" && goto TEMPY
python3 --version >nul 2>&1 && set "PYEXE=python3" && goto TEMPY
goto SEMPYTHON

:TEMPY
echo.
echo   Subindo o ICARO com %PYEXE% ...
echo   Deixe esta janela aberta enquanto usa o ICARO.
echo.
%PYEXE% icaro.py
echo.
echo   O ICARO foi encerrado.
pause
exit /b

:SEMPYTHON
echo.
echo  ============================================================
echo    O ICARO precisa do Python e nao encontrei nesta maquina.
echo  ============================================================
echo.
echo    Opcao 1: instalar agora pela loja da Microsoft, via winget.
echo    Opcao 2: baixar em https://www.python.org/downloads/
echo             e marcar Add Python to PATH na instalacao.
echo.
choice /C SN /N /M "    Instalar o Python agora pelo winget? [S/N] "
if errorlevel 2 goto MANUAL
winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
echo.
echo    Instalado. FECHE esta janela e abra o ICARO de novo.
pause
exit /b

:MANUAL
start https://www.python.org/downloads/
pause
exit /b
