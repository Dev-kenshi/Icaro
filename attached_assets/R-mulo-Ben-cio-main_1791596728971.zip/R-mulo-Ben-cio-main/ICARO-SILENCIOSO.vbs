' Sobe o ICARO sem mostrar a janela preta. Usado pela inicializacao automatica.
Dim fso, sh, pasta
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = pasta
sh.Run """" & pasta & "\ICARO.bat""", 0, False
