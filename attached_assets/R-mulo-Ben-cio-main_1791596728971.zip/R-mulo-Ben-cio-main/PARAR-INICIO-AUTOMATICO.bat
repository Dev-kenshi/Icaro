@echo off
chcp 65001 >nul
title ICARO - parar de iniciar com o Windows
set "INICIO=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%INICIO%\ICARO.lnk" (
  del "%INICIO%\ICARO.lnk"
  echo   Removido. O ICARO nao sobe mais sozinho.
) else (
  echo   Ele ja nao estava na inicializacao.
)
echo.
pause
