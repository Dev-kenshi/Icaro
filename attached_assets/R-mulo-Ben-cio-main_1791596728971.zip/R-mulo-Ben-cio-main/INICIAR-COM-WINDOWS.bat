@echo off
chcp 65001 >nul
title ICARO - iniciar junto com o Windows
cd /d "%~dp0"
set "INICIO=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
echo.
echo   Instalando o ICARO na inicializacao do Windows...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%INICIO%\ICARO.lnk');" ^
  "$s.TargetPath='%~dp0ICARO-SILENCIOSO.vbs';" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.Description='ICARO Desk - assistente do Romulo';" ^
  "$s.Save()"
if exist "%INICIO%\ICARO.lnk" (
  echo   Pronto. A partir do proximo boot o ICARO sobe sozinho,
  echo   sem janela preta, e abre a tela do holograma.
) else (
  echo   Nao consegui criar o atalho. Rode este arquivo como administrador.
)
echo.
pause
