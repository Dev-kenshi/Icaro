# ÍCARO v5

Assistente pessoal de voz e especialista em contabilidade do professor Rômulo Benício.
Inteligência, Contabilidade, Análises, Resultados e Operações.

## Novidades da versão 5 (comandos de voz)

| Diga | O que acontece |
|---|---|
| "Olá, Ícaro, estamos na UEFS" | Boa noite à UEFS e à ITCONT, título do evento, e o planeta voa até o campus |
| "Olá, Ícaro, toca Gilberto Gil" | Toca no Spotify, dentro da tela do Ícaro (YouTube só como reserva) |
| "Olá, Ícaro, mostre o painel financeiro" | Painel ao lado: dólar, euro, peso uruguaio, Selic, IPCA, CDI, Ibovespa e o clima |
| "Olá, Ícaro, qual a temperatura?" | Clima de Feira de Santana (ou da cidade pedida) no painel e falado |
| "Olá, Ícaro, mostre Montevidéu" ou "onde fica Paris" | O planeta 3D voa até o lugar e marca no mapa |
| "Olá, Ícaro, onde estamos?" | Mostra e diz onde o Ícaro está (Feira de Santana, Montevidéu...) |
| "aproxime", "afaste", "volte para o planeta" | Controla o globo (o mouse também: arrastar gira, a roda aproxima) |
| "Olá, Ícaro, fale em espanhol" | Passa a ouvir e responder em espanhol do Uruguai |
| "Ícaro, fale em português brasileiro" | Volta ao português |
| "Olá, Ícaro, quem é o professor Rômulo?" | Foto e currículo do professor na tela |
| "Olá, Ícaro, o que é o Contador do Amanhã?" | Logo e explicação do projeto (Resolução nº 101/2026) |
| "Olá, Ícaro, mostre o Discipulus" | Abre o Discipulus na tela e apresenta as funções, tela por tela |
| "Olá, Ícaro, mostre o LabEduContábil" | Abre o LabEduContábil UEFS e apresenta os módulos |
| no tour: "próximo", "volte", "pausa", "continue", "feche o sistema" | Controla a apresentação (setas do teclado também) |

## Como ligar

1. Dois cliques no atalho **ÍCARO** da Área de Trabalho (ou em `ICARO.bat`, nesta pasta).
2. Uma janela preta abre e fica aberta: ela é o servidor do ÍCARO. Não feche durante o uso.
3. O Edge abre sozinho em `http://127.0.0.1:8765`. Clique em **ATIVAR ÍCARO** e permita o microfone.
4. Diga **"Olá, Ícaro"** e faça o pedido na mesma frase ou logo depois do bipe.

Para desligar: feche a janela preta, ou use `DESLIGAR-ICARO.bat`.

## Antes do evento

1. Entre no Spotify pelo Edge (abra open.spotify.com e faça login) para tocar faixas inteiras, e
   cadastre as músicas do evento em ⚙ → MÚSICAS FIXAS DO SPOTIFY.
2. ⚙ → **PREPARAR VOZ PREMIUM DA APRESENTAÇÃO**: gera e guarda a abertura, a saudação à UEFS, o
   professor, o Contador do Amanhã e os tours dos dois sistemas. Em espanhol, prepara também as falas
   em espanhol. No palco, tudo toca na hora, sem internet e sem gastar cota.
3. Teste "Ícaro, estamos na UEFS", "mostre o Discipulus" e "mostre o painel financeiro".
4. Teste o microfone do auditório, deixe o notebook na tomada e use caixa de som com volume moderado.

## Voz

- **Voz premium (padrão):** vozes de IA do Google, praticamente humanas. Usa a chave gratuita do
  Gemini. Escolha a voz em ⚙ (botão OUVIR para comparar; sugestões: Charon, Orus, Sadaltager, Achird).
- **Reserva automática:** se a cota acabar ou a internet cair, ele continua com a voz do Edge e
  tenta a premium de novo em 10 minutos.
- **Cache:** frases repetidas não gastam cota e tocam até sem internet.
- **Voz do navegador:** no Edge, "Microsoft Antonio Online (Natural)". Em espanhol, "Microsoft Mateo
  Online (Natural), Spanish (Uruguay)". Daniel e Maria são as vozes robóticas antigas do Windows.
- Na voz premium a resposta começa cerca de 1 segundo depois da voz do Edge, porque o áudio é gerado
  na nuvem. Para conversa rápida, ⚙ → MOTOR DE VOZ → "Só a voz do navegador".

### Clonar a sua voz

⚙ → **CLONAR MINHA VOZ**. O Google cria um modelo da sua voz (Gemini 3.8 TTS, replicação de voz)
com duas gravações suas, feitas no mesmo microfone: uma **leitura** de 10 a 30 segundos e a
**autorização** com a frase exata "Eu sou o proprietário desta voz e autorizo o Google a usá-la para
criar um modelo de voz sintética." Dá para gravar ali ou ENVIAR ÁUDIO (WhatsApp, MP3, M4A, WAV).
Depois de CRIAR MINHA VOZ, ela aparece como "MINHA VOZ (clonada)" e já fica escolhida. O modelo
expira após um ano sem uso; APAGAR VOZ CLONADA remove e volta para a Charon. Se usar a voz clonada no
palco, vale avisar a plateia que é uma voz sintética.

## Boca e legendas

A boca segue o áudio real da voz premium: antes de tocar, o Ícaro mede a energia e os formantes da
fala e decide quando abrir, arredondar (o, u), esticar (e, i) e fechar (m, b, p), com acenos de cabeça
e sobrancelhas nas sílabas fortes. A legenda mostra a frase que está sendo dita, em letra grande e
branca sobre faixa escura.

## Spotify

- Sem configurar nada: o Ícaro acha a música e toca no player oficial do Spotify dentro da tela.
  **Para a faixa inteira, entre uma vez no Spotify neste Edge**; sem login, o Spotify toca só uma
  prévia de 30 segundos.
- **Músicas fixas** (⚙ → MÚSICAS FIXAS DO SPOTIFY): uma por linha, `nome = link do Spotify`, por
  exemplo `abertura = https://open.spotify.com/track/...`. "Ícaro, toca abertura" toca na hora, sem
  depender de busca na internet. Recomendado para as músicas do evento.
- Toda música que já tocou fica guardada e toca de novo sem buscar. Os buscadores da internet
  bloqueiam muitas consultas seguidas; quando isso acontece, o Ícaro troca de buscador sozinho e,
  em último caso, usa o YouTube.
- **Spotify Premium (opcional):** crie um app em developer.spotify.com com o Redirect URI mostrado em
  ⚙, cole o Client ID e clique em CONECTAR. A música passa a tocar no aplicativo do Spotify do
  computador (deixe-o aberto), com o volume abaixando enquanto o Ícaro fala.
- ⚙ → MÚSICA → YouTube volta ao comportamento antigo.

## Planeta Terra 3D

O planeta gira devagar atrás do Ícaro, com imagens de satélite da Esri. Arraste para girar, use a roda
do mouse para aproximar ou os botões à direita (+, −, onde estamos, planeta inteiro). Para saber onde
está, ele usa a localização do Windows (o Edge pede permissão uma vez) ou, se negada, a internet. Em ⚙
→ ONDE O ÍCARO ESTÁ dá para fixar o lugar (por exemplo, Montevidéu na viagem). ⚙ → CENÁRIO → Sem
cenário deixa o Ícaro mais leve em computadores fracos. O globo precisa de internet para as imagens.

## Painel financeiro

Cotações em reais (dólar, euro, peso uruguaio, peso argentino e bitcoin, pela AwesomeAPI), Selic meta,
IPCA de 12 meses e CDI (Banco Central), Ibovespa e o gráfico do dólar em 30 dias (passe o mouse para
ver cada dia), além do clima da cidade. Atualiza a cada 5 minutos enquanto estiver aberto. Valores
informativos. "Ícaro, feche o painel" esconde.

## Espanhol (visita a Montevidéu)

"Ícaro, fale em espanhol" muda a escuta para espanhol do Uruguai e as respostas para espanhol
rioplatense; a voz premium recebe instrução de sotaque uruguaio. Hora, data, clima, música, mapa e
painel respondem em espanhol, e o painel mostra o peso uruguaio primeiro. O idioma fica guardado até
"Ícaro, fale em português brasileiro". A apresentação da ITCONT continua em português.

## Sistemas do professor

O Discipulus e o LabEduContábil abrem dentro do Ícaro, numa porta separada (8766), isolados da página
do Ícaro. Ele lê sempre o arquivo original na pasta LABORATÓRIO CONTÁBIL dos Documentos, então a versão
mais nova aparece sozinha; se o arquivo mudar de lugar, ajuste `sistemas` no config.json ou deixe uma
cópia em `sistemas/discipulus.html` e `sistemas/labedu.html` (já há cópias de segurança). A apresentação
entra sozinha na demonstração (perfil Ecônomo no Discipulus; professor e base didática de 30 empresas
no LabEdu), sem mexer nos dados que você usa ao abrir os arquivos direto.

## Como conversar

- **Ativação:** "Olá, Ícaro" ou começar a frase com "Ícaro". Qualquer pessoa pode ativar.
- **Seguimento:** depois de responder, ele escuta por 8 segundos sem precisar do nome.
- **Interromper:** "Ícaro, pare", "chega", ou a tecla Esc.
- **Teclado:** barra de espaço faz ele ouvir na hora (útil em auditório barulhento).
- **Passador de slides:** Page Down faz ele ouvir, Page Up interrompe.

## O que ele sabe

**Contabilidade e normas.** Pública (Lei 4.320, MCASP 11ª edição, PCASP, LRF, NBC TSP). Societária
(Lei 6.404, Leis 11.638/2007 e 11.941/2009, todos os CPCs com a IFRS correspondente, CPC PME e NBC TG
1001 e 1002). Profissão (Decreto-Lei 9.295/1946, Lei 12.249/2010, Lei 6.839/1980, Código de Ética, NBC
PG, PA, PI e PP, normas técnicas de auditoria e perícia, Resolução CFC 750/1993 com a explicação de que
foi revogada em 2016). Tributária (reforma do consumo: IBS, CBS, IS, LC 214/2025, LC 227/2026; LC
224/2025 e Lei 15.270/2025). Uruguai (normas adequadas, NIIF, IVA, IRAE). Cada resposta técnica consulta
a base local e mostra as fontes na tela. Não há limite de perguntas: cada uma consome alguns tokens do
cérebro em nuvem (veja o contador no topo).

**Construção de sistemas.** "Ícaro, construa um sistema de..." gera os arquivos completos, mostra no
painel e salva na pasta `projetos`.

**Assistente pessoal.** Agenda com aviso 10 minutos antes e exportação .ics; rotinas ("todo dia às
oito me diga o que tenho pela frente"); música; clima; timer; opinião sobre ideias; memória (Second
Brain).

**Operador do computador.** Listar, abrir, organizar e mover arquivos, PowerShell e vigilância de
pastas. Tudo que apaga, sobrescreve ou altera o sistema pede autorização ("confirmo" ou "não"). Defina
uma **senha falada** nas configurações. No modo palco o operador fica desligado.

## Apresentação na ITCONT

- "Ícaro, estamos na UEFS": boa noite à universidade e à ITCONT.
- Tecla **P**, botão **ITCONT**, ou "Olá, Ícaro, dê boa noite e se apresente": tela cheia, título da
  ITCONT, apresentação com a foto do professor e a logo do Contador do Amanhã.
- Tecla **F** liga e desliga o modo palco. **Esc** sai.

## Cérebro e economia de tokens

- Comandos simples (hora, data, agenda, música, clima, painel, mapa, timer, volume, apresentação,
  tours) são resolvidos na máquina, sem nuvem, sem custo e na hora.
- Perguntas abertas passam por uma busca local (BM25) na pasta `conhecimento` e na memória: só os
  trechos relevantes vão para o modelo.
- A resposta chega em streaming e a voz começa na primeira frase pronta.
- Cérebro principal: Claude (Anthropic). Reserva automática: Gemini (Google). Se os dois falharem, ele
  responde pela base local e avisa.

## Pastas

```
ICARO.bat                 liga tudo
icaro.py                  servidor: cérebro, busca local, operador, agenda, música, clima, finanças, mapa
config.json               chaves e preferências (as chaves nunca vão ao navegador)
conhecimento/             base de normas em Markdown: acrescente seus próprios arquivos .md ou .txt
memoria/                  memórias, agenda, rotinas, histórico, cache de voz e de músicas
projetos/                 sistemas e arquivos gerados pelo ÍCARO
sistemas/                 cópia de segurança do Discipulus e do LabEduContábil
ui/index.html             holograma, voz, escuta, globo, painéis e tours
ui/tour.js                roteiro que conduz a apresentação dentro dos sistemas
ui/spotify.html           player do Spotify, isolado em outra porta
ui/vendor/                MapLibre GL (globo 3D), licença BSD
ui/rosto.jpg, rosto.json  rosto e a calibragem dos olhos, sobrancelhas e boca
ui/romulo.jpg             foto do professor; ui/contador-do-amanha.webp, logo do projeto
_backup-v3-2026-10-08/    cópia integral do ÍCARO Desk v3
_backup-v4-2026-10-09/    a versão 4, antes desta atualização
```

## Ampliar a base de conhecimento

Coloque arquivos `.md` ou `.txt` em `conhecimento`. Use `#` para o título do documento e `##` para
cada seção: cada seção vira um trecho pesquisável. A atualização é automática, sem reiniciar.

## Trocar ou recalibrar o rosto

Configurações, botão **TROCAR IMAGEM DO ROSTO** e depois **CALIBRAR ROSTO**: arraste os pontos dos
olhos, sobrancelhas, cantos da boca, lábios e queixo. Funciona melhor com fundo escuro.

## Quando algo não funciona

- **Microfone bloqueado:** cadeado na barra de endereço, permitir microfone, F5.
- **Música só com 30 segundos:** entre no Spotify pelo Edge (open.spotify.com) e peça de novo.
- **Música não acha:** use as músicas fixas (nome = link) ou cole o link do Spotify na busca da aba MÚSICA.
- **Globo escuro:** sem internet, as imagens de satélite não carregam; o resto funciona.
- **Sistema não abre no tour:** confira se a janela preta está aberta e se o arquivo existe no caminho.
- **"Cérebro indisponível":** veja a aba OPERADOR. Erro 400 de crédito na Anthropic significa saldo
  zerado; cadastre a chave gratuita do Gemini em aistudio.google.com/apikey.
- **Rosto como foto parada:** o navegador não liberou WebGL; atualize o Edge ou o driver de vídeo.

## Limites honestos

O reconhecimento de voz do navegador depende de internet e não reconhece quem está falando, por isso
existe a senha falada. A busca de músicas sem conta do Spotify depende de buscadores que podem bloquear
muitas consultas seguidas (por isso as músicas fixas). Normas mudam: a base local foi conferida em
outubro de 2026, e o ÍCARO avisa quando um tema está em transição. Para decisões formais, confira
sempre o texto oficial.
