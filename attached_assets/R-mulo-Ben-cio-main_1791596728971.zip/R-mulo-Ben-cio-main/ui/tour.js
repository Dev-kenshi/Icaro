/* ÍCARO · roteiro de apresentação injetado no Discipulus e no LabEduContábil.
   Só obedece à janela do Ícaro (porta local) e só faz o que uma apresentação precisa: entrar na demonstração,
   trocar de tela, rolar e destacar um item. Não lê nem envia dados do sistema. */
(function(){
  "use strict";
  var PAI = null;
  var ORIGEM_OK = /^http:\/\/(127\.0\.0\.1|localhost):\d{2,5}$/;

  function sistema(){
    var t = document.title || "";
    if (/DISCIPULUS/i.test(t)) return "discipulus";
    if (/LABCONT/i.test(t)) return "labedu";
    return "";
  }
  function responder(msg){ msg.icaro = 1; if (PAI) parent.postMessage(msg, PAI); }
  function feito(d, ms){ setTimeout(function(){ responder({ tipo: "feito", id: d.id }); }, ms || 0); }
  function erro(d, e){ responder({ tipo: "erro", id: d.id, erro: String(e && e.message || e).slice(0, 160) }); }
  function esperar(cond, ms){
    return new Promise(function(ok){
      var t0 = Date.now();
      (function laco(){ var r = false; try { r = cond(); } catch (e) {}
        if (r || Date.now() - t0 > ms) return ok(!!r); setTimeout(laco, 150); })();
    });
  }
  function porTexto(seletor, rx){
    var els = document.querySelectorAll(seletor);
    for (var i = 0; i < els.length; i++){ if (rx.test((els[i].innerText || els[i].textContent || "").trim())) return els[i]; }
    return null;
  }

  /* ---------- Discipulus: entra pelo acesso rápido da demonstração (o próprio sistema mostra a senha de demo) ---------- */
  function entrarDiscipulus(d){
    var logado = function(){ return !/#\/entrar/.test(location.hash) && document.querySelector("a[href='#/contabil']"); };
    if (logado()) return feito(d);
    esperar(function(){ return porTexto("button", /Ec[oô]nomo diocesano|Contadora diocesana/); }, 8000).then(function(){
      var perfil = porTexto("button", /Ec[oô]nomo diocesano/) || porTexto("button", /Contadora diocesana/);
      if (!perfil) throw new Error("acesso rápido da demonstração não encontrado");
      perfil.click();
      return esperar(function(){ return porTexto("button", /Entrar no sistema/); }, 3000);
    }).then(function(){
      var b = porTexto("button", /Entrar no sistema/); if (b) b.click();
      return esperar(logado, 10000);
    }).then(function(ok){ if (ok) feito(d, 300); else erro(d, "não consegui entrar na demonstração"); })
      .catch(function(e){ erro(d, e); });
  }

  /* ---------- LabEduContábil: sessão de demonstração com a conta do professor e a base didática ---------- */
  function entrarLabEdu(d){
    try {
      if (!document.body.classList.contains("autenticado")){
        if (typeof auth === "undefined" || !auth.usuarios) throw new Error("base de acesso não carregada");
        var prof = auth.usuarios.filter(function(u){ return u.papel === "professor" && u.status !== "bloqueado"; })[0];
        if (!prof) throw new Error("conta do professor não encontrada");
        abrirSessao(prof);
      }
      if (typeof db !== "undefined" && db && db.companies && !db.companies.length && typeof instalarBaseDidatica === "function"){
        instalarBaseDidatica(true);
      }
      if (typeof db !== "undefined" && db && db.companies && db.companies.length && !db.selectedCompanyId){
        db.selectedCompanyId = db.companies[0].id;
        if (typeof saveDB === "function") saveDB(); else if (typeof renderAll === "function") renderAll();
      }
      if (typeof openSec === "function") openSec("inicio");
      /* o aviso "servidor da turma não configurado" é para a turma, não para o palco */
      var av = document.getElementById("avisoAmbiente"); if (av) av.remove();
      feito(d, 300);
    } catch (e) { erro(d, e); }
  }

  /* ---------- destaque visual de um item da tela ---------- */
  var caixa = null;
  function destacar(el){
    if (!el) return;
    el.scrollIntoView({ block: "center", behavior: "smooth" });
    setTimeout(function(){
      var r = el.getBoundingClientRect();
      if (!caixa){ caixa = document.createElement("div");
        caixa.style.cssText = "position:fixed;z-index:2147483647;pointer-events:none;border:3px solid #4fd1ff;border-radius:10px;" +
          "box-shadow:0 0 0 4px rgba(79,209,255,.25),0 0 28px rgba(79,209,255,.8);transition:all .35s ease";
        document.body.appendChild(caixa); }
      caixa.style.left = (r.left - 6) + "px"; caixa.style.top = (r.top - 6) + "px";
      caixa.style.width = (r.width + 12) + "px"; caixa.style.height = (r.height + 12) + "px"; caixa.style.opacity = "1";
      clearTimeout(caixa._t); caixa._t = setTimeout(function(){ caixa.style.opacity = "0"; }, 3200);
    }, 450);
  }

  function executar(d){
    switch (d.acao){
      case "login":
        if (sistema() === "discipulus") return entrarDiscipulus(d);
        if (sistema() === "labedu") return entrarLabEdu(d);
        return erro(d, "sistema desconhecido");
      case "rota":
        if (!/^\/[a-z0-9\-\/]*$/.test(d.valor || "")) return erro(d, "rota inválida");
        location.hash = "#" + d.valor; window.scrollTo({ top: 0, behavior: "smooth" });
        var link = document.querySelector("a[href='#" + d.valor + "']"); if (link && d.valor !== "/") destacar(link);
        return feito(d, 500);
      case "secao":
        if (!/^[a-z]+$/.test(d.valor || "") || typeof openSec !== "function") return erro(d, "seção inválida");
        if (d.valor === "inss" && !document.getElementById("inss")) return feito(d);
        openSec(d.valor); window.scrollTo({ top: 0, behavior: "smooth" });
        destacar(document.querySelector(".mod[data-sec='" + d.valor + "']"));
        return feito(d, 400);
      case "destacar":
        destacar(porTexto("a,button,h1,h2,h3,h4,.mod,li", new RegExp(String(d.valor || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i")));
        return feito(d, 300);
      case "rolar":
        window.scrollBy({ top: Number(d.valor) || 400, behavior: "smooth" });
        return feito(d, 300);
      default:
        return erro(d, "ação desconhecida");
    }
  }

  window.addEventListener("message", function(ev){
    if (ev.source !== window.parent || !ORIGEM_OK.test(ev.origin) || ev.origin === location.origin) return;
    var d = ev.data; if (!d || d.icaro !== 1 || !d.acao) return;
    PAI = ev.origin;
    try { executar(d); } catch (e) { erro(d, e); }
  });

  function avisarPronto(){ if (window.parent !== window) window.parent.postMessage({ icaro: 1, tipo: "pronto", sistema: sistema() }, "*"); }
  if (document.readyState === "complete") setTimeout(avisarPronto, 300);
  else window.addEventListener("load", function(){ setTimeout(avisarPronto, 300); });
})();
