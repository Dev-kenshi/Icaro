# Site do I ITCONT: kit para o Replit

Site público do evento, em **`/itcont`** dentro do app do ÍCARO (mesmo deploy no Render, plano grátis).

**Desenvolvedor do projeto: Emanuel Macêdo Luz**

## Passo a passo (3 minutos + o tempo do Agent)
1. Arraste o `Site-ITCONT.zip` para a lista de arquivos do Replit.
2. No **Shell** do Replit:
   ```bash
   unzip -o Site-ITCONT.zip && bash Site-ITCONT/instalar-kit.sh
   ```
   O resultado esperado nessa hora é **67/100**: dados, regras e cores já passam; o resto é a interface.
3. Abra `Site-ITCONT/PROMPT_REPLIT_SITE_ITCONT.md`, copie tudo e cole no **Replit Agent**.
4. O Agent constrói o site até chegar a **100/100**, mostra os prints dos 5 modos e faz o push.
5. Acesse `https://SEU-SITE/itcont` e, no auditório, `https://SEU-SITE/itcont?modo=telao`.

## O que vem no zip
| Arquivo | Para quê |
|---|---|
| `PROMPT_REPLIT_SITE_ITCONT.md` | O prompt completo para o Agent: identidade visual, 5 experiências responsivas, seções, Nielsen, 10 leis da beleza, validação e entrega |
| `instalar-kit.sh` | Copia o kit para `artifacts/icaro/src/itcont/` e registra o validador |
| `arquivos/.../dados.ts` | Dados oficiais da página do Even3: datas, sessões, convidados, categorias, FAQ e créditos |
| `arquivos/.../logica.ts` | Regras testadas: contagem, fase do evento (antes / ao vivo / intervalo / encerrado), agenda .ics e Google, mapa, WhatsApp, 5 layouts, contraste e razão áurea |
| `arquivos/.../tokens.css` | Cores e texturas do banner (azul royal 3D, cromo escovado, neon, grade luminosa), fontes e espaçamento |
| `arquivos/.../validate-itcont-site.ts` | As **100 validações** |

## As 100 validações
| Grupo | Qtd | Exemplos |
|---|---|---|
| A. Dados oficiais | 14 | Datas 21–22/10/2026, fuso de Brasília, 3 sessões sem sobreposição, 7 convidados, inscrição gratuita, igual ao banco (seed) |
| B. Regras | 28 | Contagem, fases ao vivo e intervalo, troca exata de sessão, .ics válido (CRLF, UTC, escape), Google Agenda, mapa, WhatsApp, 5 layouts |
| C. Identidade e beleza | 15 | 8 pares de contraste WCAG, escala áurea 1,618, grade de 8px, 3 fontes, movimento reduzido, foco visível, toque de 44px |
| D. Interface (Nielsen) | 40 | Rota pública fora do login, lazy, âncoras, pular para o conteúdo, 1 h1, aria-live, alt, foto reserva, rel=noopener, sem data no código, sem hex solto, 5 modos no CSS, @container, impressão, SEO/OG, créditos |
| E. Integração | 3 | Nenhuma imagem copiada, script registrado, nenhuma dependência pesada |

Para rodar a qualquer momento:
```bash
pnpm --filter @workspace/scripts run validate:itcont-site
```

## A dinâmica (o que sites de evento fazem bem e entrou no prompt)
- **Acima da dobra:** o quê, quando, onde e um botão claro de inscrição (padrão de Web Summit, Rio2C, Campus Party).
- **Contagem regressiva e status "ao vivo"**, que vira "Agora no palco / A seguir" durante o evento (padrão de Google I/O, Apple Event).
- **Programação por dia com "adicionar à agenda"** (Config, Next.js Conf).
- **Ingresso digital personalizado para divulgar** (Vercel Ship, Next.js Conf): aqui é o "cartão de divulgação" com o nome da pessoa, gerado no navegador e sem salvar nada.
- **Modo telão** para o projetor do auditório, com QR code do site.
- **Compartilhar** com 1 toque e **FAQ** para tirar dúvidas antes de perguntar.

## Limites respeitados
- Só dados públicos da página oficial do Even3; fotos e logo ficam como links do Even3 (nada copiado).
- Sem serviço pago, chave de API ou banco novo.
- Créditos: "Emanuel Macêdo Luz, desenvolvedor do projeto".
