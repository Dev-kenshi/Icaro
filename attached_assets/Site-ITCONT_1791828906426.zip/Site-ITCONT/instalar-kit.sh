#!/usr/bin/env bash
# Copia o kit do site do ITCONT para o projeto e registra o validador.
# Uso, na raiz do projeto Icaro no Shell do Replit:  bash Site-ITCONT/instalar-kit.sh
# Desenvolvedor do projeto: Emanuel Macêdo Luz
set -euo pipefail
KIT="$(cd "$(dirname "$0")" && pwd)"
RAIZ="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$RAIZ"
[ -f pnpm-workspace.yaml ] && [ -d artifacts/icaro/src ] || { echo "✗ Rode na raiz do projeto Icaro."; exit 1; }

mkdir -p artifacts/icaro/src/itcont
for f in dados.ts logica.ts tokens.css validate-itcont-site.ts; do
  cp "$KIT/arquivos/artifacts/icaro/src/itcont/$f" "artifacts/icaro/src/itcont/$f"
  echo "✓ artifacts/icaro/src/itcont/$f"
done

node -e '
const fs = require("fs"); const p = "scripts/package.json";
const j = JSON.parse(fs.readFileSync(p, "utf8"));
j.scripts["validate:itcont-site"] = "tsx ../artifacts/icaro/src/itcont/validate-itcont-site.ts";
fs.writeFileSync(p, JSON.stringify(j, null, 2) + "\n");'
echo "✓ script validate:itcont-site registrado"

echo
echo "== Situação inicial (o esperado agora é 67/100; o resto depende da interface que o Agent vai criar)"
pnpm --filter @workspace/scripts run validate:itcont-site || true
echo
echo "Agora cole PROMPT_REPLIT_SITE_ITCONT.md no Replit Agent."
