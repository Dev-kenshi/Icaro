# PROMPT: Site oficial do I ITCONT (cole inteiro no Replit Agent)

> Antes, rode no Shell: `unzip -o Site-ITCONT.zip && bash Site-ITCONT/instalar-kit.sh`
> O kit já colocou os dados oficiais, a lógica, as cores e o validador em `artifacts/icaro/src/itcont/`.

---

Você é um engenheiro front-end sênior e diretor de arte. Crie o **site público do evento I ITCONT (I Imersão Tecnológica Contábil da UEFS)**. Ele deve ser futurista, com a textura e as cores da identidade oficial do evento e com uma responsividade diferente do comum: cada tipo de tela ganha uma *experiência* própria, não só colunas reorganizadas.

## 0. Regras inegociáveis
1. **Não altere** `dados.ts`, `logica.ts`, `tokens.css` nem `validate-itcont-site.ts` em `artifacts/icaro/src/itcont/`. Se um teste falhar, corrija o *seu* código, nunca o teste.
2. Toda data, hora, nome, link e texto oficial vem de `ITCONT` (`./dados`). Toda regra (contagem, fase do evento, agenda, mapa, compartilhar, layout) vem de `./logica`. Nada de data escrita à mão nos componentes: nem "21/10", nem "19h", nem "de outubro".
3. Cores **somente** por `var(--itc-...)`, nunca hex solto no `site.css` ou nos `.tsx`.
4. Imagens do evento (banner, logo, fotos) **só como link do Even3**, já em `dados.ts`. Não baixe nem copie imagens para `public/`.
5. Plano gratuito: nenhum serviço pago, nenhuma chave de API nova, nenhum banco novo. O site funciona 100% com os dados estáticos.
6. Não adicione bibliotecas pesadas. Use o que já existe: React, Tailwind, framer-motion, lucide-react e three (este só se quiser, e com lazy).
7. Créditos no rodapé: **"Emanuel Macêdo Luz, desenvolvedor do projeto"** (use `ITCONT.creditos`).
8. Não quebre nada do ÍCARO. O palco e o login continuam iguais.

## 1. Onde e como o site entra no app
- Rota pública **`/itcont`**, sem login, no app `artifacts/icaro`.
- Em `artifacts/icaro/src/App.tsx`, faça exatamente isto:
  ```tsx
  import { lazy, Suspense } from 'react';
  const SiteItcont = lazy(() => import('./itcont/SiteItcont'));
  function ehRotaItcont() {
    const base = import.meta.env.BASE_URL.replace(/\/$/, '');
    return window.location.pathname.replace(base, '').replace(/\/$/, '') === '/itcont';
  }
  // dentro de App(), ANTES do return com <LoginGate>:
  if (ehRotaItcont()) return <Suspense fallback={<div className="itc" style={{ minHeight: '100dvh' }} />}><SiteItcont /></Suspense>;
  ```
  O `<SiteItcont` precisa aparecer no arquivo **antes** de `<LoginGate`; o validador confere.
- O servidor já devolve o `index.html` para `/itcont`; não mexa no api-server.

## 2. Estrutura de arquivos obrigatória
```
artifacts/icaro/src/itcont/
  dados.ts  logica.ts  tokens.css  validate-itcont-site.ts   ← do kit, não alterar
  SiteItcont.tsx      ← export default function SiteItcont(); importa './tokens.css' e './site.css'
  site.css            ← layout, texturas, animações e os 5 modos
  secoes/
    Navegacao.tsx  Hero.tsx  Contagem.tsx  Sobre.tsx  Programacao.tsx  Convidados.tsx
    Local.tsx  Inscricao.tsx  Faq.tsx  Rodape.tsx  ModoTelao.tsx
```
A raiz do site é `<div className="itc" data-layout={layout}>`, com `layout = layoutPara(innerWidth, innerHeight, location.search)`, recalculado no `resize` (com debounce) e no `orientationchange`.

## 3. Identidade visual (do banner oficial)
O banner tem um "I" gigante em azul metálico com contorno neon, IMERSÃO e TECNOLÓGICA em azul royal 3D, CONTÁBIL em **prata cromada escovada**, a faixa "I T C O N T" branca sobre azul, e o slogan **INOVAÇÃO • PRÁTICA • CONEXÕES / PARA O FUTURO DA CONTABILIDADE** sobre fundo azul-abismo.
- **Fundo:** `--itc-abismo` com a grade luminosa `--itc-grade` em perspectiva (um "piso" de grade que some no horizonte, com `transform: perspective() rotateX()`), e um véu de ruído com SVG `feTurbulence` inline em 4% de opacidade.
- **Títulos:** `--itc-fonte-titulo` (Archivo, `font-weight: 900; font-stretch: 125%`). Use o efeito 3D com `--itc-metal-azul` + `background-clip: text` + `text-shadow` em camadas (chanfro) + `--itc-brilho`. O texto "CONTÁBIL" usa `--itc-cromo` + `--itc-escovado`.
- **Faixa ITCONT:** cápsula `--itc-royal` com `--itc-chanfro` e texto em `--itc-fonte-rotulo` (Michroma) com `letter-spacing: var(--itc-rastreio)`.
- **Assinatura de luz:** um feixe de luz (*light streak*) diagonal que atravessa o hero a cada 8 s e um brilho que pulsa no contorno do "I". Tudo desliga com `prefers-reduced-motion` (o `tokens.css` já faz isso).
- **Cartões:** vidro azul (`--itc-superficie` com 80% de opacidade + `backdrop-filter: blur(14px)`), borda de 1px `--itc-azul`, cantos `--itc-raio` e reflexo superior com `--itc-chanfro`.
- **Interação "holográfica" (só no desktop):** cartões e o "I" inclinam até 6° seguindo o mouse (`rotateX/rotateY`), com reflexo que acompanha o cursor. No celular, em vez disso, a inclinação vem do giroscópio só se o usuário tocar em "Ativar efeito 3D" (permissão do iOS), e nunca por padrão.

## 4. Responsividade diferente: 5 experiências (`data-layout`)
| Modo | Quando | Experiência |
|---|---|---|
| `celular` | < 600px | **Ingresso digital.** O hero vira um cartão-ingresso vertical (picote lateral com `mask`, código do evento, data, local e o botão "Garantir minha vaga" grande). Barra de abas inferior fixa (Início · Programação · Convidados · Local · Inscrever), com alvos de 44px, ícone e rótulo. Convidados em carrossel com `scroll-snap`. Botão de inscrição fixo acima da barra depois que o hero sai da tela. |
| `celular-deitado` | altura < 500 e deitado | **Painel dividido.** Contagem e botão à esquerda (fixos); conteúdo rolando à direita. Sem barra inferior (economiza altura). |
| `tablet` | 600–1023px | **Bento.** Grade de blocos 2×N com tamanhos diferentes (hero 2×2, contagem 1×1, próxima sessão 1×1, convidados 2×1…), usando `@container` para cada bloco se adaptar ao próprio tamanho. |
| `desktop` | ≥ 1024px | **Cinema.** Hero em tela cheia com o "I" 3D em parallax, menu lateral vertical com indicador de progresso da rolagem e `aria-current`, programação como **linha do tempo horizontal das 2 noites** (trilha neon que acende até a hora atual durante o evento), convidados em grade com inclinação holográfica. |
| `telao` | `?modo=telao` ou ≥ 1920px | **Modo auditório (projetor).** Sem rolagem e sem menu. Tela única gigante que alterna sozinha a cada 12 s: contagem regressiva, "AGORA NO PALCO" e "A SEGUIR" (por `faseDoEvento`), convidados e um QR code do site gerado em SVG inline, sem biblioteca externa nem serviço online. Tecla Esc ou toque mostra "Sair do modo telão". |

- Tipografia fluida com `clamp()`; `--itc-t-hero` já existe.
- `@media print`: programação limpa em preto e branco, 1 página, com local e link da inscrição.
- Nada pode transbordar na horizontal em 320px.

## 5. Seções e conteúdo
1. **Navegacao**: `<nav aria-label="Seções do site">`, links âncora, `aria-current="true"` na seção visível (via IntersectionObserver). Primeiro elemento do site: o link `<a href="#conteudo">Pular para o conteúdo</a>`, visível só no foco.
2. **Hero** (`id="inicio"`): o **único `<h1>`** do site, com `ITCONT.tituloOficial` composto com os efeitos da seção 3. O slogan sai de `ITCONT.slogan.join(' • ')` + `ITCONT.missao`. A data sai de `dataExtenso()` e `horaCurta()`, e o local de `ITCONT.local`. Botões: "Garantir minha vaga (gratuita)" para `ITCONT.inscricaoUrl` e "Ver programação" para `#programacao`. Use o logo do Even3 (`ITCONT.logo`) com `alt` descritivo.
3. **Contagem**: `contagem(new Date())` atualizada a cada 1 s (pausa quando a aba está oculta). Use dígitos com a fonte de rótulo e um *flip* suave. Um `aria-live="polite"` anuncia **só a cada minuto** (não a cada segundo). O selo de status sai de `faseDoEvento()`:
   - `antes`: "Faltam X dias";
   - `ao-vivo`: "🔴 AO VIVO: {título}", com `--itc-alerta`;
   - `intervalo`: "Próxima: {título} · {dataExtenso} às {horaCurta}";
   - `encerrado`: "Obrigado! Até a próxima edição."
4. **Sobre** (`id="sobre"`): `ITCONT.chamada`, `ITCONT.descricao`, `ITCONT.fechamento`; 3 pilares (Inovação, Prática, Conexões) em cartões com ícone lucide.
5. **Programacao** (`id="programacao"`): `sessoesPorDia()`, com abas por noite no celular e linha do tempo no desktop. Cada sessão mostra horário, duração (`duracaoMin`), tipo e os botões "Google Agenda" (`googleAgendaUrl`) e "Baixar .ics" (Blob com `gerarICS([sessao])`, `text/calendar`). Inclua também o botão "Adicionar o evento inteiro" (`gerarICS()`). Durante o evento, destaque a sessão ao vivo.
6. **Convidados** (`id="convidados"`): `ITCONT.convidados`. Cada foto tem `<img alt={nome} loading="lazy" decoding="async" referrerPolicy="no-referrer" onError={...}>`; quando a foto falha, mostra um círculo com `iniciais(nome)` no gradiente metálico. Não invente cargo ou biografia que não estejam em `dados.ts`.
7. **Local** (`id="local"`): `ITCONT.local` + botão "Como chegar" (`mapaUrl()`), e um mapa estilizado em SVG próprio: UEFS como pino neon e Feira de Santana. Não use iframe pago.
8. **Inscricao** (`id="inscricao"`):
   - as 3 categorias gratuitas (`ITCONT.categorias`), as inscrições até `dataExtenso(ITCONT.inscricoesAte)` e o botão grande para `ITCONT.inscricaoUrl`;
   - "Compartilhar": `navigator.share` quando existir, senão `whatsappUrl(location.href)`, mais "Copiar link" com aviso de "Link copiado";
   - **dinâmica de evento:** "Gere seu cartão de divulgação". A pessoa digita o primeiro nome e vê um cartão-ingresso estilizado (canvas) com o nome, o "I" e a data, para baixar como PNG e postar. Escreva "Cartão de divulgação: não substitui a inscrição oficial." Nada é salvo nem enviado.
9. **Faq** (`id="faq"`): `ITCONT.faq` com `<details><summary>`.
10. **Rodape**:
    - `ITCONT.realizacao`, `ITCONT.vinculo.join(' · ')` e `ITCONT.local.instituicao`;
    - link da fonte oficial `ITCONT.fonteUrl`;
    - `ITCONT.creditos`;
    - "Assistente oficial: ÍCARO", com link para `/` (o palco do ÍCARO).
11. **ModoTelao**: descrito na seção 4.

**SEO e compartilhamento:** em `SiteItcont`, num `useEffect`, defina `document.title = \`${ITCONT.sigla} 2026 · ${ITCONT.titulo}\`` e crie ou atualize `meta[name="description"]`, `og:title`, `og:description` e `og:image` (= `ITCONT.banner`) e `theme-color` (abismo). Restaure tudo ao sair. Use `<html lang="pt-BR">` (já existe).

**Links externos:** sempre `target="_blank" rel="noopener noreferrer"`. **Botões:** sempre `<button type="button"` com `type` como **primeiro** atributo.

## 6. As 10 heurísticas de Nielsen aplicadas
1. **Visibilidade do status:** selo da fase (antes / ao vivo / intervalo / encerrado), contagem, `aria-current` no menu, barra de progresso da rolagem, "Link copiado".
2. **Correspondência com o mundo real:** linguagem do público ("Garantir minha vaga", "Como chegar", "Noite 1"), data por extenso e horário de Brasília escrito.
3. **Controle e liberdade:** "Voltar ao topo", sair do modo telão com Esc, carrossel com setas e com toque, nada abre sozinho.
4. **Consistência e padrões:** um só estilo de botão primário (royal + chanfro) e secundário (contorno neon); ícones lucide; âncoras padrão.
5. **Prevenção de erros:** a inscrição só no link oficial; avisar que o cartão de divulgação não é inscrição; nome do cartão limitado a 24 caracteres; agenda sempre no fuso certo.
6. **Reconhecer em vez de lembrar:** data, hora e local repetidos no ingresso, na contagem e na programação; botão de inscrição sempre ao alcance.
7. **Flexibilidade e eficiência:** atalhos de teclado (`g p` programação, `g i` inscrição, `t` modo telão), adicionar à agenda em 1 clique, `.ics` do evento inteiro.
8. **Estética e minimalismo:** uma ideia por tela; no máximo 2 botões por bloco; o brilho só onde importa.
9. **Ajudar a reconhecer e corrigir erros:** foto que falha vira iniciais; sem `navigator.share`, cai no WhatsApp; ao copiar o link, mostra sucesso ou o link para copiar à mão.
10. **Ajuda e documentação:** FAQ, "Como chegar" e o contato pela página oficial.

## 7. As 10 leis da beleza aplicadas
1. **Proporção áurea:** escala tipográfica 1,618 (`--itc-t-*`); o hero divide em 61,8% título e 38,2% ingresso ou contagem.
2. **Regra dos terços:** o "I" e o botão principal ficam nos pontos de força do hero.
3. **Simetria e equilíbrio:** a faixa ITCONT e o modo telão são centrados; o desktop é assimétrico, mas equilibrado pelo peso visual.
4. **Contraste:** azul profundo × prata × neon; todos os pares de texto ≥ 4,5:1 (conferido pelo validador).
5. **Hierarquia:** título 3D, depois data e local, depois o botão, depois o detalhe; 1 `<h1>` e `<h2>` por seção.
6. **Ritmo e repetição:** grade de 8px; o mesmo chanfro e o mesmo brilho em todos os elementos ativos; animações com `--itc-ritmo`.
7. **Unidade (Gestalt):** cartões agrupam informação relacionada; proximidade antes de bordas.
8. **Espaço negativo:** margens generosas (`--itc-e-8` e `--itc-e-12`); o fundo escuro "respira" entre as seções.
9. **Harmonia de cor:** paleta análoga de azuis do banner + prata neutra + um único acento quente (`--itc-alerta`), usado só para "ao vivo".
10. **Movimento com propósito:** cada animação comunica algo (luz = tecnologia, contagem = urgência, trilha = tempo do evento); 60 fps (só `transform` e `opacity`); tudo desliga com movimento reduzido.

## 8. Qualidade e validação: obrigatório 100/100
Rode, corrija e repita até tudo passar:
```bash
pnpm --filter @workspace/scripts run validate:itcont-site
pnpm --filter @workspace/icaro run typecheck
pnpm --filter @workspace/scripts run validate:video-v5-tudo   # se o pacote do vídeo estiver instalado
```
Depois teste no navegador e me mostre prints:
- `/itcont` em 390×844 (celular), 844×390 (deitado), 820×1180 (tablet), 1440×900 (desktop) e `/itcont?modo=telao`;
- teclado: Tab percorre tudo, com foco visível; "Pular para o conteúdo" funciona;
- Lighthouse em `/itcont`: Acessibilidade ≥ 95, Boas práticas ≥ 95, SEO ≥ 95, Desempenho ≥ 85 no celular;
- nenhum erro no console; `/` (palco do ÍCARO) e o login continuam funcionando.

## 9. Entrega
1. Faça commit: `feat(itcont): site público do evento I ITCONT (/itcont)`.
2. Dê push para `main` sem force; se for recusado, faça pull com merge, valide de novo e só então push.
3. Não commite `Site-ITCONT.zip` nem a pasta `Site-ITCONT/`.
4. Responda com: o resultado `X/100`, o typecheck, os prints dos 5 modos, as notas do Lighthouse e o hash do commit.
