# PROMPT 9 · Cérebro "99%": pré-preenchimento máximo, IA só no necessário

> Cole no Replit Agent. Mantém banco (`lib/cerebro`) e base (`lib/conhecimento`); acrescenta camadas antes da IA.

## Meta realista
Nenhum banco fixo responde 99% de **qualquer** pergunta. A meta medível é:
- **≥ 90 a 95% das perguntas do evento** respondidas sem chamada completa à IA;
- nas restantes, a IA recebe **no máximo 3 trechos e responde curto**.

O que vale é o número medido com perguntas reais, não a promessa.

---

Implemente o roteador em camadas em `artifacts/api-server/src/lib/cerebro-camadas.ts`, chamado no começo de `/api/ai/chat` e `/api/ai/chat/stream`, **antes** de qualquer provedor.

## Camadas (para na primeira que resolver)
| # | Camada | Custo | Como |
|---|---|---|---|
| L0 | Comandos | 0 | já existe (`commands.ts` + servidor) |
| L1 | **Cache exato** | 0 | pergunta normalizada (minúsculas, sem acento nem pontuação, sinônimos do tesauro) → resposta já dada antes (memória + arquivo `.data/cache-respostas.json`, validade de 30 dias) |
| L2 | **Banco de intenções** | 0 | `IcaroBrain` atual (local/puzzle) |
| L3 | **Cache semântico** | 0 token | embeddings **locais** com `@huggingface/transformers` (modelo `Xenova/multilingual-e5-small`, roda no Node e baixa uma vez ~120 MB) de: todas as perguntas-exemplo do banco, todos os títulos+perguntas da base e todas as perguntas já respondidas pela IA. Similaridade de cosseno ≥ 0,90 → usa a resposta salva; entre 0,82 e 0,90 → confirma com a camada L4 |
| L4 | **Base de conhecimento** | 0 | `IcaroConhecimento.responder` (BM25) **combinado** com a busca vetorial de L3 (fusão por posição, RRF). Se `modo === 'base'` → responde o trecho |
| L5 | **Composição curta** | ~150 tokens de saída | a IA (fila `rapido` do PROMPT 8) só **junta e adapta** os 2 ou 3 trechos à pergunta: "Use SÓ estes trechos; 4 a 6 frases; não acrescente fatos". Entrada pequena, saída curta |
| L6 | **IA completa** | normal | só quando nada acima tem confiança; pergunta fora do domínio |

## Aprendizado contínuo (o que faz chegar perto dos 99%)
1. **Toda resposta de L5/L6 vira candidata**: salve `{pergunta, resposta, camada, motor, data}` em `.data/candidatas.jsonl`.
2. **Painel `/admin/cerebro`** (já previsto): lista as candidatas mais frequentes com os botões **Aprovar → banco**, **Aprovar → base** ou **Descartar**. Aprovar gera o embedding e passa a valer na hora (L3).
3. **Paráfrases sintéticas, uma vez e offline:** script `scripts/src/gerar-parafrases.ts` que, para cada intenção do banco e cada trecho da base, pede a um motor grátis 15 variações de como um aluno perguntaria (gírias, erros de fala do reconhecimento de voz, perguntas longas). Salva em `perguntas-extra.json` e indexa em L3. Rode de novo quando a base mudar.
4. **Ensaio antes do ITCONT:** gere 300 perguntas prováveis do público (motor grátis + professor), rode todas pelo roteador e **pré-gere o áudio** das respostas (cache de voz). No dia, a maior parte sai do cache em menos de 1 s.

## Medição (obrigatório)
- `GET /api/ask/stats` passa a mostrar a % por camada (L1…L6), os tokens gastos e os tokens economizados.
- `scripts/src/validate-cerebro-99.ts`: 200 perguntas reais ou de ensaio, com a camada e o id esperados.

  | Grupo | Meta |
  |---|---|
  | dentro do tema | ≥ 90% resolvidas em L1 a L4 |
  | respostas erradas vindas do cache | ≤ 2% |
  | fora do tema | nunca respondidas pelo cache |

- Mostre no painel admin a curva "% sem IA" por dia.

## Regras
- Respostas de L1/L3 continuam passando pelo `presenterize` (gancho de apresentador) e pelo streaming.
- Cache de respostas **não guarda dados pessoais**: se a pergunta tiver CPF, e-mail ou nome próprio de aluno, não salve.
- Dados que mudam (alíquotas, prazos, prefeito) marcados `verificar` na base expiram do cache em 7 dias.

Entregue: a tabela de % por camada antes e depois, com as mesmas 200 perguntas.
