# Ícaro Futuro: pacote de evolução

| Ordem | Arquivo | Para que serve |
|---|---|---|
| 0 | `MAPA_MOTORES_IA_GRATIS.md` | **Leia primeiro:** onde pegar cada chave grátis, nome do Secret e limites |
| 1 | `PROMPT_8_MULTIMOTOR.md` | vários motores de IA com troca automática (o Ícaro nunca fica mudo) |
| 2 | `PROMPT_9_CEREBRO_99.md` | cache, busca semântica local e aprendizado: IA só no necessário |
| 3 | `PROMPT_7_DESIGN_ALIENIGENA.md` | cenário alienígena: galáxia, sistema solar, Terra ao vivo e rede neural estilo filme *A.I.* |
| 4 | `PROMPT_10_NIVEL_HUMANO.md` | emoção, ritmo de apresentador, interrupção natural e memória curta |

Cole **um prompt por vez** no Replit Agent e confira os critérios de aceite antes do próximo.
Antes de tudo, aplique a correção do microfone (`icaro-microfone.zip` ou branch `mic-config`).

Pré-requisito: quem cola os prompts precisa ter permissão de edição no Replit (a conta Emanuelluz não tem).
