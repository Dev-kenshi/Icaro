# PROMPT 10 · Ícaro "nível humano": emoção, ritmo e presença

> Cole no Replit Agent depois dos PROMPTs 7 a 9. Ferramentas gratuitas; ElevenLabs só se houver chave.

1. **Emoção controlada pelo texto:** a persona passa a abrir cada frase, quando fizer sentido, com uma etiqueta invisível `[entusiasmo]`, `[sério]`, `[curioso]`, `[alerta]` ou `[sorriso]`. O servidor remove as etiquetas do texto falado e as envia como eventos SSE `emocao`. O front usa a etiqueta para:
   - mudar a microexpressão do rosto (sobrancelha, sorriso leve) no motor `IcaroAvatar` atual;
   - mudar a cor e a velocidade da rede neural (PROMPT 7);
   - escolher o estilo da voz: no ElevenLabs, `style` e `stability` por frase; no Gemini TTS, uma instrução de estilo curta ("diga com entusiasmo:").
2. **Ritmo de apresentador:**
   - pausa de 250 a 400 ms depois de pergunta retórica e antes de "Anota isso:";
   - pausa curta (120 ms) entre frases comuns;
   - leve aceleração (+5%) em enumerações.

   Implemente no `speakStream` pelo `gap` por frase.
3. **Escuta ativa:** enquanto a pessoa fala por mais de 4 s, o rosto acena levemente com a cabeça e a rede neural pulsa; sem som (nada de "uhum" automático, que atrapalha o reconhecimento).
4. **Interrupção natural:** se o microfone detectar voz forte por mais de 400 ms enquanto o Ícaro fala, ele baixa o volume e para em até 300 ms ("barge-in"), e escuta.
5. **Memória curta da conversa:** guarde as últimas 6 trocas por sessão. Perguntas como "e isso vale para o MEI?" usam o contexto (o banco já tem "e depois?"; estenda para pronomes com uma reescrita da pergunta numa chamada de até 60 tokens, só quando a pergunta tiver menos de 6 palavras e começar com "e", "isso" ou "e se").
6. **Voz mais humana (gratuita):** teste o **Kokoro-82M** (`kokoro-js`, WebGPU no navegador, vozes pt-BR) como 3ª opção em Motor de voz, ao lado de Piper e Servidor. Compare com o Piper em 10 frases e deixe como padrão a que soar melhor, com fallback automático.

Aceite: em 10 perguntas, o rosto muda de expressão de acordo com a etiqueta; a interrupção corta a fala em ≤ 300 ms; "e isso vale para o MEI?" depois de "o que é split payment?" responde no contexto.
