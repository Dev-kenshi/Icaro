# PROMPT 8 · Vários motores de IA gratuitos com troca automática

> Cole no Replit Agent depois de cadastrar as chaves do `MAPA_MOTORES_IA_GRATIS.md` nos Secrets. Não remova nada do fluxo atual: banco → base → IA, streaming `/api/ai/chat/stream` e voz.

---

Crie no `artifacts/api-server` um **pool de motores de IA** que usa só os provedores com chave configurada e troca sozinho quando um falha ou bate o limite. Assim o Ícaro nunca fica mudo no evento.

## 1. Cliente único compatível com OpenAI
`src/lib/providers.ts`:
- **Registro dos provedores:** `{ id, nome, baseURL, secret(s), modelos: { rapido, profundo }, extra? }` para Groq, Gemini (endpoint OpenAI), Cerebras, OpenRouter (`:free`), Mistral, GitHub Models, NVIDIA NIM, Cloudflare, Hugging Face e Cohere (compatibility). Os modelos de cada um ficam em variáveis (`CEREBRAS_MODEL` etc.), com padrão sensato, e **são conferidos no boot** com `GET /models`; um modelo que não existe mais é marcado como indisponível.
- **Funções:** `streamChat(provider, {system, messages, maxTokens, signal})` (SSE, mesmo formato do `groq.streamAnswer`) e `chat()` sem streaming.
- **Modelos de raciocínio** (gpt-oss, qwen3, deepseek-r1): aplique `reasoning_effort` baixo quando o provedor aceitar; se a resposta for 400, repita sem o parâmetro (como já é feito na Groq).

## 2. Roteador com saúde de cada motor
`src/lib/router-ia.ts`:
- **Duas filas:**
  - `rapido` (padrão do palco): Groq → Cerebras → Gemini Flash → Mistral Small → OpenRouter free → GitHub Models → Cloudflare;
  - `profundo` (modo deep, perguntas longas, cálculo ou lei): Gemini Pro/Flash → OpenRouter (modelo grande free) → Groq gpt-oss-120b → NVIDIA.
- **Saúde:** para cada motor, guarde latência do 1º token (média móvel), taxa de erro, `retry-after` de 429 e "em resfriamento até". Pule motores em resfriamento.
- **Troca no meio:** se o 1º token não chegar em 2,5 s (rápido) ou 6 s (profundo), cancele e tente o próximo. Se já saiu texto, não troque: termine com o que veio.
- **Logs:** `{motor, modelo, msPrimeiroToken, msTotal, tokens, fallbackDe}`. `GET /api/ia/saude` (admin) devolve o painel.

## 3. Ligar no fluxo existente
- `/api/ai/chat/stream` e `/api/ai/chat` com `provider: "auto"` usam o roteador. O palco passa a enviar `auto` por padrão; a aba Conexão ganha a opção **Automático (recomendado)** e mantém a escolha manual.
- Na aba Conexão: lista de motores com bolinha verde, amarela ou vermelha, latência média e "em uso agora".
- A lacuna do modo quebra-cabeça usa a fila `rapido` com no máximo 120 tokens.

## 4. Privacidade (obrigatório)
- Nunca envie nome, CPF, e-mail ou dados de alunos aos provedores; a persona do Ícaro não precisa disso.
- Marque no registro os provedores cujo plano grátis pode usar prompts para treino (Gemini fora da UE, Mistral Experiment, alguns `:free` do OpenRouter) e mostre um aviso discreto na aba Conexão.

## 5. Testes
`scripts/src/validate-motores.ts` com `fetch` simulado (sem chave real):
1. Groq dá 429 → Cerebras responde; a Groq entra em resfriamento pelo `retry-after`.
2. O 1º provedor não manda token em 2,5 s → troca para o próximo; o pedido antigo é abortado.
3. Erro depois de já ter mandado texto → não troca e termina com o parcial.
4. Sem nenhuma chave → mensagem clara "configure ao menos uma chave".
5. Modelo inexistente no `/models` → motor marcado indisponível no boot.

Aceite: `validate:motores` sem falhas, `validate:stream` 19 ok e, com as chaves reais, uma pergunta nova respondida com Groq desligado (simule removendo a chave da sessão) em menos de 3 s.
