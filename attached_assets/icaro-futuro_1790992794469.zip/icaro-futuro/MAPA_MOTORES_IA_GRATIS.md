# Mapa de motores de IA gratuitos para o Ícaro (out/2026)

Os limites gratuitos mudam todo mês. Os números abaixo são **aproximados**, vêm de comparativos públicos de 2026 (fontes no fim) e **devem ser conferidos no painel de cada provedor** ao criar a chave.
Guarde cada chave nos **Secrets do Replit** com o nome da coluna "Secret". Nunca no código.

## Texto (o cérebro): todos com API compatível com OpenAI
| # | Provedor | Onde pegar a chave | Secret | Base URL | Grátis (aprox.) | Bom para | Atenção |
|---|---|---|---|---|---|---|---|
| 1 | **Groq** (já usado) | console.groq.com/keys | `GROQ_API_KEY` | `https://api.groq.com/openai/v1` | ~30 req/min; limite diário por modelo | resposta mais rápida (gpt-oss, Llama, Qwen) | limites por modelo |
| 2 | **Google AI Studio (Gemini)** | aistudio.google.com/apikey | `GEMINI_API_KEY` | `https://generativelanguage.googleapis.com/v1beta/openai/` | 5 a 15 req/min, até ~1.500/dia conforme o modelo | perguntas difíceis, contexto longo, voz (TTS) e embeddings | no plano grátis fora da UE os prompts podem ser usados para treino |
| 3 | **Cerebras** | cloud.cerebras.ai | `CEREBRAS_API_KEY` | `https://api.cerebras.ai/v1` | ~30 req/min | altíssima velocidade (Llama/Qwen) | algumas fontes falam em crédito de teste: confira |
| 4 | **OpenRouter** (modelos `:free`) | openrouter.ai/keys | `OPENROUTER_API_KEY` | `https://openrouter.ai/api/v1` | ~20 req/min e 50 req/dia (1.000/dia após comprar US$ 10 uma vez) | variedade: dezenas de modelos grátis num lugar só | modelos grátis mudam e alguns registram prompts |
| 5 | **Mistral** | console.mistral.ai/api-keys | `MISTRAL_API_KEY` | `https://api.mistral.ai/v1` | plano Experiment/Free com cota mensal | bom português, Mistral Small/Large | o plano grátis pode exigir aceitar uso dos dados |
| 6 | **GitHub Models** | github.com/settings/tokens (token com permissão `models:read`) | `GITHUB_MODELS_TOKEN` | `https://models.github.ai/inference` | ~15 req/min, 150 a 1.000/dia | testar modelos da OpenAI e outros com a conta GitHub | limites baixos; bom como reserva |
| 7 | **NVIDIA NIM** | build.nvidia.com (gerar API key) | `NVIDIA_API_KEY` | `https://integrate.api.nvidia.com/v1` | créditos e limites gratuitos | Nemotron, Llama, DeepSeek | créditos acabam |
| 8 | **Cloudflare Workers AI** | dash.cloudflare.com, depois AI, depois Workers AI (Account ID + API Token) | `CF_ACCOUNT_ID` + `CF_API_TOKEN` | `https://api.cloudflare.com/client/v4/accounts/{CF_ACCOUNT_ID}/ai/v1` | cota diária de "neurons" | reserva barata; também tem Whisper e embeddings | contextos menores |
| 9 | **Hugging Face** | huggingface.co/settings/tokens | `HF_TOKEN` | `https://router.huggingface.co/v1` | créditos mensais incluídos | milhares de modelos abertos | limites variam |
| 10 | **Cohere** | dashboard.cohere.com/api-keys | `COHERE_API_KEY` | `https://api.cohere.ai/compatibility/v1` | chave de teste, ~100 req/dia | **reranking** e embeddings multilíngues (melhora a base) | uso não comercial na chave de teste |

**Local e 100% grátis, sem chave:** Ollama (llama3.2:3b, qwen2.5) no PC do evento. Já preparado em `icaro-local/`.

## Voz e ouvido
| Função | Opção | Onde | Secret | Grátis |
|---|---|---|---|---|
| Fala → texto | **Groq Whisper** (já integrado na branch mic-config) | console.groq.com | `GROQ_API_KEY` | dentro da cota Groq |
| Fala → texto | Cloudflare Whisper | Workers AI | `CF_*` | cota de neurons |
| Fala → texto | faster-whisper local | `icaro-local` | nenhum | sim |
| Texto → fala | **ElevenLabs** (voz mais humana, com tempo de cada letra para os lábios) | elevenlabs.io → Profile → API Keys | `ELEVENLABS_API_KEY` + `ELEVENLABS_VOICE_ID` | plano Free com créditos mensais pequenos |
| Texto → fala | **Gemini TTS** (já usado: Charon) | aistudio.google.com | `GEMINI_API_KEY` | cota do AI Studio |
| Texto → fala | **Piper** (já usado no navegador) | sem chave | nenhum | sim |
| Texto → fala | **Kokoro-82M** (vozes pt-BR, qualidade alta, roda no navegador com WebGPU via `kokoro-js`) | sem chave | nenhum | sim. **Testar** a qualidade em português antes de adotar |

## Cosmos e Terra (PROMPT 7)
| Recurso | Onde | Secret | Grátis |
|---|---|---|---|
| NASA GIBS (imagens diárias da Terra) | nasa-gibs.github.io/gibs-api-docs | nenhum | sim |
| NASA API (APOD, imagens) | api.nasa.gov | `NASA_API_KEY` | sim (DEMO_KEY também funciona com limite baixo) |
| Posição da ISS | api.wheretheiss.at | nenhum | sim |
| Terremotos USGS | earthquake.usgs.gov/earthquakes/feed | nenhum | sim |
| Cesium ion (globo estilo Google Earth) | ion.cesium.com/tokens | `VITE_CESIUM_TOKEN` (token público de navegador) | plano Community: uso não comercial ou educacional sem financiamento, ~15 GB/mês |
| Google Photorealistic 3D Tiles | console.cloud.google.com → Map Tiles API | `GOOGLE_MAPS_KEY` | crédito mensal do Google Maps; **exige conta de faturamento**. Use só se o evento aceitar |
| Texturas de planetas | solarsystemscope.com/textures | nenhum | CC BY 4.0 (citar créditos) |
| Posições dos planetas | npm `astronomy-engine` | nenhum | MIT |

**Sobre "Osiris AI":** é um projeto open source (OSIRIS, OSINT) que mostra um globo estilo Google Earth em **CesiumJS** com dezenas de feeds públicos. O PROMPT 7 usa a mesma base técnica (CesiumJS e dados abertos), mas só com dados seguros (ISS, terremotos, imagens da NASA), sem câmeras ou dados de vigilância.

## Ordem sugerida para pegar as chaves
1. Groq (já tem) e **Gemini** (já tem?): confira as duas.
2. **Cerebras** e **OpenRouter**: reservas rápidas para quando a Groq bater o limite.
3. **Cohere**: reranking, que melhora a base de conhecimento (PROMPT 9).
4. **ElevenLabs**: voz mais humana com lábios exatos.
5. Mistral, GitHub Models, NVIDIA, Cloudflare e Hugging Face: reservas extras.
6. Cesium ion: só para o globo "Google Earth".

## Fontes
- [OpenRouter: Free LLM API in 2026, 13 opções comparadas](https://openrouter.ai/blog/tutorials/free-llm-apis-compared/)
- [Free LLM API providers list (2026)](https://0xzr.github.io/freellmpool/free-llm-api-providers-list.html)
- [KDnuggets: 5 Free LLM API Providers 2026](https://www.kdnuggets.com/5-free-llm-api-providers-you-can-use-in-2026)
- [Analytics Vidhya: 15 Free LLM APIs 2026](https://www.analyticsvidhya.com/blog/2026/01/top-free-llm-apis/)
- [Cesium ion: preços dos planos (2026)](https://www.softwr.com/pricing/cesium-ion)
- [Google: perguntas sobre Photorealistic 3D Tiles](https://mapsplatform.google.com/resources/blog/commonly-asked-questions-about-our-recently-launched-photorealistic-3d-tiles/)
- [OSIRIS no GitHub](https://github.com/trevorcapps/osiris)
