# PROMPT 7 · Ícaro "vivo": cenário alienígena, cosmos e rede neural

> Cole no Replit Agent. Mudanças só no front (`artifacts/icaro`). Não mexa no motor do rosto (`public/avatar`), na voz, no microfone nem nas rotas da API.

---

Transforme o palco do ÍCARO (`artifacts/icaro/src/pages/stage.tsx` + `components/stage/*`) num **cenário futurista de design alienígena**, vivo e cheio de detalhes. Referências de clima: ponte de nave alienígena (Arrival, Prometheus), interfaces orgânicas e bioluminescentes, e a estética da rede neural luminosa do filme *A.I. Inteligência Artificial* (2001): azul-gelo, translúcido e com sinapses que acendem. Não copie imagens, marcas nem trechos de filmes; crie tudo por código.

## Regras
1. O rosto continua sendo o centro e precisa ficar nítido: tudo o que é novo fica atrás dele ou nas bordas.
2. **Desempenho:** um único loop de animação; 60 fps no notebook e 30 fps no celular; qualidade cai sozinha se o quadro passar de 22 ms; pausa quando a aba está oculta.
3. **Nada de chave de API no front:** tokens públicos ficam em variáveis `VITE_*` só quando o provedor exige token de navegador (Cesium); o resto vem do servidor.
4. Responsivo de 360 px a 4K; respeite `prefers-reduced-motion` (sem câmera girando, só fades).
5. Carregue three.js, CesiumJS e texturas de forma preguiçosa (depois que o palco aparece), com tela de "materialização" holográfica enquanto carrega.

## 1. Fundo cósmico com 3 cenas (troca suave a cada 90 s ou por comando de voz)
Componente novo `components/stage/cosmos/` com three.js (WebGL), atrás do rosto:

- **Cena A · Galáxia:** espiral procedural de 60 a 120 mil partículas (braços logarítmicos, núcleo quente, poeira escura), girando devagar, com paralaxe no mouse ou giroscópio.
- **Cena B · Sistema Solar:** Sol com shader de plasma e glow; 8 planetas com texturas públicas (Solar System Scope, CC BY 4.0, cite os créditos na aba Sobre); órbitas em linhas holográficas; anéis de Saturno; posições reais do dia calculadas com `astronomy-engine` (MIT, sem chave).
- **Cena C · Terra ao vivo:**
  - **Opção leve (padrão):** globo em three.js com NASA Blue Marble e Black Marble (domínio público). Inclui o terminador dia/noite real pela hora atual, a camada de nuvens do dia via NASA GIBS (WMTS, sem chave), a atmosfera com espalhamento (shader de Fresnel) e as luzes das cidades no lado noturno.
  - **Opção "Google Earth" (se houver token):** CesiumJS com `Cesium.createWorldTerrainAsync` e imagens do Cesium ion (plano Community gratuito para uso educacional sem financiamento e não comercial: confirme o enquadramento do evento). A câmera começa no espaço e faz um voo lento até **Feira de Santana (-12.2664, -38.9663)** e a **UEFS**.
  - **Dados públicos sobre o globo**, estilo painel OSINT, mas só dados abertos e seguros:
    - posição da Estação Espacial em tempo real (`api.wheretheiss.at`, sem chave);
    - terremotos das últimas 24 h (feed GeoJSON do USGS, sem chave);
    - órbita traçada da ISS;
    - marcador pulsante em Feira de Santana.

    Atualize a cada 30 s pelo servidor (rota `/api/cosmos/feeds` com cache), nunca direto do navegador para cada usuário.
- Comandos de voz e teclado: "Ícaro, mostre a galáxia", "mostre o sistema solar", "mostre a Terra", "voe até Feira de Santana". Adicione esses comandos em `lib/commands.ts`, resolvidos sem IA.

## 2. Rede neural viva (inspiração *A.I.*)
Camada `components/stage/neural-web.tsx` (canvas ou WebGL) **entre o cosmos e o rosto**:
- **Rede:** 300 a 600 neurônios em uma esfera ao redor da cabeça, ligados por axônios curvos (Bézier) azul-gelo translúcidos.
- **Comportamento por estado:**

  | Estado | O que a rede faz |
  |---|---|
  | **ouvindo** | as sinapses acendem conforme o volume do microfone, numa onda que vem de fora para dentro |
  | **pensando** | cascatas de disparos saem do centro da testa e percorrem caminhos, como impulsos elétricos; cada `thought` do servidor acende um "cluster" com o título do pensamento em letras finas |
  | **falando** | os disparos seguem a energia de cada palavra (use o `AnalyserNode` da voz); as sílabas fortes acendem nós próximos da boca |
  | **parado** | respiração lenta, com 1 a 3 disparos aleatórios por segundo |

- Cor base `#bfefff` com halo `#39d5ff`; disparos em branco quente; profundidade com blur leve nos nós distantes.

## 3. Arquitetura alienígena do palco
- **Moldura do rosto:** anéis com glifos alienígenas procedurais (alfabeto inventado, gerado por código) que giram em sentidos opostos; marcadores que se reorganizam quando ele pensa.
- **Painéis laterais orgânicos** (só desktop ≥ 1200 px), em vidro fosco com bordas biomórficas (SVG com curvas, não retângulos), mostrando dados reais:
  - relógio de Feira de Santana;
  - próxima passagem da ISS;
  - "rede neural: N sinapses/s";
  - fonte da última resposta (banco, base ou IA) e tempo de resposta.
- **Piso holográfico:** grade hexagonal em perspectiva que pulsa com a voz.
- **Partículas bioluminescentes:** esporos que flutuam e são atraídos pelo rosto quando ele fala.
- **Som ambiente opcional** (desligado por padrão, botão "Ambiente"): drone grave sintetizado com WebAudio (osciladores + ruído filtrado), sem arquivos.

## 4. Materialização (boot de 4 s, uma vez por sessão, pulável)
Escuro total, depois um ponto de luz, a galáxia que se forma, um zoom até a Terra, a rede neural que se acende, o rosto que materializa por varredura e o texto "ÍCARO · CONSCIÊNCIA ONLINE" em decode.

## 5. Qualidade automática
- **Alta:** cosmos three.js completo, 600 neurônios, bloom e Cesium (se houver token).
- **Média:** 40 mil partículas, 300 neurônios, sem bloom.
- **Baixa / celular:** cosmos em imagem estática pré-renderizada com paralaxe CSS e 120 neurônios em canvas 2D.
- Botão "Qualidade" na aba Voz/Visual (Auto, Alta, Média, Baixa), salvo no `localStorage`.

## Aceite
1. As três cenas aparecem e trocam com fade; o comando de voz "mostre a Terra" funciona sem IA.
2. A Terra mostra o dia e a noite corretos agora e a ISS na posição real (compare com wheretheiss.at).
3. A rede neural reage visivelmente nos quatro estados.
4. FPS ≥ 55 no desktop e ≥ 30 em 375×812; sem rolagem horizontal.
5. Sem token do Cesium, o globo leve aparece normalmente (sem erro no console).
6. Créditos das texturas (NASA, Solar System Scope) na aba Sobre.

Entregue a lista de arquivos, prints das 3 cenas em desktop e celular e o FPS medido.
