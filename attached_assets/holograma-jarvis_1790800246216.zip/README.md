# Holograma Jarvis · ITCONT 2026

O holograma azul do vídeo do ITCONT 2026 transformado em assistente interativo. Você pergunta (texto ou voz) e ele responde falando com a sua voz clonada, **com a boca sincronizada à fala em tempo real**. Tem fundo de partículas, scanlines e o cartão final **ITCONT 2026 / Contador do Amanhã**.

## Como a leitura labial funciona
```
pergunta → cérebro (sua Jarvis / Claude) → texto
texto → ElevenLabs (sua voz, PCM 16 kHz) → Simli → vídeo WebRTC do rosto + áudio, sincronizados
```
A Simli anima o rosto do holograma a partir do áudio: cada fonema vira o movimento de boca correspondente. Vídeo e som chegam no mesmo stream WebRTC, então os lábios batem com as palavras. A latência fica em torno de 1 s.

Sem Simli configurada, ou se ela cair, o holograma continua funcionando com o vídeo original em loop, com a boca mexendo mas sem sincronia.

## Rodar no Replit
1. **Create Repl → Import → Upload zip**.
2. Em **Tools → Secrets**, cadastre:
   | Secret | Para quê |
   |---|---|
   | `ELEVENLABS_API_KEY` | voz clonada |
   | `ELEVENLABS_VOICE_ID` | id da voz (`npm run clone-voice`) |
   | `SIMLI_API_KEY` | leitura labial ([app.simli.com](https://app.simli.com) → API key) |
   | `SIMLI_FACE_ID` | rosto do holograma (`npm run create-face`) |
   | `ANTHROPIC_API_KEY` **ou** `JARVIS_URL` | cérebro (opcional) |
3. Clique em **Run**. Não precisa `npm install`: o projeto não tem dependências.
4. Abra a URL `.replit.dev` em aba própria (Chrome/Edge), para o microfone e o áudio funcionarem.

### Configuração única (no Shell do Replit)
```
npm run clone-voice     # cria a voz na ElevenLabs → ELEVENLABS_VOICE_ID
npm run create-face     # cria o rosto na Simli → SIMLI_FACE_ID (leva alguns minutos)
```
Se a Simli recusar o rosto, tente a versão com margem:
```
node scripts/create-face.js scripts/rosto_jarvis_margem.jpg
```
Depois de cadastrar os ids nos Secrets, reinicie o Repl.

## Custos
- **Simli:** cobra por minuto de sessão aberta. A sessão fecha sozinha após `SIMLI_MAX_IDLE` segundos sem fala (padrão 180) e reabre na próxima pergunta. Também fecha ao sair da página.
- **ElevenLabs:** cobra por caractere falado.
- **`RATE_LIMIT`:** limita requisições por visitante por minuto (padrão 40), para ninguém gastar seus créditos.

## Ligar na sua Jarvis
- **Webhook:** defina `JARVIS_URL`. O servidor envia `POST {message, history}` e espera `{ "reply": "texto" }`.
- **Claude:** defina `ANTHROPIC_API_KEY` (modelo em `ANTHROPIC_MODEL`, padrão `claude-sonnet-5-5`). Personalidade em `JARVIS_SYSTEM_PROMPT`.
- **No navegador:** `window.Jarvis.speak("texto")`, `window.Jarvis.ask("pergunta")`, `window.Jarvis.showCard()`.

## Controles
- **Enter** envia · **🎤** ou **Espaço** (fora do campo) fala
- **ITCONT** ou **C** mostra o cartão do evento · **Esc** fecha · "encerrar" exibe o cartão final
- A bolinha do painel mostra o status; passe o mouse para ver voz, leitura labial e cérebro.

## API
| Rota | Descrição |
|---|---|
| `GET /api/health` | status de voz, leitura labial e cérebro |
| `POST /api/chat` `{message, history}` | resposta `{reply, source}` |
| `POST /api/tts` `{text, format?}` | áudio MP3, ou PCM16 16 kHz com `format:"pcm"` |
| `POST /api/simli/session` | token da sessão de leitura labial (a chave fica no servidor) |

## Validação
```
npm test
```
São 66 checagens: arquivos, front-end, servidor estático (Range de vídeo, cache, path traversal), API, limites, integração com webhook e leitura labial com Simli simulada.

## Estrutura
```
server.js              servidor Node sem dependências (estático + API + proxy Simli/ElevenLabs)
public/                interface, estética holográfica, cliente WebRTC da Simli
public/media/          intro.mp4, holo.mp4 (loop de reserva), idle.jpg
scripts/               clone-voice.js, create-face.js, amostra_voz.mp3, rosto_jarvis*.jpg
test/validate.js       validações automáticas
```

## Observações
- A voz clonada e o rosto exigem autorização de quem aparece e fala no vídeo (termos da ElevenLabs e da Simli).
- A leitura labial depende de rede estável: WebRTC precisa de UDP ou TURN, que a Simli já fornece.
