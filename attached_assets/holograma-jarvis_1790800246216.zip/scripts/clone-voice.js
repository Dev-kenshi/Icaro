// Cria a voz clonada na ElevenLabs a partir de scripts/amostra_voz.mp3.
// Uso: ELEVENLABS_API_KEY=... node scripts/clone-voice.js [arquivo.mp3] [nome]
'use strict';
const fs = require('fs');
const path = require('path');

const envFile = path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) for (const l of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
  const m = /^\s*([A-Z_]+)\s*=\s*(.*)\s*$/.exec(l); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
}
const key = process.env.ELEVENLABS_API_KEY;
const file = process.argv[2] || path.join(__dirname, 'amostra_voz.mp3');
const name = process.argv[3] || 'Jarvis ITCONT';
if (!key) { console.error('Defina ELEVENLABS_API_KEY (Secrets do Replit ou .env).'); process.exit(1); }
if (!fs.existsSync(file)) { console.error('Amostra não encontrada:', file); process.exit(1); }

(async () => {
  const form = new FormData();
  form.append('name', name);
  form.append('remove_background_noise', 'true');
  form.append('description', 'Voz do holograma Jarvis (ITCONT 2026)');
  form.append('files', new Blob([fs.readFileSync(file)], { type: 'audio/mpeg' }), path.basename(file));
  const r = await fetch('https://api.elevenlabs.io/v1/voices/add', { method: 'POST', headers: { 'xi-api-key': key }, body: form });
  const txt = await r.text();
  if (!r.ok) { console.error(`Erro ${r.status}: ${txt}`); process.exit(1); }
  const { voice_id } = JSON.parse(txt);
  console.log(`\nVoz criada! Cadastre no Secrets:\nELEVENLABS_VOICE_ID=${voice_id}\n`);
})().catch(e => { console.error(e); process.exit(1); });
