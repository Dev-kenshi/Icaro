// Cria o avatar (rosto) do holograma na Simli para a leitura labial em tempo real.
// Uso: SIMLI_API_KEY=... node scripts/create-face.js [imagem.jpg] [nome]
'use strict';
const fs = require('fs');
const path = require('path');

const envFile = path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) for (const l of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
  const m = /^\s*([A-Z_]+)\s*=\s*(.*)\s*$/.exec(l); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
}
const key = process.env.SIMLI_API_KEY;
const base = (process.env.SIMLI_API_BASE || 'https://api.simli.ai').replace(/\/$/, '');
const file = process.argv[2] || path.join(__dirname, 'rosto_jarvis.jpg');
const name = process.argv[3] || 'jarvis_itcont';
if (!key) { console.error('Defina SIMLI_API_KEY (Secrets do Replit ou .env).'); process.exit(1); }
if (!fs.existsSync(file)) { console.error('Imagem não encontrada:', file); process.exit(1); }

const sleep = ms => new Promise(r => setTimeout(r, ms));
const findId = o => {
  if (!o || typeof o !== 'object') return null;
  for (const k of ['face_id', 'faceId', 'character_uid', 'id', 'uid']) if (typeof o[k] === 'string') return o[k];
  for (const v of Object.values(o)) { const r = typeof v === 'object' ? findId(v) : null; if (r) return r; }
  return null;
};

(async () => {
  const form = new FormData();
  const type = /\.png$/i.test(file) ? 'image/png' : 'image/jpeg';
  form.append('image', new Blob([fs.readFileSync(file)], { type }), path.basename(file));
  console.log('Enviando rosto para a Simli…');
  const r = await fetch(`${base}/faces/trinity?face_name=${encodeURIComponent(name)}`, {
    method: 'POST', headers: { 'x-simli-api-key': key }, body: form,
  });
  const txt = await r.text();
  if (!r.ok) { console.error(`Erro ${r.status}: ${txt}`); process.exit(1); }
  let data; try { data = JSON.parse(txt); } catch { data = txt; }
  console.log('Resposta:', JSON.stringify(data));
  const id = findId(data);
  if (!id) { console.log('\nNão achei o id na resposta acima. Copie-o manualmente para SIMLI_FACE_ID.'); return; }

  console.log(`\nRosto em geração (id ${id}). Acompanhando o status (pode levar alguns minutos)…`);
  for (let i = 0; i < 90; i++) {
    await sleep(10000);
    const s = await fetch(`${base}/faces/trinity/generation_status?face_id=${encodeURIComponent(id)}`, { headers: { 'x-simli-api-key': key } });
    const body = await s.text();
    process.stdout.write(`  [${new Date().toLocaleTimeString()}] ${body.slice(0, 160)}\n`);
    if (/fail|error/i.test(body) && !/"error"\s*:\s*null/i.test(body)) { console.error('\nA geração falhou. Tente outra imagem (rosto de frente, bem iluminado, mín. 512x512).'); process.exit(1); }
    if (/complete|done|success|ready|finished/i.test(body)) break;
  }
  console.log(`\nPronto! Cadastre nos Secrets:\nSIMLI_FACE_ID=${id}\n`);
})().catch(e => { console.error(e); process.exit(1); });
