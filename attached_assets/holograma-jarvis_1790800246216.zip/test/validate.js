// 50 validações automáticas: node test/validate.js
'use strict';
const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const exists = f => fs.existsSync(path.join(ROOT, f));
let n = 0, fail = 0;
async function check(name, fn) {
  n++;
  try { const ok = await fn(); if (ok === false) throw new Error('falso'); console.log(`  ✔ ${String(n).padStart(2)} ${name}`); }
  catch (e) { fail++; console.log(`  ✘ ${String(n).padStart(2)} ${name} — ${e.message}`); }
}
const eq = (a, b) => { if (a !== b) throw new Error(`esperado ${b}, veio ${a}`); return true; };

function req(port, method, p, { body, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const r = http.request({ host: '127.0.0.1', port, method, path: p, headers }, res => {
      const chunks = []; res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const buf = Buffer.concat(chunks);
        let json; try { json = JSON.parse(buf.toString()); } catch {}
        resolve({ status: res.statusCode, headers: res.headers, buf, text: buf.toString(), json });
      });
    });
    r.on('error', reject);
    if (body !== undefined) r.write(typeof body === 'string' ? body : JSON.stringify(body));
    r.end();
  });
}
const post = (port, p, body, headers) => req(port, 'POST', p, { body, headers: { 'Content-Type': 'application/json', ...headers } });

function startServer(port, env) {
  return new Promise((resolve, reject) => {
    const clean = { PATH: process.env.PATH, SystemRoot: process.env.SystemRoot, PORT: String(port), HOST: '127.0.0.1',
      ELEVENLABS_API_KEY: '', ELEVENLABS_VOICE_ID: '', ANTHROPIC_API_KEY: '', JARVIS_URL: '', ...env };
    const p = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: clean });
    let out = '';
    const t = setTimeout(() => reject(new Error('servidor não subiu: ' + out)), 8000);
    p.stdout.on('data', d => { out += d; if (out.includes('Holograma Jarvis')) { clearTimeout(t); resolve(p); } });
    p.stderr.on('data', d => { out += d; });
    p.on('exit', c => { clearTimeout(t); reject(new Error('saiu com ' + c + ': ' + out)); });
  });
}

(async () => {
  console.log('\nArquivos');
  await check('server.js, package.json e .replit presentes', () => ['server.js', 'package.json', '.replit'].every(exists));
  await check('package.json válido com script start', () => eq(JSON.parse(read('package.json')).scripts.start, 'node server.js'));
  await check('.replit roda server.js na porta 3000', () => /run = "node server\.js"/.test(read('.replit')) && /localPort = 3000/.test(read('.replit')));
  await check('front-end presente (index/style/app/favicon)', () => ['public/index.html', 'public/style.css', 'public/app.js', 'public/favicon.svg'].every(exists));
  await check('mídias do holograma presentes e não vazias', () => ['intro.mp4', 'holo.mp4', 'idle.jpg'].every(f => fs.statSync(path.join(ROOT, 'public/media', f)).size > 10000));
  await check('amostra de voz e script de clonagem presentes', () => exists('scripts/amostra_voz.mp3') && exists('scripts/clone-voice.js'));
  await check('.env.example documenta todas as variáveis', () => ['ELEVENLABS_API_KEY', 'ELEVENLABS_VOICE_ID', 'ELEVENLABS_MODEL', 'JARVIS_URL', 'ANTHROPIC_API_KEY'].every(k => read('.env.example').includes(k)));
  await check('.gitignore protege .env', () => /^\.env$/m.test(read('.gitignore')));
  await check('sem dependências externas (zero npm install)', () => !JSON.parse(read('package.json')).dependencies);
  await check('nenhuma chave secreta embutida no código', () => !/(sk-ant-|xi-api-key['"]?\s*:\s*['"][a-z0-9]{20})/i.test(read('server.js') + read('public/app.js')));

  console.log('\nFront-end');
  const html = read('public/index.html'), js = read('public/app.js'), css = read('public/style.css');
  await check('todo $(id) do app.js existe no HTML', () => {
    const ids = [...js.matchAll(/\$\('([\w-]+)'\)/g)].map(m => m[1]);
    const miss = ids.filter(id => !html.includes(`id="${id}"`));
    if (miss.length) throw new Error('faltando: ' + miss.join(', ')); return true;
  });
  await check('HTML em pt-BR com viewport mobile', () => html.includes('lang="pt-BR"') && html.includes('name="viewport"'));
  await check('cartão final idêntico ao vídeo', () => ['ITCONT 2026', '1ª Imersão Tecnológica Contábil da UEFS', 'Uma realização do projeto de extensão', 'Contador do Amanhã', '13 e 14 de outubro de 2026', 'Feira de Santana', 'Bahia'].every(s => html.includes(s)));
  await check('vídeos com muted + playsinline (autoplay iOS)', () => (html.match(/muted/g) || []).length >= 2 && (html.match(/playsinline/g) || []).length >= 2);
  await check('holograma compõe com fundo (mix-blend-mode: screen)', () => css.includes('mix-blend-mode: screen'));
  await check('sem recursos externos (CSP self)', () => !/(src|href)="https?:/.test(html) && !/url\(https?:/.test(css));
  await check('fallback de voz do navegador implementado', () => js.includes('speechSynthesis') && js.includes('speakBrowser'));
  await check('reconhecimento de voz pt-BR', () => /rec\.lang = 'pt-BR'/.test(js));
  await check('acessibilidade: legenda aria-live e botões rotulados', () => html.includes('aria-live="polite"') && (html.match(/aria-label=/g) || []).length >= 4);
  await check('respeita prefers-reduced-motion', () => css.includes('prefers-reduced-motion'));

  const PORT = 3100 + Math.floor(Math.random() * 500);
  const srv = await startServer(PORT, {});
  try {
    console.log('\nServidor estático');
    const home = await req(PORT, 'GET', '/');
    await check('GET / → 200 text/html', () => eq(home.status, 200) && /text\/html/.test(home.headers['content-type']));
    await check('cabeçalhos de segurança (nosniff + CSP)', () => home.headers['x-content-type-options'] === 'nosniff' && /default-src 'self'/.test(home.headers['content-security-policy']));
    await check('HTML com Cache-Control no-cache', () => eq(home.headers['cache-control'], 'no-cache'));
    await check('CSS e JS com MIME corretos', async () => /text\/css/.test((await req(PORT, 'GET', '/style.css')).headers['content-type']) && /javascript/.test((await req(PORT, 'GET', '/app.js')).headers['content-type']));
    const size = fs.statSync(path.join(ROOT, 'public/media/holo.mp4')).size;
    await check('vídeo servido como video/mp4 com Accept-Ranges', async () => { const r = await req(PORT, 'HEAD', '/media/holo.mp4'); return /video\/mp4/.test(r.headers['content-type']) && r.headers['accept-ranges'] === 'bytes' && eq(+r.headers['content-length'], size); });
    await check('Range bytes=0-99 → 206 com 100 bytes', async () => { const r = await req(PORT, 'GET', '/media/holo.mp4', { headers: { Range: 'bytes=0-99' } }); return eq(r.status, 206) && eq(r.buf.length, 100) && eq(r.headers['content-range'], `bytes 0-99/${size}`); });
    await check('Range sufixo bytes=-50 → últimos 50 bytes', async () => { const r = await req(PORT, 'GET', '/media/holo.mp4', { headers: { Range: 'bytes=-50' } }); return eq(r.status, 206) && eq(r.buf.length, 50); });
    await check('Range inválido → 416', async () => eq((await req(PORT, 'GET', '/media/holo.mp4', { headers: { Range: `bytes=${size + 10}-` } })).status, 416));
    await check('HEAD não envia corpo', async () => eq((await req(PORT, 'HEAD', '/')).buf.length, 0));
    await check('ETag → 304 Not Modified', async () => { const tag = (await req(PORT, 'GET', '/app.js')).headers.etag; return !!tag && eq((await req(PORT, 'GET', '/app.js', { headers: { 'If-None-Match': tag } })).status, 304); });
    await check('path traversal bloqueado (/../server.js)', async () => { const r = await req(PORT, 'GET', '/../server.js'); return r.status !== 200 && !r.text.includes('createServer'); });
    await check('path traversal codificado bloqueado (%2e%2e)', async () => { const r = await req(PORT, 'GET', '/%2e%2e/server.js'); return r.status !== 200 && !r.text.includes('createServer'); });
    await check('byte nulo na URL → 400', async () => eq((await req(PORT, 'GET', '/a%00.js')).status, 400));
    await check('arquivo inexistente → 404', async () => eq((await req(PORT, 'GET', '/nada.png')).status, 404));
    await check('POST em rota estática → 405', async () => eq((await req(PORT, 'POST', '/')).status, 405));

    console.log('\nAPI');
    await check('/api/health → ok, tts=false, chat=local', async () => { const r = await req(PORT, 'GET', '/api/health'); return r.json.ok === true && r.json.tts === false && eq(r.json.chat, 'local'); });
    await check('/api/tts GET → 405', async () => eq((await req(PORT, 'GET', '/api/tts')).status, 405));
    await check('/api/tts texto vazio → 400', async () => eq((await post(PORT, '/api/tts', { text: '   ' })).status, 400));
    await check('/api/tts JSON inválido → 400', async () => eq((await post(PORT, '/api/tts', '{quebrado')).status, 400));
    await check('/api/tts texto > 2500 → 413', async () => eq((await post(PORT, '/api/tts', { text: 'a'.repeat(2600) })).status, 413));
    await check('/api/tts sem chave → 503 com fallback', async () => { const r = await post(PORT, '/api/tts', { text: 'Olá' }); return eq(r.status, 503) && r.json.fallback === true; });
    await check('corpo > 16KB → 413', async () => eq((await post(PORT, '/api/chat', { message: 'x'.repeat(20000) })).status, 413));
    await check('/api/chat mensagem vazia → 400', async () => eq((await post(PORT, '/api/chat', { message: '' })).status, 400));
    await check('/api/chat mensagem não-string → 400', async () => eq((await post(PORT, '/api/chat', { message: { a: 1 } })).status, 400));
    await check('/api/chat saudação em modo local', async () => { const r = await post(PORT, '/api/chat', { message: 'Olá Jarvis' }); return eq(r.status, 200) && /Jarvis/.test(r.json.reply) && eq(r.json.source, 'local'); });
    await check('/api/chat responde a data do evento', async () => /13 e 14 de outubro/.test((await post(PORT, '/api/chat', { message: 'Quando é o evento?' })).json.reply));
    await check('/api/chat tolera histórico malformado', async () => eq((await post(PORT, '/api/chat', { message: 'oi', history: [null, 5, { role: 'x' }, { role: 'assistant', content: 'a' }] })).status, 200));
    await check('rota /api desconhecida → 404 JSON', async () => { const r = await req(PORT, 'GET', '/api/xyz'); return eq(r.status, 404) && !!r.json; });
  } finally { srv.kill(); }

  console.log('\nIntegração com sua Jarvis (webhook)');
  let got = null, mode = 'ok';
  const mock = http.createServer((q, s) => {
    let b = ''; q.on('data', c => b += c); q.on('end', () => {
      got = JSON.parse(b);
      if (mode === 'err') { s.writeHead(500); return s.end(); }
      s.writeHead(200, { 'Content-Type': 'application/json' }); s.end(JSON.stringify({ reply: 'Resposta da sua Jarvis' }));
    });
  });
  await new Promise(r => mock.listen(0, '127.0.0.1', r));
  const P2 = PORT + 1;
  const srv2 = await startServer(P2, { JARVIS_URL: `http://127.0.0.1:${mock.address().port}/`, ANTHROPIC_API_KEY: 'nao-usar' });
  try {
    await check('/api/health prioriza webhook', async () => eq((await req(P2, 'GET', '/api/health')).json.chat, 'webhook'));
    await check('webhook recebe mensagem + histórico e devolve reply', async () => {
      const r = await post(P2, '/api/chat', { message: 'teste', history: [{ role: 'user', content: 'a' }, { role: 'assistant', content: 'b' }] });
      return eq(r.json.reply, 'Resposta da sua Jarvis') && eq(got.message, 'teste') && eq(got.history.length, 2);
    });
    await check('erro no webhook → 502 sem derrubar servidor', async () => { mode = 'err'; const r = await post(P2, '/api/chat', { message: 'x' }); mode = 'ok'; return eq(r.status, 502) && eq((await req(P2, 'GET', '/api/health')).status, 200); });
  } finally { srv2.kill(); mock.close(); }

  console.log('\nLeitura labial (Simli simulada)');
  await check('script de rosto e imagens do avatar presentes', () => exists('scripts/create-face.js') && exists('scripts/rosto_jarvis.jpg') && exists('scripts/rosto_jarvis_margem.jpg'));
  await check('HTML tem vídeo e áudio da leitura labial', () => html.includes('id="simli"') && html.includes('id="simliAudio"'));
  await check('app.js envia PCM em blocos de 6000 bytes com bytes pares', () => js.includes('const CHUNK = 6000') && js.includes("format: 'pcm'") && js.includes('% 2'));
  await check('app.js cai para o holograma em loop se a Simli falhar', () => /catch \(e\)[\s\S]{0,200}speakEleven|await speakEleven\(text\)/.test(js) && js.includes('e.partial'));
  let simliMode = 'ok', simliGot = null;
  const simli = http.createServer((q, s) => {
    let b = ''; q.on('data', c => b += c); q.on('end', () => {
      const j = (code, o) => { s.writeHead(code, { 'Content-Type': 'application/json' }); s.end(JSON.stringify(o)); };
      if (q.headers['x-simli-api-key'] !== 'simli-teste') return j(401, { detail: 'bad key' });
      if (q.url === '/compose/token') { simliGot = JSON.parse(b); return simliMode === 'tokfail' ? j(500, {}) : j(200, { session_token: 'tok123' }); }
      if (q.url === '/compose/ice') return simliMode === 'icefail' ? j(500, {}) : j(200, [{ urls: 'turn:x', username: 'u', credential: 'c' }]);
      j(404, {});
    });
  });
  await new Promise(r => simli.listen(0, '127.0.0.1', r));
  const P3 = PORT + 2, sp = simli.address().port;
  const srv3 = await startServer(P3, { SIMLI_API_KEY: 'simli-teste', SIMLI_FACE_ID: 'face-abc', SIMLI_API_BASE: `http://127.0.0.1:${sp}`, ELEVENLABS_API_KEY: 'x', ELEVENLABS_VOICE_ID: 'y' });
  try {
    await check('/api/health indica leitura labial ativa', async () => (await req(P3, 'GET', '/api/health')).json.lipsync === true);
    await check('sessão Simli: token, websocket e ICE repassados', async () => {
      const r = await post(P3, '/api/simli/session', {});
      return eq(r.status, 200) && eq(r.json.session_token, 'tok123') && eq(r.json.ws, `ws://127.0.0.1:${sp}/compose/webrtc/p2p`) && eq(r.json.iceServers[0].urls, 'turn:x');
    });
    await check('token pede faceId, PCM16 e fecha sessão ociosa', () => eq(simliGot.faceId, 'face-abc') && eq(simliGot.audioInputFormat, 'pcm16') && simliGot.handleSilence === true && simliGot.maxIdleTime <= 600);
    await check('ICE indisponível → usa STUN público', async () => { simliMode = 'icefail'; const r = await post(P3, '/api/simli/session', {}); simliMode = 'ok'; return /stun:/.test(JSON.stringify(r.json.iceServers)); });
    await check('erro da Simli → 502 sem vazar a chave', async () => { simliMode = 'tokfail'; const r = await post(P3, '/api/simli/session', {}); simliMode = 'ok'; return eq(r.status, 502) && !r.text.includes('simli-teste'); });
  } finally { srv3.kill(); simli.close(); }

  const P4 = PORT + 3;
  const srv4 = await startServer(P4, { RATE_LIMIT: '3' });
  try {
    await check('sem chave Simli → /api/simli/session 503', async () => eq((await post(P4, '/api/simli/session', {})).status, 503));
    await check('GET em /api/simli/session → 405', async () => eq((await req(P4, 'GET', '/api/simli/session')).status, 405));
    await check('CSP libera só api.simli.ai além do próprio site', async () => /connect-src 'self' https:\/\/api\.simli\.ai wss:\/\/api\.simli\.ai;/.test((await req(P4, 'GET', '/')).headers['content-security-policy']));
    await check('limite por IP → 429 (proteção de custo)', async () => { await post(P4, '/api/chat', { message: 'oi' }); return eq((await post(P4, '/api/chat', { message: 'oi' })).status, 429); });
  } finally { srv4.kill(); }

  const P5 = PORT + 4;
  const srv5 = await startServer(P5, { SIMLI_API_KEY: 'k', SIMLI_FACE_ID: 'f', SIMLI_API_BASE: 'http://127.0.0.1:9' });
  try {
    await check('Simli inacessível → 502 (front cai para o loop)', async () => eq((await post(P5, '/api/simli/session', {})).status, 502));
    await check('app.js espera 60s antes de tentar a Simli de novo', () => /retryAt = Date\.now\(\) \+ 60000/.test(read('public/app.js')));
  } finally { srv5.kill(); }

  console.log(`\n${n - fail}/${n} validações OK${fail ? ` — ${fail} falharam` : ''}\n`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
