// Holograma Jarvis — servidor sem dependências (Node 18+)
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');

loadEnv(path.join(__dirname, '.env'));

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC = path.join(__dirname, 'public');
const MAX_BODY = 16 * 1024;
const MAX_TEXT = 2500;

const EL_KEY = process.env.ELEVENLABS_API_KEY || '';
const EL_VOICE = process.env.ELEVENLABS_VOICE_ID || '';
const EL_MODEL = process.env.ELEVENLABS_MODEL || 'eleven_flash_v2_5';
const AN_KEY = process.env.ANTHROPIC_API_KEY || '';
const AN_MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const JARVIS_URL = process.env.JARVIS_URL || '';
// Sincronia labial em tempo real (Simli)
const SIMLI_KEY = process.env.SIMLI_API_KEY || '';
const SIMLI_FACE = process.env.SIMLI_FACE_ID || '';
const SIMLI_API = (process.env.SIMLI_API_BASE || 'https://api.simli.ai').replace(/\/$/, '');
const SIMLI_WS = process.env.SIMLI_WS_URL || SIMLI_API.replace(/^http/, 'ws') + '/compose/webrtc/p2p';
const SIMLI_IDLE = Math.min(Math.max(Number(process.env.SIMLI_MAX_IDLE) || 180, 30), 600);
const RATE_LIMIT = Number(process.env.RATE_LIMIT) || 40; // requisições /api por minuto por IP

const SYSTEM_PROMPT = process.env.JARVIS_SYSTEM_PROMPT ||
  'Você é Jarvis, o holograma assistente do ITCONT 2026 — 1ª Imersão Tecnológica Contábil da UEFS, ' +
  'uma realização do projeto de extensão Contador do Amanhã, em 13 e 14 de outubro de 2026, Feira de Santana, Bahia. ' +
  'Responda sempre em português do Brasil, com tom confiante, cordial e futurista. ' +
  'Suas respostas serão faladas em voz alta: use no máximo 3 frases curtas, sem markdown, listas, emojis ou links.';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.mp4': 'video/mp4', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8',
};

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || !line.includes('=')) continue;
    const i = line.indexOf('=');
    const k = line.slice(0, i).trim();
    const v = line.slice(i + 1).trim().replace(/^(['"])(.*)\1$/, '$2');
    if (!(k in process.env)) process.env[k] = v;
  }
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'microphone=(self), camera=()');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; media-src 'self' blob:; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self' https://api.simli.ai wss://api.simli.ai; frame-ancestors *");
}

const hits = new Map();
function rateLimited(req) {
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const now = Date.now();
  const h = hits.get(ip);
  if (!h || now - h.t > 60000) { hits.set(ip, { t: now, n: 1 }); return false; }
  return ++h.n > RATE_LIMIT;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (now - v.t > 60000) hits.delete(k); }, 60000).unref();

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': MIME['.json'], 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' });
  res.end(body);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    const tooBig = () => Object.assign(new Error('Corpo muito grande'), { status: 413 });
    if (Number(req.headers['content-length']) > MAX_BODY) { req.resume(); return reject(tooBig()); }
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size <= MAX_BODY) chunks.push(c); // acima do limite: só drena, responde 413 no fim
    });
    req.on('end', () => {
      if (size > MAX_BODY) return reject(tooBig());
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { reject(Object.assign(new Error('JSON inválido'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function cleanText(t) {
  return typeof t === 'string' ? t.replace(/[\u0000-\u0008\u000B-\u001F\u007F]/g, '').trim() : '';
}

// ---------- estático (com Range p/ vídeo no Safari/iOS) ----------
function serveStatic(req, res, urlPath) {
  let rel;
  try { rel = decodeURIComponent(urlPath); } catch { return sendJson(res, 400, { error: 'URL inválida' }); }
  if (rel.includes('\0')) return sendJson(res, 400, { error: 'URL inválida' });
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.resolve(PUBLIC, '.' + rel);
  if (file !== PUBLIC && !file.startsWith(PUBLIC + path.sep)) return sendJson(res, 403, { error: 'Proibido' });

  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return sendJson(res, 404, { error: 'Não encontrado' });
    const ext = path.extname(file).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
    const headers = {
      'Content-Type': type, 'Accept-Ranges': 'bytes', ETag: etag,
      'Last-Modified': st.mtime.toUTCString(),
      // código sempre revalida (ETag) para atualizações aparecerem na hora; mídia pesada fica em cache
      'Cache-Control': /\.(html|css|js|json|webmanifest)$/.test(ext) ? 'no-cache' : 'public, max-age=86400',
    };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers); return res.end(); }

    const range = req.headers.range;
    if (range) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(range);
      let start, end;
      if (m && (m[1] || m[2])) {
        if (m[1]) { start = +m[1]; end = m[2] ? Math.min(+m[2], st.size - 1) : st.size - 1; }
        else { start = Math.max(st.size - +m[2], 0); end = st.size - 1; }
      }
      if (start === undefined || start > end || start >= st.size) {
        res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end();
      }
      res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

// ---------- API ----------
async function handleTts(req, res) {
  const { text, format } = await readJson(req);
  const pcm = format === 'pcm'; // PCM16 16 kHz mono = formato que a Simli usa para a leitura labial
  const t = cleanText(text);
  if (!t) return sendJson(res, 400, { error: 'Texto vazio' });
  if (t.length > MAX_TEXT) return sendJson(res, 413, { error: `Texto acima de ${MAX_TEXT} caracteres` });
  if (!EL_KEY || !EL_VOICE) return sendJson(res, 503, { error: 'ElevenLabs não configurada', fallback: true });

  const body = {
    text: t, model_id: EL_MODEL,
    voice_settings: { stability: 0.45, similarity_boost: 0.9, style: 0, use_speaker_boost: true },
  };
  if (/v2_5/.test(EL_MODEL)) body.language_code = 'pt'; // só modelos v2.5 aceitam language_code

  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(EL_VOICE)}/stream?output_format=${pcm ? 'pcm_16000' : 'mp3_44100_128'}`, {
    method: 'POST',
    headers: { 'xi-api-key': EL_KEY, 'Content-Type': 'application/json', Accept: pcm ? 'audio/pcm' : 'audio/mpeg' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(60000),
  });
  if (!r.ok || !r.body) {
    const detail = await r.text().catch(() => '');
    console.error('[tts]', r.status, detail.slice(0, 300));
    return sendJson(res, 502, { error: `ElevenLabs ${r.status}`, fallback: true });
  }
  res.writeHead(200, { 'Content-Type': pcm ? 'application/octet-stream' : 'audio/mpeg', 'Cache-Control': 'no-store' });
  const reader = r.body.getReader();
  req.on('close', () => reader.cancel().catch(() => {}));
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!res.write(Buffer.from(value))) await new Promise(ok => res.once('drain', ok));
  }
  res.end();
}

async function handleSimliSession(req, res) {
  if (!SIMLI_KEY || !SIMLI_FACE) return sendJson(res, 503, { error: 'Simli não configurada' });
  const headers = { 'x-simli-api-key': SIMLI_KEY, 'Content-Type': 'application/json' };
  const [tok, ice] = await Promise.all([
    fetch(`${SIMLI_API}/compose/token`, {
      method: 'POST', headers, signal: AbortSignal.timeout(15000),
      body: JSON.stringify({ faceId: SIMLI_FACE, apiVersion: 'v2', handleSilence: true, maxSessionLength: 3600, maxIdleTime: SIMLI_IDLE, audioInputFormat: 'pcm16' }),
    }),
    fetch(`${SIMLI_API}/compose/ice`, { headers, signal: AbortSignal.timeout(15000) }).catch(() => null),
  ]);
  if (!tok.ok) {
    console.error('[simli]', tok.status, (await tok.text().catch(() => '')).slice(0, 300));
    return sendJson(res, 502, { error: `Simli ${tok.status}` });
  }
  const { session_token } = await tok.json();
  if (!session_token) return sendJson(res, 502, { error: 'Simli sem session_token' });
  let iceServers = null;
  if (ice && ice.ok) {
    const j = await ice.json().catch(() => null);
    iceServers = Array.isArray(j) ? j : j ? [j] : null;
  }
  return sendJson(res, 200, {
    session_token, ws: SIMLI_WS,
    iceServers: iceServers && iceServers.length ? iceServers : [{ urls: ['stun:stun.l.google.com:19302'] }],
  });
}

async function handleChat(req, res) {
  const { message, history } = await readJson(req);
  const msg = cleanText(message);
  if (!msg) return sendJson(res, 400, { error: 'Mensagem vazia' });
  if (msg.length > MAX_TEXT) return sendJson(res, 413, { error: 'Mensagem muito longa' });

  const hist = (Array.isArray(history) ? history : [])
    .filter(h => h && (h.role === 'user' || h.role === 'assistant') && cleanText(h.content))
    .slice(-10)
    .map(h => ({ role: h.role, content: cleanText(h.content).slice(0, MAX_TEXT) }));
  while (hist.length && hist[0].role !== 'user') hist.shift();

  // 1) Sua Jarvis externa (webhook)
  if (JARVIS_URL) {
    const r = await fetch(JARVIS_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, history: hist }), signal: AbortSignal.timeout(45000),
    });
    if (!r.ok) return sendJson(res, 502, { error: `Jarvis externa ${r.status}` });
    const data = await r.json().catch(() => ({}));
    const reply = cleanText(data.reply || data.response || data.text || data.message);
    return sendJson(res, 200, { reply: reply || 'Sem resposta da Jarvis.', source: 'webhook' });
  }

  // 2) Claude (Anthropic)
  if (AN_KEY) {
    const messages = [...hist, { role: 'user', content: msg }];
    // garante alternância user/assistant
    const merged = [];
    for (const m of messages) {
      if (merged.length && merged[merged.length - 1].role === m.role) merged[merged.length - 1].content += '\n' + m.content;
      else merged.push({ ...m });
    }
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': AN_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: AN_MODEL, max_tokens: 400, system: SYSTEM_PROMPT, messages: merged }),
      signal: AbortSignal.timeout(45000),
    });
    if (!r.ok) {
      console.error('[chat]', r.status, (await r.text().catch(() => '')).slice(0, 300));
      return sendJson(res, 502, { error: `Anthropic ${r.status}` });
    }
    const data = await r.json();
    const reply = cleanText((data.content || []).filter(b => b.type === 'text').map(b => b.text).join(' '));
    return sendJson(res, 200, { reply: reply || 'Não consegui formular uma resposta.', source: 'claude' });
  }

  // 3) Modo local (sem chaves)
  return sendJson(res, 200, { reply: localReply(msg), source: 'local' });
}

function localReply(msg) {
  const m = msg.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (/\b(oi|ola|bom dia|boa tarde|boa noite|e ai)\b/.test(m)) return 'Olá! Eu sou o Jarvis, o holograma do ITCONT 2026. Como posso ajudar?';
  if (/quando|data|dia/.test(m)) return 'O ITCONT 2026 acontece nos dias 13 e 14 de outubro de 2026, em Feira de Santana, Bahia.';
  if (/onde|local|lugar/.test(m)) return 'O evento acontece na UEFS, em Feira de Santana, Bahia.';
  if (/itcont|evento|imersao/.test(m)) return 'O ITCONT 2026 é a primeira Imersão Tecnológica Contábil da UEFS, uma realização do projeto de extensão Contador do Amanhã.';
  if (/quem (e|es) voce|seu nome/.test(m)) return 'Eu sou o Jarvis, o assistente holográfico do ITCONT 2026.';
  return 'Estou em modo local. Configure a chave da Anthropic ou a URL da sua Jarvis para respostas completas.';
}

function status() {
  return {
    ok: true,
    tts: Boolean(EL_KEY && EL_VOICE),
    lipsync: Boolean(SIMLI_KEY && SIMLI_FACE && EL_KEY && EL_VOICE),
    chat: JARVIS_URL ? 'webhook' : AN_KEY ? 'claude' : 'local',
  };
}

const server = http.createServer(async (req, res) => {
  securityHeaders(res);
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname === '/api/health' && req.method === 'GET') return sendJson(res, 200, status());
    if (url.pathname.startsWith('/api/') && rateLimited(req)) return sendJson(res, 429, { error: 'Muitas requisições, aguarde um minuto' });
    if (url.pathname === '/api/simli/session') {
      if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return sendJson(res, 405, { error: 'Use POST' }); }
      return await handleSimliSession(req, res);
    }
    if (url.pathname === '/api/tts') {
      if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return sendJson(res, 405, { error: 'Use POST' }); }
      return await handleTts(req, res);
    }
    if (url.pathname === '/api/chat') {
      if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return sendJson(res, 405, { error: 'Use POST' }); }
      return await handleChat(req, res);
    }
    if (url.pathname.startsWith('/api/')) return sendJson(res, 404, { error: 'Rota inexistente' });
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.setHeader('Allow', 'GET, HEAD'); return sendJson(res, 405, { error: 'Método não permitido' }); }
    return serveStatic(req, res, url.pathname);
  } catch (e) {
    // serviço externo inacessível (fetch failed) → 502; tempo esgotado → 504
    const code = e.status || (e.name === 'TimeoutError' ? 504 : e instanceof TypeError && /fetch failed/i.test(e.message) ? 502 : 500);
    if (code >= 500) console.error('[erro]', e);
    if (!res.headersSent) sendJson(res, code, { error: code === 504 ? 'Tempo esgotado' : e.status ? e.message : 'Erro interno', fallback: req.url.startsWith('/api/tts') });
    else res.end();
  }
});

server.requestTimeout = 90000;
if (require.main === module) {
  server.listen(PORT, HOST, () => {
    const s = status();
    console.log(`Holograma Jarvis em http://localhost:${PORT}  | voz: ${s.tts ? 'ElevenLabs' : 'navegador (fallback)'} | leitura labial: ${s.lipsync ? 'Simli' : 'desligada'} | cérebro: ${s.chat}`);
  });
}
module.exports = { server, localReply };
