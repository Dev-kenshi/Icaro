/* Holograma Jarvis — ITCONT 2026 */
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const stage = $('stage'), canvas = $('particles'), intro = $('intro'), talk = $('talk');
  const dock = $('dock'), ask = $('ask'), mic = $('mic'), send = $('send'), dot = $('dot');
  const caption = $('caption'), startBtn = $('start'), cardBtn = $('cardBtn');

  const state = { mode: 'boot', busy: false, history: [], tts: false, audioCtx: null, analyser: null, level: 0, queue: Promise.resolve() };
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

  const setMode = mode => { state.mode = mode; stage.dataset.state = mode; };

  /* ---------------- partículas (fundo estrelado azul do vídeo) ---------------- */
  const ctx = canvas.getContext('2d');
  let W = 0, H = 0, DPR = 1, parts = [];
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = canvas.clientWidth; H = canvas.clientHeight;
    canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const n = Math.round(Math.min(260, (W * H) / 6500));
    parts = Array.from({ length: n }, () => spawn(true));
  }
  function spawn(anywhere) {
    const z = Math.random();
    return {
      x: Math.random() * W, y: anywhere ? Math.random() * H : H + 10,
      r: .4 + z * 2.2, z, a: .15 + z * .75,
      vx: (Math.random() - .5) * .08, vy: -(.05 + z * .25),
      tw: Math.random() * Math.PI * 2,
    };
  }
  function draw(t) {
    ctx.clearRect(0, 0, W, H);
    const boost = 1 + state.level * 1.6;
    for (const p of parts) {
      p.x += p.vx * boost; p.y += p.vy * boost; p.tw += .02;
      if (p.y < -10 || p.x < -10 || p.x > W + 10) Object.assign(p, spawn(false));
      const a = p.a * (.7 + .3 * Math.sin(p.tw));
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 3);
      g.addColorStop(0, `rgba(170,225,255,${a})`);
      g.addColorStop(.35, `rgba(70,160,255,${a * .6})`);
      g.addColorStop(1, 'rgba(30,110,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 3, 0, Math.PI * 2); ctx.fill();
    }
  }

  /* ---------------- nível de áudio → brilho do holograma ---------------- */
  const buf = new Uint8Array(256);
  let fakeTalk = false;
  function tick(t) {
    let lvl = 0;
    const an = lip.ready && lip.analyser ? lip.analyser : state.analyser;
    if (an && state.mode === 'speaking' && !fakeTalk) {
      an.getByteTimeDomainData(buf);
      let sum = 0; for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
      lvl = Math.min(1, Math.sqrt(sum / buf.length) * 4);
    } else if (fakeTalk && state.mode === 'speaking') {
      lvl = .35 + .25 * Math.sin(t / 90) * Math.sin(t / 37);
    }
    state.level += (lvl - state.level) * .25;
    stage.style.setProperty('--lvl', state.level.toFixed(3));
    if (!reduced || state.mode === 'speaking') draw(t);
    requestAnimationFrame(tick);
  }

  /* ---------------- status do servidor ---------------- */
  async function health() {
    try {
      const r = await fetch('/api/health', { cache: 'no-store' });
      const h = await r.json();
      state.tts = !!h.tts;
      lip.enabled = !!h.lipsync && 'RTCPeerConnection' in window;
      dot.className = 'dot ' + (h.tts && h.chat !== 'local' ? 'ok' : 'warn');
      dot.title = `Voz: ${h.tts ? 'ElevenLabs' : 'navegador'} · Leitura labial: ${lip.enabled ? 'Simli' : 'desligada'} · Cérebro: ${h.chat}`;
    } catch {
      dot.className = 'dot warn'; dot.title = 'Servidor offline';
    }
  }

  /* ---------------- legenda ---------------- */
  let capTimer;
  function showCaption(text, who = 'jarvis', hold = 0) {
    clearTimeout(capTimer);
    caption.textContent = text;
    caption.className = 'caption on' + (who === 'user' ? ' user' : '');
    if (hold) capTimer = setTimeout(() => caption.classList.remove('on'), hold);
  }

  /* ---------------- leitura labial ao vivo (Simli) ----------------
     A voz (ElevenLabs, PCM16 16 kHz) vai para a Simli, que devolve por WebRTC o vídeo do rosto
     com a boca sincronizada + o mesmo áudio. Vídeo e som chegam juntos, então a leitura labial bate. */
  const simliVideo = $('simli'), simliAudio = $('simliAudio');
  const CHUNK = 6000; // tamanho de bloco recomendado pela Simli
  const lip = { enabled: false, ready: false, ws: null, pc: null, connecting: null, speaking: false, analyser: null, retryAt: 0 };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function lipClose() {
    lip.ready = false; lip.speaking = false;
    stage.classList.remove('live');
    const { ws, pc } = lip;
    lip.ws = lip.pc = null;
    try { if (ws && ws.readyState === 1) ws.send('DONE'); } catch {}
    try { ws && ws.close(); } catch {}
    try { pc && pc.close(); } catch {}
  }

  function waitIce(pc) {
    return new Promise(resolve => {
      if (pc.iceGatheringState === 'complete') return resolve();
      let last = -1, count = 0;
      pc.addEventListener('icecandidate', e => { if (e.candidate) count++; else resolve(); });
      const poll = setInterval(() => {
        if (pc.iceGatheringState === 'complete' || (count > 0 && count === last)) { clearInterval(poll); resolve(); }
        last = count;
      }, 250);
      setTimeout(() => { clearInterval(poll); resolve(); }, 3000);
    });
  }

  function firstFrame(video, ms) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('simli sem vídeo')), ms);
      const ok = () => { clearTimeout(t); resolve(); };
      if (video.readyState >= 2) return ok();
      video.addEventListener('loadeddata', ok, { once: true });
      video.play().catch(() => {});
    });
  }

  function hookLipAnalyser(stream) {
    if (!state.audioCtx) return;
    try {
      const a = state.audioCtx.createAnalyser(); a.fftSize = 512;
      state.audioCtx.createMediaStreamSource(stream).connect(a); // só mede; quem toca é o <audio>
      lip.analyser = a;
    } catch {}
  }

  function lipConnect() {
    if (!lip.enabled) return Promise.reject(new Error('leitura labial desligada'));
    if (lip.ready && lip.ws && lip.ws.readyState === 1) return Promise.resolve();
    if (lip.connecting) return lip.connecting;
    if (Date.now() < lip.retryAt) return Promise.reject(new Error('Simli indisponível, nova tentativa em instantes'));
    lip.connecting = (async () => {
      const r = await fetch('/api/simli/session', { method: 'POST' });
      if (!r.ok) throw new Error('simli ' + r.status);
      const { session_token, ws: wsBase, iceServers } = await r.json();

      const pc = new RTCPeerConnection({ iceServers });
      lip.pc = pc;
      pc.addTransceiver('audio', { direction: 'recvonly' });
      pc.addTransceiver('video', { direction: 'recvonly' });
      pc.ontrack = e => {
        const stream = e.streams[0] || new MediaStream([e.track]);
        if (e.track.kind === 'video') simliVideo.srcObject = stream;
        else { simliAudio.srcObject = stream; simliAudio.play().catch(() => {}); hookLipAnalyser(stream); }
      };
      pc.onconnectionstatechange = () => {
        if (lip.pc === pc && ['failed', 'closed'].includes(pc.connectionState)) lipClose();
      };
      await pc.setLocalDescription(await pc.createOffer());
      await waitIce(pc);

      const url = new URL(wsBase);
      url.searchParams.set('session_token', session_token);
      url.searchParams.set('enableSFU', 'true');
      const ws = new WebSocket(url);
      ws.binaryType = 'arraybuffer';
      lip.ws = ws;

      const answer = await new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error('simli sem resposta')), 20000);
        ws.onopen = () => ws.send(JSON.stringify({ type: 'offer', sdp: pc.localDescription.sdp }));
        ws.onerror = () => { clearTimeout(t); reject(new Error('falha no websocket da Simli')); };
        ws.onclose = () => { clearTimeout(t); reject(new Error('Simli encerrou a sessão')); if (lip.ws === ws) lipClose(); };
        ws.onmessage = e => {
          if (typeof e.data !== 'string') return;
          const d = e.data;
          if (d === 'START') { setTimeout(() => { if (ws.readyState === 1) ws.send(new Uint8Array(64000)); }, 100); return; }
          if (d === 'SPEAK') { lip.speaking = true; return; }
          if (d === 'SILENT') { lip.speaking = false; return; }
          if (d === 'STOP' || /^(ERROR|CLOSING|RATE)/.test(d)) { console.warn('[simli]', d); if (lip.ws === ws) lipClose(); return; }
          if (d[0] === '{') {
            try { const m = JSON.parse(d); if (m.type === 'answer') { clearTimeout(t); resolve(m); } } catch {}
          }
        };
      });
      await pc.setRemoteDescription(answer);
      await firstFrame(simliVideo, 20000);
      lip.ready = true;
      stage.classList.add('live');
      lip.retryAt = 0;
    })().catch(e => { lip.retryAt = Date.now() + 60000; lipClose(); throw e; }).finally(() => { lip.connecting = null; });
    return lip.connecting;
  }

  async function speakSimli(text) {
    await lipConnect();
    const r = await fetch('/api/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text, format: 'pcm' }) });
    if (!r.ok || !r.body) throw new Error('tts ' + r.status);
    const reader = r.body.getReader();
    let carry = new Uint8Array(0), sent = 0;
    const send = u8 => {
      if (!lip.ws || lip.ws.readyState !== 1) throw Object.assign(new Error('Simli desconectou'), { partial: sent > 0 });
      lip.ws.send(u8); sent += u8.length;
    };
    const t0 = performance.now();
    setMode('speaking');
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        const buf = new Uint8Array(carry.length + value.length);
        buf.set(carry); buf.set(value, carry.length);
        const full = buf.length - (buf.length % CHUNK);
        for (let i = 0; i < full; i += CHUNK) send(buf.slice(i, i + CHUNK));
        carry = buf.slice(full);
      }
      if (carry.length) send(carry.length % 2 ? Uint8Array.from([...carry, 0]) : carry); // PCM16 precisa de bytes pares
      if (!sent) throw new Error('tts vazio');
      // espera o áudio terminar: duração real (32000 bytes = 1 s) e depois o SILENT da Simli
      await sleep(Math.max(0, t0 + (sent / 32000) * 1000 + 300 - performance.now()));
      for (let i = 0; i < 30 && lip.speaking; i++) await sleep(100);
    } finally {
      reader.cancel().catch(() => {});
      if (state.mode === 'speaking') setMode('idle');
    }
  }

  /* ---------------- fala ---------------- */
  function ensureAudio() {
    if (state.audioCtx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    state.audioCtx = new AC();
    state.analyser = state.audioCtx.createAnalyser();
    state.analyser.fftSize = 512;
    state.analyser.connect(state.audioCtx.destination);
  }

  function startTalking() {
    setMode('speaking');
    // começa num ponto aleatório do vídeo para cada fala parecer diferente
    if (talk.duration) try { talk.currentTime = Math.random() * Math.max(0, talk.duration - 8); } catch {}
    talk.play().catch(() => {});
  }
  function stopTalking() {
    talk.pause(); fakeTalk = false;
    if (state.mode === 'speaking') setMode('idle');
  }

  async function speakEleven(text) {
    const r = await fetch('/api/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
    if (!r.ok) throw new Error('tts ' + r.status);
    const blob = await r.blob();
    if (!blob.size) throw new Error('tts vazio');
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    audio.preload = 'auto';
    if (state.audioCtx) {
      try { state.audioCtx.createMediaElementSource(audio).connect(state.analyser); } catch { fakeTalk = true; }
    } else fakeTalk = true;
    try {
      await new Promise((resolve, reject) => {
        audio.onended = resolve;
        audio.onerror = () => reject(new Error('falha ao tocar áudio'));
        audio.onplaying = startTalking;
        audio.play().catch(reject);
      });
    } finally { URL.revokeObjectURL(url); stopTalking(); }
  }

  function pickVoice() {
    const vs = speechSynthesis.getVoices();
    return vs.find(v => /pt-BR/i.test(v.lang) && /male|masculin|daniel|antonio|ricardo/i.test(v.name)) ||
           vs.find(v => /pt-BR/i.test(v.lang)) || vs.find(v => /^pt/i.test(v.lang)) || null;
  }
  function speakBrowser(text) {
    return new Promise(resolve => {
      if (!('speechSynthesis' in window)) {
        fakeTalk = true; startTalking();
        setTimeout(() => { stopTalking(); resolve(); }, Math.min(12000, 400 + text.length * 60));
        return;
      }
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'pt-BR'; u.rate = 1.02; u.pitch = .9;
      const v = pickVoice(); if (v) u.voice = v;
      let done = false;
      const end = () => { if (done) return; done = true; clearTimeout(guard); stopTalking(); resolve(); };
      const guard = setTimeout(end, 4000 + text.length * 120); // alguns navegadores não disparam onend
      u.onstart = () => { fakeTalk = true; startTalking(); };
      u.onend = end; u.onerror = end;
      speechSynthesis.speak(u);
    });
  }

  function speak(text) {
    state.queue = state.queue.then(async () => {
      showCaption(text);
      try {
        if (!state.tts) throw new Error('sem tts');
        if (lip.enabled) {
          try { await speakSimli(text); showCaption(text, 'jarvis', 2500); return; }
          catch (e) {
            console.warn('[leitura labial] indisponível, usando holograma em loop:', e.message);
            if (e.partial) { showCaption(text, 'jarvis', 2500); return; } // já falou parte: não repete
          }
        }
        await speakEleven(text);
      } catch (e) {
        if (e.message !== 'sem tts') console.warn('[voz] usando voz do navegador:', e.message);
        await speakBrowser(text);
      }
      showCaption(text, 'jarvis', 2500);
    }).catch(console.error);
    return state.queue;
  }

  /* ---------------- conversa ---------------- */
  async function askJarvis(raw) {
    const text = (raw || '').trim();
    if (!text || state.busy) return;
    if (/^(mostrar |abrir )?(cart[aã]o|itcont|encerrar|finalizar)$/i.test(text)) { toggleCard(true); return; }
    state.busy = true; send.disabled = true; dot.classList.add('busy');
    hideCard();
    showCaption(text, 'user');
    setMode('thinking');
    try {
      const r = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: state.history }),
      });
      const data = await r.json().catch(() => ({}));
      const reply = r.ok && data.reply ? data.reply : 'Desculpe, tive uma falha de conexão. Pode repetir?';
      if (r.ok) {
        state.history.push({ role: 'user', content: text }, { role: 'assistant', content: reply });
        state.history = state.history.slice(-12);
      }
      setMode('idle');
      await speak(reply);
    } catch {
      setMode('idle');
      await speak('Estou sem conexão com o servidor no momento.');
    } finally {
      state.busy = false; send.disabled = false; dot.classList.remove('busy');
      if (state.mode === 'thinking') setMode('idle');
    }
  }

  dock.addEventListener('submit', e => {
    e.preventDefault();
    const q = ask.value; ask.value = '';
    askJarvis(q);
  });

  /* ---------------- microfone ---------------- */
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null, listening = false;
  if (!SR) { mic.disabled = true; mic.title = 'Reconhecimento de voz indisponível neste navegador (use Chrome/Edge)'; }
  function listen() {
    if (!SR || state.busy) return;
    if (listening) { rec && rec.stop(); return; }
    if (state.mode === 'speaking') return;
    rec = new SR();
    rec.lang = 'pt-BR'; rec.interimResults = true; rec.maxAlternatives = 1;
    let finalText = '';
    rec.onstart = () => { listening = true; mic.classList.add('rec'); showCaption('Ouvindo…', 'user'); };
    rec.onresult = e => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const s = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalText += s; else interim += s;
      }
      showCaption((finalText + interim).trim() || 'Ouvindo…', 'user');
    };
    rec.onerror = e => { if (e.error === 'not-allowed') showCaption('Permita o microfone para falar com o Jarvis.', 'user', 3500); };
    rec.onend = () => {
      listening = false; mic.classList.remove('rec');
      if (finalText.trim()) askJarvis(finalText); else if (caption.textContent === 'Ouvindo…') caption.classList.remove('on');
    };
    try { rec.start(); } catch { listening = false; }
  }
  mic.addEventListener('click', listen);
  window.addEventListener('keydown', e => {
    if (document.activeElement === ask || state.mode === 'boot') return;
    if (e.code === 'Space' && !e.repeat) { e.preventDefault(); listen(); }
    if (e.key === 'c' || e.key === 'C') toggleCard();
    if (e.key === 'Escape') hideCard();
  });

  /* ---------------- cartão ITCONT ---------------- */
  function toggleCard(force) {
    const on = typeof force === 'boolean' ? force : !stage.classList.contains('show-card');
    stage.classList.toggle('show-card', on);
    $('card').setAttribute('aria-hidden', String(!on));
  }
  function hideCard() { toggleCard(false); }
  cardBtn.addEventListener('click', () => toggleCard());
  $('card').addEventListener('click', hideCard);

  /* ---------------- boot ---------------- */
  async function boot() {
    ensureAudio();
    if (state.audioCtx && state.audioCtx.state === 'suspended') state.audioCtx.resume().catch(() => {});
    // desbloqueia o vídeo de fala no iOS dentro do gesto do usuário
    talk.play().then(() => talk.pause()).catch(() => {});
    simliAudio.play().catch(() => {});
    if (lip.enabled) lipConnect().catch(e => console.warn('[leitura labial]', e.message)); // conecta durante a intro
    if ('speechSynthesis' in window) speechSynthesis.getVoices();
    setMode('intro');
    const done = new Promise(res => {
      intro.onended = res;
      setTimeout(res, 4500);
    });
    intro.currentTime = 0;
    intro.play().catch(() => {});
    await done;
    setMode('idle');
    ask.focus({ preventScroll: true });
    speak('Sistemas online. Eu sou o Jarvis, o holograma do ITCONT 2026. Em que posso ajudar?');
  }
  startBtn.addEventListener('click', boot, { once: true });

  window.addEventListener('resize', resize);
  document.addEventListener('visibilitychange', () => { if (document.hidden && listening && rec) rec.stop(); });
  window.addEventListener('pagehide', lipClose); // encerra a sessão Simli (cobrança por minuto)
  resize(); health(); requestAnimationFrame(tick);

  // API pública para integrar com outra Jarvis no mesmo navegador
  window.Jarvis = { speak, ask: askJarvis, showCard: () => toggleCard(true), hideCard };
})();
