Aplique a correção do microfone que está em icaro-microfone/. Não reescreva o código dela.

1. git am icaro-microfone/icaro-microfone.patch
   - Se falhar: git am --abort e copie cada arquivo de icaro-microfone/arquivos/ para o mesmo caminho na raiz (substituindo).
   - (Alternativa: a mesma mudança está na branch "mic-config" do GitHub, 1 commit em cima do 7201572.)
2. Rode e me mostre:
   - pnpm run typecheck
   - pnpm --filter @workspace/scripts run validate:stt      (9 ok)
   - pnpm --filter @workspace/scripts run validate:stream   (19 ok)
3. Com a GROQ_API_KEY real: grave 3 s de fala (ou gere um áudio de teste) e faça POST /api/ai/stt logado (Content-Type audio/webm). Me diga o texto e os ms.
4. Reinicie os workflows, faça commit e push para a main do GitHub.
5. Não publique. Remova a pasta icaro-microfone/ depois de aplicar.
