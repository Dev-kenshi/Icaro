# Ícaro: correção do microfone

## Por que o microfone não funciona
Hoje o Ícaro só ouve pelo reconhecimento de voz do Chrome, que manda o áudio para servidores do Google. Falha quando:
- a permissão do microfone não foi dada ao site (no seu Chrome estava "perguntar");
- o Chrome usa outro microfone como padrão (o reconhecimento sempre usa o padrão);
- outro programa está usando o microfone (Teams, Zoom, Discord, WhatsApp);
- a rede bloqueia o serviço do Google (erro "network", comum em redes de universidade e empresa);
- o navegador não tem reconhecimento (Firefox, alguns Brave/Opera).

## O que esta correção faz
1. **Painel "Microfone"** (na ajuda que abre quando o microfone falha e na aba Voz):
   - modo **Automático** (padrão), **Navegador** ou **Servidor (Whisper)**;
   - escolha do aparelho;
   - medidor de volume;
   - botão **Testar microfone**, que diz exatamente o problema e o que fazer.
2. **Modo Servidor (Whisper)**: toque no microfone, fale e pare. O Ícaro grava, detecta o silêncio e transcreve na Groq (mesma GROQ_API_KEY). Funciona em qualquer rede e navegador com microfone.
3. **Automático**: se o reconhecimento do navegador der erro de rede/serviço, o botão passa sozinho a usar o servidor.

## Arquivos
- `artifacts/api-server/src/routes/stt.ts` (novo) + `routes/index.ts`
- `artifacts/icaro/src/lib/mic-config.ts` (novo)
- `artifacts/icaro/src/components/stage/mic-settings.tsx` (novo)
- `artifacts/icaro/src/pages/stage.tsx`, `stage.css`
- `scripts/src/validate-stt.ts` (novo) + `scripts/package.json`

## Como aplicar
Envie a pasta para a raiz do Replit e cole o `PROMPT_REPLIT.md` no Agent. Ou faça merge da branch `mic-config` no GitHub.

## Enquanto não aplica: resolver no seu Chrome agora
1. Abra o Ícaro, clique no **cadeado** ao lado do endereço → **Microfone → Permitir** → recarregue.
2. Em `chrome://settings/content/microphone`, escolha o microfone certo no topo.
3. Feche Teams/Zoom/Discord.
4. Windows → Configurações → Privacidade → Microfone: permita para apps da área de trabalho (Chrome).
