"""Cria a voz clonada (Instant Voice Cloning) na ElevenLabs a partir da amostra e salva o voice_id no .env.
Uso: python clonar_voz.py [amostra.mp3] [nome]"""
import sys
from pathlib import Path
import requests
from config import API, API_KEY, salvar_env

amostra = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).with_name("amostra_voz.mp3"))
nome = sys.argv[2] if len(sys.argv) > 2 else "Jarvis"

if not API_KEY or "cole_sua" in API_KEY:
    sys.exit("Defina ELEVENLABS_API_KEY no arquivo .env")

with amostra.open("rb") as f:
    r = requests.post(
        f"{API}/voices/add",
        headers={"xi-api-key": API_KEY},
        data={"name": nome, "remove_background_noise": "true",
              "description": "Voz do Jarvis clonada da amostra", "labels": '{"language":"pt-BR"}'},
        files={"files": (amostra.name, f, "audio/mpeg")},
        timeout=120,
    )
if not r.ok:
    sys.exit(f"Erro {r.status_code}: {r.text}")

voice_id = r.json()["voice_id"]
salvar_env("ELEVENLABS_VOICE_ID", voice_id)
print(f"Voz '{nome}' criada: {voice_id} (salvo no .env)")
