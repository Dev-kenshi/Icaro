import os
from pathlib import Path

ENV = Path(__file__).with_name(".env")


def carregar_env():
    if ENV.exists():
        for linha in ENV.read_text(encoding="utf-8").splitlines():
            linha = linha.strip()
            if linha and not linha.startswith("#") and "=" in linha:
                k, v = linha.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def salvar_env(chave, valor):
    linhas = ENV.read_text(encoding="utf-8").splitlines() if ENV.exists() else []
    linhas = [l for l in linhas if not l.startswith(f"{chave}=")] + [f"{chave}={valor}"]
    ENV.write_text("\n".join(linhas) + "\n", encoding="utf-8")


carregar_env()
API = "https://api.elevenlabs.io/v1"
API_KEY = os.environ.get("ELEVENLABS_API_KEY", "")
VOICE_ID = os.environ.get("ELEVENLABS_VOICE_ID", "")
MODEL = os.environ.get("ELEVENLABS_MODEL", "eleven_flash_v2_5")
