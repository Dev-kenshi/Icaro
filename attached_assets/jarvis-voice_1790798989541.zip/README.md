# jarvis-voice

Voz clonada (ElevenLabs) para a Jarvis: tudo que ela responder sai com a voz da amostra.

## Setup
1. `pip install -r requirements.txt`
2. Copie `.env.example` para `.env` e preencha `ELEVENLABS_API_KEY`
3. `python clonar_voz.py` (uma vez só: cria a voz e grava `ELEVENLABS_VOICE_ID` no `.env`)
4. Teste: `python voz.py "Sistemas online, senhor."`

## Integração
```python
from voz import falar, sintetizar, salvar

falar(resposta)                 # toca com streaming (baixa latência, usa ffplay)
mp3 = sintetizar(resposta)      # bytes MP3 (web, WhatsApp, API)
salvar(resposta, "saida.mp3")   # grava em arquivo
```

## Configuração (.env)
- `ELEVENLABS_MODEL`: `eleven_flash_v2_5` (rápido) ou `eleven_multilingual_v2` (qualidade máxima)
- Ajuste fino da voz: `VOICE_SETTINGS` em `voz.py` (stability / similarity_boost)

## Requisitos
- Python 3.9+
- ffmpeg/ffplay no PATH (opcional: sem ele o áudio abre no player padrão do Windows)
- Plano pago da ElevenLabs (Starter ou superior) para clonar voz
- Autorização de quem fala na amostra (exigência dos termos da ElevenLabs)
