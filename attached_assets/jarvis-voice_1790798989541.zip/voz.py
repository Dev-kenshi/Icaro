"""Módulo de voz do Jarvis (ElevenLabs TTS com streaming).

    from voz import falar
    falar("Olá, senhor.")
"""
import shutil
import subprocess
import requests
from config import API, API_KEY, VOICE_ID, MODEL

VOICE_SETTINGS = {"stability": 0.45, "similarity_boost": 0.9, "style": 0.0, "use_speaker_boost": True}
FORMATO = "mp3_44100_128"


def _stream(texto, voice_id=None):
    if not API_KEY or not (voice_id or VOICE_ID):
        raise RuntimeError("Configure ELEVENLABS_API_KEY e rode clonar_voz.py antes.")
    r = requests.post(
        f"{API}/text-to-speech/{voice_id or VOICE_ID}/stream",
        params={"output_format": FORMATO, "optimize_streaming_latency": 2},
        headers={"xi-api-key": API_KEY, "Content-Type": "application/json"},
        json={"text": texto, "model_id": MODEL, "language_code": "pt", "voice_settings": VOICE_SETTINGS},
        stream=True, timeout=60,
    )
    if not r.ok:
        raise RuntimeError(f"ElevenLabs {r.status_code}: {r.text}")
    return r.iter_content(chunk_size=4096)


def sintetizar(texto, voice_id=None) -> bytes:
    """Retorna o MP3 inteiro em bytes (para enviar via web, WhatsApp, etc.)."""
    return b"".join(_stream(texto, voice_id))


def salvar(texto, caminho="resposta.mp3", voice_id=None):
    with open(caminho, "wb") as f:
        for chunk in _stream(texto, voice_id):
            f.write(chunk)
    return caminho


def falar(texto, voice_id=None):
    """Toca a resposta enquanto ela ainda está sendo gerada (baixa latência)."""
    if not texto or not texto.strip():
        return
    player = shutil.which("ffplay")
    if not player:
        import os, tempfile
        p = salvar(texto, os.path.join(tempfile.gettempdir(), "jarvis_resposta.mp3"), voice_id)
        os.startfile(p)
        return
    proc = subprocess.Popen([player, "-nodisp", "-autoexit", "-loglevel", "quiet", "-i", "pipe:0"],
                            stdin=subprocess.PIPE)
    try:
        for chunk in _stream(texto, voice_id):
            proc.stdin.write(chunk)
    finally:
        proc.stdin.close()
        proc.wait()


if __name__ == "__main__":
    import sys
    falar(" ".join(sys.argv[1:]) or "Sistemas online. Em que posso ajudar, senhor?")
