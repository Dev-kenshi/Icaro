"""Exemplo de integração: tudo que o Jarvis responder sai com a voz clonada.
Troque `gerar_resposta` pelo cérebro da sua Jarvis (LLM, comandos, etc.)."""
from voz import falar


def gerar_resposta(pergunta: str) -> str:
    return f"Você perguntou: {pergunta}"  # <- substitua pela lógica da sua Jarvis


if __name__ == "__main__":
    falar("Jarvis online.")
    while True:
        pergunta = input("Você: ").strip()
        if pergunta.lower() in {"sair", "exit"}:
            break
        resposta = gerar_resposta(pergunta)
        print("Jarvis:", resposta)
        falar(resposta)
